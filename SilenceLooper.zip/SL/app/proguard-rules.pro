# Sem regras adicionais.
