package com.silence.looper;

import android.content.Context;
import android.net.Uri;

import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.List;

public final class Mp3Exporter {
    private Mp3Exporter() {}

    public static void export(Context context, Uri outputUri, AudioDecoder.PcmFile audio,
                              List<AudioDecoder.Segment> segments, int repeats, float speed,
                              int repeatPauseSeconds) throws Exception {
        int channels = Math.min(2, Math.max(1, audio.channels));
        AndroidLame lame = new LameBuilder()
                .setInSampleRate(audio.sampleRate)
                .setOutSampleRate(audio.sampleRate)
                .setOutChannels(channels)
                .setOutBitrate(192)
                .setQuality(5)
                .build();

        OutputStream raw = context.getContentResolver().openOutputStream(outputUri, "w");
        if (raw == null) {
            try { lame.close(); } catch (Exception ignored) {}
            throw new IllegalStateException("Não foi possível criar o ficheiro MP3.");
        }

        byte[] mp3buf = new byte[65536];
        short[] pcm = new short[8192 * channels];
        short[] left = new short[8192];
        short[] right = new short[8192];

        try (BufferedOutputStream out = new BufferedOutputStream(raw, 128 * 1024);
             PcmSequenceGenerator gen = new PcmSequenceGenerator(
                     audio, segments, repeats, speed, channels, repeatPauseSeconds)) {
            while (true) {
                int frames = gen.fill(pcm, 8192);
                if (frames <= 0) break;

                int encoded;
                if (channels == 1) {
                    encoded = lame.encode(pcm, pcm, frames, mp3buf);
                } else {
                    for (int i = 0; i < frames; i++) {
                        left[i] = pcm[i * 2];
                        right[i] = pcm[i * 2 + 1];
                    }
                    encoded = lame.encode(left, right, frames, mp3buf);
                }
                if (encoded > 0) out.write(mp3buf, 0, encoded);
            }

            int flush = lame.flush(mp3buf);
            if (flush > 0) out.write(mp3buf, 0, flush);
            out.flush();
        } finally {
            try { lame.close(); } catch (Exception ignored) {}
        }
    }
}
