package com.silence.looper;

import android.content.Context;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.OutputStream;
import java.util.List;

public final class WavExporter {
    private WavExporter() {}

    public static void export(Context context, Uri outputUri, AudioDecoder.PcmFile audio,
                              List<AudioDecoder.Segment> segments, int repeats, float speed,
                              int repeatPauseSeconds) throws Exception {
        int channels = Math.max(1, audio.channels);
        long pauseFrames = Math.max(0, repeatPauseSeconds) * (long) audio.sampleRate;
        long totalFrames = 0L;
        long totalItems = (long) segments.size() * Math.max(1, repeats);

        for (AudioDecoder.Segment s : segments) {
            long originalFrames = msToFrames(Math.max(0L, s.endMs - s.startMs), audio.sampleRate);
            long spedFrames = Math.max(1L, Math.round(originalFrames / Math.max(0.05f, speed)));
            totalFrames += spedFrames * Math.max(1, repeats);
        }
        if (totalItems > 1L) totalFrames += pauseFrames * (totalItems - 1L);

        long dataBytes = totalFrames * channels * 2L;
        if (dataBytes > 0xFFFFFFFFL - 44L) {
            throw new IllegalArgumentException("O ficheiro WAV resultante seria demasiado grande.");
        }

        OutputStream raw = context.getContentResolver().openOutputStream(outputUri, "w");
        if (raw == null) throw new IllegalStateException("Não foi possível criar o ficheiro WAV.");

        try (BufferedOutputStream out = new BufferedOutputStream(raw, 128 * 1024);
             PcmSequenceGenerator gen = new PcmSequenceGenerator(
                     audio, segments, repeats, speed, channels, repeatPauseSeconds)) {
            writeHeader(out, audio.sampleRate, channels, dataBytes);
            short[] pcm = new short[8192 * channels];
            byte[] bytes = new byte[pcm.length * 2];

            while (true) {
                int frames = gen.fill(pcm, 8192);
                if (frames <= 0) break;
                int samples = frames * channels;
                int p = 0;
                for (int i = 0; i < samples; i++) {
                    short s = pcm[i];
                    bytes[p++] = (byte) (s & 0xff);
                    bytes[p++] = (byte) ((s >> 8) & 0xff);
                }
                out.write(bytes, 0, p);
            }
            out.flush();
        }
    }

    private static long msToFrames(long ms, int sampleRate) {
        return ms * sampleRate / 1000L;
    }

    private static void writeHeader(OutputStream out, int sampleRate, int channels,
                                    long dataBytes) throws Exception {
        long byteRate = (long) sampleRate * channels * 2L;
        int blockAlign = channels * 2;
        out.write(new byte[]{'R', 'I', 'F', 'F'});
        writeLE32(out, 36L + dataBytes);
        out.write(new byte[]{'W', 'A', 'V', 'E', 'f', 'm', 't', ' '});
        writeLE32(out, 16L);
        writeLE16(out, 1);
        writeLE16(out, channels);
        writeLE32(out, sampleRate);
        writeLE32(out, byteRate);
        writeLE16(out, blockAlign);
        writeLE16(out, 16);
        out.write(new byte[]{'d', 'a', 't', 'a'});
        writeLE32(out, dataBytes);
    }

    private static void writeLE16(OutputStream out, int v) throws Exception {
        out.write(v & 0xff);
        out.write((v >> 8) & 0xff);
    }

    private static void writeLE32(OutputStream out, long v) throws Exception {
        out.write((int) (v & 0xff));
        out.write((int) ((v >> 8) & 0xff));
        out.write((int) ((v >> 16) & 0xff));
        out.write((int) ((v >> 24) & 0xff));
    }
}
