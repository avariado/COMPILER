package com.silence.looper;

import java.io.Closeable;
import java.io.RandomAccessFile;
import java.util.Arrays;
import java.util.List;

/**
 * Gera PCM de saída em streaming a partir de um ficheiro PCM temporário.
 * Suporta segmentos, repetições, pausa entre reproduções e alteração de velocidade
 * sem carregar todo o áudio para a memória.
 */
public final class PcmSequenceGenerator implements Closeable {
    private static final int CACHE_FRAMES = 4096;

    private final AudioDecoder.PcmFile audio;
    private final List<AudioDecoder.Segment> segments;
    private final int repeats;
    private final float speed;
    private final int outChannels;
    private final long pauseFramesTotal;
    private final RandomAccessFile raf;

    private final byte[] cacheBytes;
    private final short[] cacheSamples;
    private long cacheStartFrame = -1L;
    private int cacheFrameCount = 0;

    private int segIndex = 0;
    private int repeatIndex = 0;
    private long dstFrameInItem = 0L;
    private long pauseFramesRemaining = 0L;

    public PcmSequenceGenerator(AudioDecoder.PcmFile audio,
                                List<AudioDecoder.Segment> segments,
                                int repeats,
                                float speed,
                                int outChannels,
                                int repeatPauseSeconds) throws Exception {
        this.audio = audio;
        this.segments = segments;
        this.repeats = Math.max(1, repeats);
        this.speed = Math.max(0.05f, speed);
        this.outChannels = Math.max(1, outChannels);
        this.pauseFramesTotal = Math.max(0, repeatPauseSeconds) * (long) audio.sampleRate;
        this.raf = new RandomAccessFile(audio.file, "r");
        this.cacheBytes = new byte[CACHE_FRAMES * audio.channels * 2];
        this.cacheSamples = new short[CACHE_FRAMES * audio.channels];
    }

    public int fill(short[] dst, int maxFrames) throws Exception {
        int written = 0;
        while (written < maxFrames && segIndex < segments.size()) {
            if (pauseFramesRemaining > 0L) {
                int n = (int) Math.min(maxFrames - written, pauseFramesRemaining);
                Arrays.fill(dst, written * outChannels, (written + n) * outChannels, (short) 0);
                written += n;
                pauseFramesRemaining -= n;
                continue;
            }

            AudioDecoder.Segment seg = segments.get(segIndex);
            long startFrame = clamp(msToFrames(seg.startMs), 0L, audio.totalFrames);
            long endFrame = clamp(msToFrames(seg.endMs), startFrame, audio.totalFrames);
            long srcFrames = endFrame - startFrame;
            if (srcFrames <= 0L) {
                advanceItem();
                continue;
            }

            long dstFrames = Math.max(1L, Math.round(srcFrames / (double) speed));
            if (dstFrameInItem >= dstFrames) {
                advanceItem();
                continue;
            }

            double srcPos = dstFrameInItem * (double) speed;
            long i0 = Math.min(srcFrames - 1L, (long) Math.floor(srcPos));
            long i1 = Math.min(srcFrames - 1L, i0 + 1L);
            double frac = srcPos - i0;

            for (int ch = 0; ch < outChannels; ch++) {
                int srcCh = Math.min(ch, audio.channels - 1);
                short a = sampleAt(startFrame + i0, srcCh);
                short b = sampleAt(startFrame + i1, srcCh);
                int v = (int) Math.round(a + (b - a) * frac);
                dst[written * outChannels + ch] = (short) Math.max(Short.MIN_VALUE,
                        Math.min(Short.MAX_VALUE, v));
            }

            dstFrameInItem++;
            written++;
        }
        return written;
    }

    private void advanceItem() {
        dstFrameInItem = 0L;
        repeatIndex++;
        if (repeatIndex >= repeats) {
            repeatIndex = 0;
            segIndex++;
        }
        if (segIndex < segments.size() && pauseFramesTotal > 0L) {
            pauseFramesRemaining = pauseFramesTotal;
        }
    }

    private short sampleAt(long frame, int channel) throws Exception {
        if (frame < 0L || frame >= audio.totalFrames) return 0;
        if (cacheStartFrame < 0L
                || frame < cacheStartFrame
                || frame >= cacheStartFrame + cacheFrameCount) {
            loadCache(frame);
        }
        int localFrame = (int) (frame - cacheStartFrame);
        if (localFrame < 0 || localFrame >= cacheFrameCount) return 0;
        return cacheSamples[localFrame * audio.channels + channel];
    }

    private void loadCache(long requestedFrame) throws Exception {
        long blockStart = (requestedFrame / CACHE_FRAMES) * CACHE_FRAMES;
        int framesToRead = (int) Math.min(CACHE_FRAMES, audio.totalFrames - blockStart);
        if (framesToRead <= 0) {
            cacheStartFrame = blockStart;
            cacheFrameCount = 0;
            return;
        }

        int bytesToRead = framesToRead * audio.channels * 2;
        raf.seek(blockStart * audio.channels * 2L);
        int read = 0;
        while (read < bytesToRead) {
            int n = raf.read(cacheBytes, read, bytesToRead - read);
            if (n < 0) break;
            read += n;
        }

        int samplesRead = read / 2;
        for (int i = 0, p = 0; i < samplesRead; i++, p += 2) {
            cacheSamples[i] = (short) ((cacheBytes[p] & 0xff) | (cacheBytes[p + 1] << 8));
        }
        cacheStartFrame = blockStart;
        cacheFrameCount = samplesRead / audio.channels;
    }

    private long msToFrames(long ms) {
        return Math.max(0L, ms) * audio.sampleRate / 1000L;
    }

    private static long clamp(long v, long min, long max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override public void close() {
        try { raf.close(); } catch (Exception ignored) {}
    }
}
