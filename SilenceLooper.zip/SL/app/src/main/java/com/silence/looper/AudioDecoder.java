package com.silence.looper;

import android.content.Context;
import android.media.AudioFormat;
import android.media.MediaCodec;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;

import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;

public final class AudioDecoder {
    public static final class PcmFile {
        public final File file;
        public final int sampleRate;
        public final int channels;
        public final long totalFrames;

        public PcmFile(File file, int sampleRate, int channels, long totalFrames) {
            this.file = file;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.totalFrames = totalFrames;
        }

        public long durationMs() {
            return totalFrames * 1000L / Math.max(1, sampleRate);
        }

        public void delete() {
            try { if (file != null) file.delete(); } catch (Exception ignored) {}
        }
    }

    public static final class Segment {
        public final long startMs;
        public final long endMs;

        public Segment(long startMs, long endMs) {
            this.startMs = Math.max(0L, startMs);
            this.endMs = Math.max(this.startMs, endMs);
        }
    }

    public static final class AnalysisResult {
        public final List<Segment> segments;
        public final int sampleRate;
        public final int channels;
        public final long durationMs;
        public final String engine;

        AnalysisResult(List<Segment> segments, int sampleRate, int channels,
                       long durationMs, String engine) {
            this.segments = segments;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.durationMs = durationMs;
            this.engine = engine;
        }
    }

    private static final int ANALYSIS_WINDOW_MS = 40;
    // 800 amostras/s dão 32 medições por janela de 40 ms, suficientes
    // para o envelope de silêncio e com metade do trabalho Java anterior.
    private static final int ANALYSIS_HZ = 800;
    // AAC-LC neste ficheiro tem pacotes de ~23 ms. Para encontrar silêncios
    // de pelo menos 1 s não é necessário descodificar os ~84 mil pacotes:
    // dois pacotes consecutivos a cada 160 ms preservam transições e reduzem
    // em cerca de 70% as chamadas caras ao MediaCodec.
    private static final long ANALYSIS_BURST_INTERVAL_US = 160_000L;
    private static final int ANALYSIS_BURST_PACKETS = 2;

    private AudioDecoder() {}

    /**
     * Análise rápida em vários blocos. Cada bloco descodifica apenas a sua zona da
     * faixa e produz um envelope de nível. A criação dos trechos só acontece no fim,
     * depois de conhecermos o início E o fim de cada silêncio completo.
     */
    public static AnalysisResult analyzeParallelFast(Context context, Uri uri,
                                                     int silenceSeconds,
                                                     int thresholdDb,
                                                     long knownDurationMs,
                                                     boolean reliableRandomAccess) throws Exception {
        SourceInfo info = probeSource(context, uri);
        if (info.durationMs <= 0L && knownDurationMs > 0L) {
            info.durationMs = knownDurationMs;
        }
        if (info.durationMs <= 0L) {
            throw new IllegalArgumentException(
                    "Não foi possível determinar a duração da faixa de áudio.");
        }

        // Num MP4 fragmentado a faixa costuma declarar duration=0. O
        // MediaExtractor da plataforma não usa mfra/tfra para os seeks dos
        // blocos paralelos: cada worker pode recomeçar em zero e descodificar
        // grande parte do ficheiro, multiplicando brutalmente o tempo total.
        // Uma passagem sequencial única é mais rápida e, sobretudo, finita.
        if (!info.hasDeclaredDuration && !reliableRandomAccess) {
            return analyzeSingleEnvelope(
                    context, uri, silenceSeconds, thresholdDb, info);
        }

        int workers;
        if (info.durationMs < 4L * 60_000L) {
            workers = 2;
        } else {
            // Vários MediaCodec AAC em paralelo competem pelo mesmo decoder
            // do dispositivo. Dois blocos foram mais previsíveis que quatro.
            workers = 2;
        }
        workers = Math.min(workers,
                Math.max(1, (int) (info.durationMs / 90_000L) + 1));
        if (workers <= 1) {
            return analyzeSingleEnvelope(context, uri, silenceSeconds, thresholdDb, info);
        }

        ExecutorService pool = Executors.newFixedThreadPool(workers);
        List<Future<ChunkResult>> futures = new ArrayList<>();
        try {
            for (int i = 0; i < workers; i++) {
                long rawStart = info.durationMs * i / workers;
                long rawEnd = info.durationMs * (i + 1L) / workers;

                long startMs = (rawStart / ANALYSIS_WINDOW_MS) * ANALYSIS_WINDOW_MS;
                long endMs = (i == workers - 1)
                        ? info.durationMs
                        : (rawEnd / ANALYSIS_WINDOW_MS) * ANALYSIS_WINDOW_MS;
                if (endMs <= startMs) {
                    endMs = Math.min(info.durationMs, startMs + ANALYSIS_WINDOW_MS);
                }

                final long chunkStart = startMs;
                final long chunkEnd = endMs;
                futures.add(pool.submit(() -> decodeAnalysisChunk(
                        context, uri, info.mime, info.sampleRate, info.channels,
                        chunkStart, chunkEnd, ANALYSIS_WINDOW_MS, ANALYSIS_HZ)));
            }

            List<WindowLevel> all = new ArrayList<>();
            for (Future<ChunkResult> future : futures) {
                all.addAll(future.get().windows);
            }
            Collections.sort(all, Comparator.comparingLong(w -> w.startMs));
            List<WindowLevel> merged = deduplicateWindows(all);

            if (merged.isEmpty()) {
                throw new IllegalStateException(
                        "A descodificação não produziu amostras para análise.");
            }

            DetectionOutput detected = buildSegments(
                    merged, info.durationMs,
                    Math.max(1, silenceSeconds) * 1000L,
                    thresholdDb,
                    ANALYSIS_WINDOW_MS);

            String engine = "Android MediaCodec paralelo (" + workers
                    + " blocos; pedido " + thresholdDb + " dBFS; efetivo "
                    + formatDb(detected.effectiveThresholdDbfs) + " dBFS; piso≈"
                    + formatDb(detected.quietReferenceDb) + " dBFS)";
            return new AnalysisResult(detected.segments, info.sampleRate,
                    info.channels, info.durationMs, engine);
        } catch (ExecutionException e) {
            for (Future<ChunkResult> future : futures) future.cancel(true);
            return analyzeSingleEnvelope(context, uri, silenceSeconds, thresholdDb, info);
        } finally {
            pool.shutdownNow();
        }
    }

    private static AnalysisResult analyzeSingleEnvelope(Context context, Uri uri,
                                                        int silenceSeconds,
                                                        int thresholdDb,
                                                        SourceInfo info) throws Exception {
        ChunkResult chunk = decodeAnalysisChunk(
                context, uri, info.mime, info.sampleRate, info.channels,
                0L, info.durationMs,
                ANALYSIS_WINDOW_MS, ANALYSIS_HZ);

        DetectionOutput detected = buildSegments(
                chunk.windows, info.durationMs,
                Math.max(1, silenceSeconds) * 1000L,
                thresholdDb,
                ANALYSIS_WINDOW_MS);

        String engine = "Android MediaCodec (1 bloco; pedido " + thresholdDb
                + " dBFS; efetivo " + formatDb(detected.effectiveThresholdDbfs)
                + " dBFS; piso≈" + formatDb(detected.quietReferenceDb) + " dBFS)";
        return new AnalysisResult(detected.segments, info.sampleRate,
                info.channels, info.durationMs, engine);
    }

    private static String formatDb(double db) {
        if (!Double.isFinite(db)) return "?";
        return String.format(Locale.US, "%.1f", db);
    }

    private static final class SourceInfo {
        String mime;
        int sampleRate;
        int channels;
        long durationMs;
        boolean hasDeclaredDuration;
    }

    private static SourceInfo probeSource(Context context, Uri uri) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        try {
            ex.setDataSource(context, uri, null);
            for (int i = 0; i < ex.getTrackCount(); i++) {
                MediaFormat f = ex.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    SourceInfo out = new SourceInfo();
                    out.mime = mime;
                    out.sampleRate = f.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                            ? f.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
                    out.channels = f.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                            ? f.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
                    out.durationMs = f.containsKey(MediaFormat.KEY_DURATION)
                            ? Math.max(0L, f.getLong(MediaFormat.KEY_DURATION) / 1000L)
                            : 0L;
                    out.hasDeclaredDuration = out.durationMs > 0L;
                    return out;
                }
            }
        } finally {
            ex.release();
        }
        throw new IllegalArgumentException(
                "O ficheiro não contém uma faixa de áudio suportada.");
    }

    private static final class WindowLevel {
        final long startMs;
        final double db;

        WindowLevel(long startMs, double db) {
            this.startMs = startMs;
            this.db = db;
        }
    }

    private static final class ChunkResult {
        final List<WindowLevel> windows = new ArrayList<>();
    }

    /**
     * Descodifica um bloco e mede o nível RMS em pequenas janelas.
     * A análise usa apenas uma fração regular das amostras para manter o motor
     * rápido, mas o cálculo por janela permanece em dBFS antes da normalização.
     */
    private static ChunkResult decodeAnalysisChunk(
            Context context,
            Uri uri,
            String expectedMime,
            int initialSampleRate,
            int initialChannels,
            long primaryStartMs,
            long primaryEndMs,
            int windowMs,
            int targetAnalysisHz) throws Exception {

        final long warmupMs = 1200L;
        final long decodeStartMs = Math.max(0L, primaryStartMs - warmupMs);
        final long decodeStopMs = primaryEndMs + 180L;

        MediaExtractor extractor = new MediaExtractor();
        MediaCodec codec = null;
        ChunkResult result = new ChunkResult();
        try {
            extractor.setDataSource(context, uri, null);
            int track = -1;
            MediaFormat format = null;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat f = extractor.getTrackFormat(i);
                String mime = f.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    track = i;
                    format = f;
                    break;
                }
            }
            if (track < 0 || format == null) {
                throw new IllegalArgumentException(
                        "O ficheiro não contém uma faixa de áudio suportada.");
            }
            extractor.selectTrack(track);
            extractor.seekTo(decodeStartMs * 1000L,
                    MediaExtractor.SEEK_TO_PREVIOUS_SYNC);
            final long seekAnchorUs = Math.max(0L, extractor.getSampleTime());

            int sampleRate = format.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                    ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE)
                    : initialSampleRate;
            int channels = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                    ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    : initialChannels;
            String mime = format.getString(MediaFormat.KEY_MIME);
            if (mime == null) mime = expectedMime;

            codec = MediaCodec.createDecoderByType(mime);
            codec.configure(format, null, null, 0);
            codec.start();

            int frameStride = Math.max(1, sampleRate / targetAnalysisHz);
            MediaCodec.BufferInfo bi = new MediaCodec.BufferInfo();
            boolean inputDone = false;
            boolean outputDone = false;
            boolean stopFeeding = false;
            long nextAnalysisBurstUs = decodeStartMs * 1000L;
            int analysisBurstPacketsLeft = 0;

            long currentWindowStart = -1L;
            double sumAbs = 0.0;
            long sampleCount = 0L;
            long ptsOffsetUs = Long.MIN_VALUE;

            while (!outputDone) {
                boolean progressed = false;

                while (!inputDone) {
                    long sampleTimeUs = extractor.getSampleTime();
                    while (!stopFeeding && sampleTimeUs >= 0L
                            && analysisBurstPacketsLeft <= 0
                            && sampleTimeUs < nextAnalysisBurstUs) {
                        if (!extractor.advance()) {
                            sampleTimeUs = -1L;
                            break;
                        }
                        sampleTimeUs = extractor.getSampleTime();
                        progressed = true;
                    }
                    if (analysisBurstPacketsLeft <= 0
                            && sampleTimeUs >= nextAnalysisBurstUs) {
                        analysisBurstPacketsLeft = ANALYSIS_BURST_PACKETS;
                        nextAnalysisBurstUs = sampleTimeUs + ANALYSIS_BURST_INTERVAL_US;
                    }

                    int in = codec.dequeueInputBuffer(0);
                    if (in < 0) break;
                    ByteBuffer buf = codec.getInputBuffer(in);
                    if (buf == null) break;
                    buf.clear();

                    if (stopFeeding || sampleTimeUs < 0L
                            || sampleTimeUs > decodeStopMs * 1000L) {
                        codec.queueInputBuffer(in, 0, 0,
                                Math.max(0L, decodeStopMs * 1000L),
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                        break;
                    }

                    int size = extractor.readSampleData(buf, 0);
                    if (size < 0) {
                        codec.queueInputBuffer(in, 0, 0, 0,
                                MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                        inputDone = true;
                    } else {
                        codec.queueInputBuffer(in, 0, size,
                                Math.max(0L, sampleTimeUs), 0);
                        if (analysisBurstPacketsLeft > 0) {
                            analysisBurstPacketsLeft--;
                        }
                        extractor.advance();
                    }
                    progressed = true;
                }

                while (true) {
                    int outIndex = codec.dequeueOutputBuffer(bi, 0);
                    if (outIndex >= 0) {
                        ByteBuffer out = codec.getOutputBuffer(outIndex);
                        if (out != null && bi.size > 0) {
                            MediaFormat of;
                            try {
                                of = codec.getOutputFormat(outIndex);
                            } catch (Throwable ignored) {
                                of = codec.getOutputFormat();
                            }
                            if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                                sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                            }
                            if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                                channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                            }
                            validatePcm16(of);
                            frameStride = Math.max(1, sampleRate / targetAnalysisHz);

                            out.order(ByteOrder.LITTLE_ENDIAN);
                            int bytesPerFrame = Math.max(2, channels * 2);
                            int frames = bi.size / bytesPerFrame;
                            int limit = bi.offset + bi.size;
                            long rawStartUs = Math.max(0L, bi.presentationTimeUs);

                            if (ptsOffsetUs == Long.MIN_VALUE) {
                                long diffUs = Math.abs(rawStartUs - seekAnchorUs);
                                ptsOffsetUs = (primaryStartMs > 0L && diffUs > 2_000_000L)
                                        ? (seekAnchorUs - rawStartUs)
                                        : 0L;
                            }
                            long bufferStartUs = Math.max(0L, rawStartUs + ptsOffsetUs);

                            for (int frame = 0; frame < frames; frame += frameStride) {
                                long timeMs = bufferStartUs / 1000L
                                        + (long) frame * 1000L
                                        / Math.max(1, sampleRate);
                                if (timeMs < primaryStartMs) continue;
                                if (timeMs >= primaryEndMs) {
                                    stopFeeding = true;
                                    break;
                                }

                                long winStart = (timeMs / windowMs) * windowMs;
                                if (currentWindowStart < 0L) {
                                    currentWindowStart = winStart;
                                }
                                if (winStart != currentWindowStart) {
                                    if (sampleCount > 0L
                                            && currentWindowStart >= primaryStartMs
                                            && currentWindowStart < primaryEndMs) {
                                        result.windows.add(new WindowLevel(
                                                currentWindowStart,
                                                dbFromMeanAbs(sumAbs, sampleCount)));
                                    }
                                    currentWindowStart = winStart;
                                    sumAbs = 0.0;
                                    sampleCount = 0L;
                                }

                                int frameBase = bi.offset + frame * bytesPerFrame;
                                for (int ch = 0; ch < channels; ch++) {
                                    int pos = frameBase + ch * 2;
                                    if (pos + 1 >= limit) break;
                                    short sample = out.getShort(pos);
                                    sumAbs += Math.abs((int) sample) / 32768.0;
                                    sampleCount++;
                                }
                            }
                        }

                        boolean eos = (bi.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                        codec.releaseOutputBuffer(outIndex, false);
                        progressed = true;
                        if (eos) {
                            outputDone = true;
                            break;
                        }
                        continue;
                    }
                    if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                        MediaFormat of = codec.getOutputFormat();
                        if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                            sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                        }
                        if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                            channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                        }
                        validatePcm16(of);
                        frameStride = Math.max(1, sampleRate / targetAnalysisHz);
                        progressed = true;
                        continue;
                    }
                    break;
                }

                if (!outputDone && !progressed) {
                    // Não retiramos um buffer aqui para não perder dados de análise.
                    // A espera só acontece quando o codec não aceitou entrada nem
                    // produziu saída nessa iteração.
                    try {
                        Thread.sleep(1L);
                    } catch (InterruptedException e) {
                        Thread.currentThread().interrupt();
                        throw new IllegalStateException("Análise interrompida.", e);
                    }
                }
            }

            if (sampleCount > 0L
                    && currentWindowStart >= primaryStartMs
                    && currentWindowStart < primaryEndMs) {
                result.windows.add(new WindowLevel(
                        currentWindowStart,
                        dbFromMeanAbs(sumAbs, sampleCount)));
            }
            return result;
        } finally {
            if (codec != null) {
                try { codec.stop(); } catch (Throwable ignored) {}
                try { codec.release(); } catch (Throwable ignored) {}
            }
            try { extractor.release(); } catch (Throwable ignored) {}
        }
    }

    private static double dbFromMeanAbs(double sumAbs, long count) {
        if (count <= 0L) return -120.0;
        double mean = sumAbs / count;
        return mean <= 1.0e-9 ? -120.0 : 20.0 * Math.log10(mean);
    }

    private static List<WindowLevel> deduplicateWindows(List<WindowLevel> all) {
        List<WindowLevel> merged = new ArrayList<>(all.size());
        long lastStart = Long.MIN_VALUE;
        for (WindowLevel w : all) {
            if (w.startMs == lastStart && !merged.isEmpty()) {
                // Na fronteira entre blocos conservamos o valor MAIS ALTO
                // (menos silencioso), para nunca inventar um silêncio sobre fala.
                WindowLevel previous = merged.get(merged.size() - 1);
                if (w.db > previous.db) {
                    merged.set(merged.size() - 1, w);
                }
            } else {
                merged.add(w);
                lastStart = w.startMs;
            }
        }
        return merged;
    }

    private static final class SilenceRange {
        final long startMs;
        final long endMs;

        SilenceRange(long startMs, long endMs) {
            this.startMs = startMs;
            this.endMs = endMs;
        }
    }

    private static final class DetectionOutput {
        final List<Segment> segments;
        final double quietReferenceDb;
        final double effectiveThresholdDbfs;

        DetectionOutput(List<Segment> segments,
                        double quietReferenceDb,
                        double effectiveThresholdDbfs) {
            this.segments = segments;
            this.quietReferenceDb = quietReferenceDb;
            this.effectiveThresholdDbfs = effectiveThresholdDbfs;
        }
    }

    /**
     * Usa deliberadamente a mesma métrica e o mesmo critério base da v1.8.0,
     * que no ficheiro de teste já produzia um número plausível de trechos.
     *
     * A única calibração adicional é limitada: se o valor pedido ficar abaixo
     * do piso real de ruído da gravação, o limiar pode subir no máximo 4 dB.
     * Isto evita a queda abrupta de centenas de trechos para 1 sem transformar
     * o controlo numa escala relativa arbitrária.
     *
     * Os silêncios são primeiro detetados por inteiro. Só depois é criada uma
     * fronteira NO CENTRO da pausa. Não se remove nenhum intervalo de áudio: o
     * fim de um trecho coincide exatamente com o início do seguinte.
     */
    private static DetectionOutput buildSegments(List<WindowLevel> windows,
                                                 long durationMs,
                                                 long requiredSilenceMs,
                                                 int thresholdDb,
                                                 int windowMs) {
        if (durationMs <= 0L) {
            return new DetectionOutput(Collections.emptyList(), Double.NaN, thresholdDb);
        }
        if (windows == null || windows.isEmpty()) {
            return new DetectionOutput(
                    Collections.singletonList(new Segment(0L, durationMs)),
                    Double.NaN, thresholdDb);
        }

        double[] raw = new double[windows.size()];
        for (int i = 0; i < windows.size(); i++) raw[i] = windows.get(i).db;
        double[] level = median3(raw);

        // CALIBRAÇÃO DA ESCALA DO UTILIZADOR:
        // -25 dB é o ponto de referência já validado no ficheiro de teste e
        // permanece exatamente -25 dB internamente. As variações em torno desse
        // ponto são comprimidas para 35%, evitando que uma deslocação de apenas
        // 5 dB transforme centenas de pausas em praticamente nenhuma.
        // Exemplos: -20 -> -23,25 dB internos; -30 -> -26,75 dB internos.
        final double calibrationAnchorDb = -25.0;
        final double calibrationSlope = 0.35;
        final double effectiveThreshold = calibrationAnchorDb
                + (thresholdDb - calibrationAnchorDb) * calibrationSlope;
        final double quietFloor = percentileFinite(level, 0.10);

        // Uma pausa tem de ser essencialmente contínua. Admitimos apenas um
        // pico muito curto (até 80 ms) para não partir uma pausa por causa de
        // um clique/estalido isolado. Ao contrário das versões anteriores,
        // nunca aceitamos 20% de fala dentro de uma pausa.
        final int maxLoudGapWindows = Math.max(1,
                (int) Math.ceil(80.0 / Math.max(1, windowMs)));

        List<Long> cuts = new ArrayList<>();
        final long minimumSegmentMs = 800L;
        long previousCut = 0L;

        int i = 0;
        while (i < windows.size()) {
            if (level[i] > effectiveThreshold) {
                i++;
                continue;
            }

            int silenceStartIndex = i;
            int lastSilentIndex = i;
            int loudGap = 0;
            int j = i + 1;

            while (j < windows.size()) {
                if (level[j] <= effectiveThreshold) {
                    lastSilentIndex = j;
                    loudGap = 0;
                } else {
                    loudGap++;
                    if (loudGap > maxLoudGapWindows) break;
                }
                j++;
            }

            long silenceStartMs = windows.get(silenceStartIndex).startMs;
            long silenceEndMs = Math.min(durationMs,
                    windows.get(lastSilentIndex).startMs + windowMs);

            if (silenceEndMs - silenceStartMs >= requiredSilenceMs
                    && silenceStartMs > windowMs * 2L
                    && silenceEndMs < durationMs - windowMs * 2L) {

                // Dentro da pausa qualificada procuramos o maior núcleo de
                // janelas REALMENTE abaixo do limiar e cortamos no centro
                // desse núcleo. Assim o ponto de corte não pode cair numa
                // janela classificada como fala.
                int bestStart = -1;
                int bestEnd = -1;
                int runStart = -1;

                for (int k = silenceStartIndex; k <= lastSilentIndex; k++) {
                    boolean strictSilent = level[k] <= effectiveThreshold;
                    if (strictSilent) {
                        if (runStart < 0) runStart = k;
                    }

                    boolean closesRun = runStart >= 0
                            && (!strictSilent || k == lastSilentIndex);
                    if (closesRun) {
                        int runEnd = strictSilent && k == lastSilentIndex ? k : k - 1;
                        if (bestStart < 0 || runEnd - runStart > bestEnd - bestStart) {
                            bestStart = runStart;
                            bestEnd = runEnd;
                        }
                        runStart = -1;
                    }
                }

                if (bestStart >= 0 && bestEnd >= bestStart) {
                    long coreStartMs = windows.get(bestStart).startMs;
                    long coreEndMs = Math.min(durationMs,
                            windows.get(bestEnd).startMs + windowMs);
                    long cut = coreStartMs + (coreEndMs - coreStartMs) / 2L;
                    cut = Math.max(1L, Math.min(durationMs - 1L, cut));

                    // Não criamos microtrechos. Ignoramos apenas a fronteira;
                    // nunca apagamos o áudio que ficaria nesse intervalo.
                    if (cut - previousCut >= minimumSegmentMs
                            && durationMs - cut >= 400L) {
                        cuts.add(cut);
                        previousCut = cut;
                    }
                }
            }

            // Retomamos a procura depois da sequência que terminou esta pausa.
            // Se o fim do ficheiro foi atingido, termina o ciclo.
            i = Math.max(i + 1, j);
        }

        if (!cuts.isEmpty()
                && durationMs - cuts.get(cuts.size() - 1) < minimumSegmentMs) {
            cuts.remove(cuts.size() - 1);
        }

        List<Segment> segments = new ArrayList<>();
        long startMs = 0L;
        for (long cut : cuts) {
            if (cut > startMs) segments.add(new Segment(startMs, cut));
            startMs = cut;
        }
        if (durationMs > startMs) segments.add(new Segment(startMs, durationMs));
        if (segments.isEmpty()) segments.add(new Segment(0L, durationMs));

        return new DetectionOutput(segments, quietFloor, effectiveThreshold);
    }

    private static double[] median3(double[] input) {
        double[] out = new double[input.length];
        for (int i = 0; i < input.length; i++) {
            double a = input[Math.max(0, i - 1)];
            double b = input[i];
            double c = input[Math.min(input.length - 1, i + 1)];
            out[i] = median(a, b, c);
        }
        return out;
    }

    private static double median(double a, double b, double c) {
        if (a > b) { double t = a; a = b; b = t; }
        if (b > c) { double t = b; b = c; c = t; }
        if (a > b) { double t = a; a = b; b = t; }
        return b;
    }

    private static double percentileFinite(double[] values, double q) {
        List<Double> finite = new ArrayList<>();
        for (double v : values) {
            if (Double.isFinite(v) && v > -140.0 && v < 40.0) finite.add(v);
        }
        if (finite.isEmpty()) return Double.NaN;
        Collections.sort(finite);
        int index = (int) Math.round((finite.size() - 1) * q);
        index = Math.max(0, Math.min(finite.size() - 1, index));
        return finite.get(index);
    }

    // -------------------------------------------------------------------------
    // Descodificação integral para ficheiro PCM temporário, usada pela exportação.
    // Evita manter ficheiros de áudio longos integralmente na RAM.
    // -------------------------------------------------------------------------

    public static PcmFile decodeToPcmFile(Context context, Uri uri) throws Exception {
        DecoderState ds = openDecoder(context, uri);
        int sampleRate = ds.sampleRate;
        int channels = ds.channels;
        int pcmEncoding = AudioFormat.ENCODING_PCM_16BIT;
        File temp = File.createTempFile("silence_looper_", ".pcm", context.getCacheDir());
        long bytesWritten = 0L;
        MediaCodec.BufferInfo info = new MediaCodec.BufferInfo();
        boolean inputDone = false;
        boolean outputDone = false;
        byte[] scratch = new byte[64 * 1024];

        try (OutputStream out = new BufferedOutputStream(new FileOutputStream(temp), 128 * 1024)) {
            while (!outputDone) {
                if (!inputDone) {
                    int inIndex = ds.codec.dequeueInputBuffer(10000);
                    if (inIndex >= 0) {
                        ByteBuffer input = ds.codec.getInputBuffer(inIndex);
                        if (input != null) {
                            input.clear();
                            int size = ds.extractor.readSampleData(input, 0);
                            if (size < 0) {
                                ds.codec.queueInputBuffer(inIndex, 0, 0, 0,
                                        MediaCodec.BUFFER_FLAG_END_OF_STREAM);
                                inputDone = true;
                            } else {
                                ds.codec.queueInputBuffer(inIndex, 0, size,
                                        ds.extractor.getSampleTime(), 0);
                                ds.extractor.advance();
                            }
                        }
                    }
                }

                int outIndex = ds.codec.dequeueOutputBuffer(info, 10000);
                if (outIndex >= 0) {
                    ByteBuffer output = ds.codec.getOutputBuffer(outIndex);
                    if (output != null && info.size > 0) {
                        ByteBuffer view = output.duplicate();
                        view.position(info.offset);
                        view.limit(info.offset + info.size);
                        view = view.slice();

                        if (pcmEncoding == AudioFormat.ENCODING_PCM_FLOAT) {
                            view.order(ByteOrder.LITTLE_ENDIAN);
                            int floats = view.remaining() / 4;
                            byte[] converted = new byte[floats * 2];
                            int p = 0;
                            for (int i = 0; i < floats; i++) {
                                float f = Math.max(-1f, Math.min(1f, view.getFloat()));
                                short v = (short) Math.round(f * 32767f);
                                converted[p++] = (byte) (v & 0xff);
                                converted[p++] = (byte) ((v >> 8) & 0xff);
                            }
                            out.write(converted);
                            bytesWritten += converted.length;
                        } else {
                            while (view.hasRemaining()) {
                                int n = Math.min(scratch.length, view.remaining());
                                view.get(scratch, 0, n);
                                out.write(scratch, 0, n);
                                bytesWritten += n;
                            }
                        }
                    }
                    outputDone = (info.flags & MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0;
                    ds.codec.releaseOutputBuffer(outIndex, false);
                } else if (outIndex == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    MediaFormat of = ds.codec.getOutputFormat();
                    if (of.containsKey(MediaFormat.KEY_SAMPLE_RATE)) {
                        sampleRate = of.getInteger(MediaFormat.KEY_SAMPLE_RATE);
                    }
                    if (of.containsKey(MediaFormat.KEY_CHANNEL_COUNT)) {
                        channels = of.getInteger(MediaFormat.KEY_CHANNEL_COUNT);
                    }
                    if (android.os.Build.VERSION.SDK_INT >= 24
                            && of.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
                        pcmEncoding = of.getInteger(MediaFormat.KEY_PCM_ENCODING);
                        if (pcmEncoding != AudioFormat.ENCODING_PCM_16BIT
                                && pcmEncoding != AudioFormat.ENCODING_PCM_FLOAT) {
                            throw new IllegalArgumentException(
                                    "Formato PCM descodificado não suportado neste dispositivo.");
                        }
                    }
                }
            }
            out.flush();
        } catch (Throwable e) {
            try { temp.delete(); } catch (Exception ignored) {}
            if (e instanceof Exception) throw (Exception) e;
            throw new RuntimeException(e);
        } finally {
            ds.close();
        }

        long frameBytes = Math.max(1L, channels * 2L);
        long totalFrames = bytesWritten / frameBytes;
        return new PcmFile(temp, sampleRate, channels, totalFrames);
    }

    private static void validatePcm16(MediaFormat format) {
        if (android.os.Build.VERSION.SDK_INT >= 24
                && format.containsKey(MediaFormat.KEY_PCM_ENCODING)) {
            int enc = format.getInteger(MediaFormat.KEY_PCM_ENCODING);
            if (enc != AudioFormat.ENCODING_PCM_16BIT) {
                throw new IllegalArgumentException(
                        "PCM descodificado não é 16-bit neste dispositivo.");
            }
        }
    }

    private static DecoderState openDecoder(Context context, Uri uri) throws Exception {
        MediaExtractor ex = new MediaExtractor();
        ex.setDataSource(context, uri, null);
        int track = -1;
        MediaFormat format = null;
        for (int i = 0; i < ex.getTrackCount(); i++) {
            MediaFormat f = ex.getTrackFormat(i);
            String mime = f.getString(MediaFormat.KEY_MIME);
            if (mime != null && mime.startsWith("audio/")) {
                track = i;
                format = f;
                break;
            }
        }
        if (track < 0 || format == null) {
            ex.release();
            throw new IllegalArgumentException(
                    "O ficheiro não contém uma faixa de áudio suportada.");
        }
        ex.selectTrack(track);
        String mime = format.getString(MediaFormat.KEY_MIME);
        int sr = format.containsKey(MediaFormat.KEY_SAMPLE_RATE)
                ? format.getInteger(MediaFormat.KEY_SAMPLE_RATE) : 44100;
        int ch = format.containsKey(MediaFormat.KEY_CHANNEL_COUNT)
                ? format.getInteger(MediaFormat.KEY_CHANNEL_COUNT) : 1;
        long durationUs = format.containsKey(MediaFormat.KEY_DURATION)
                ? format.getLong(MediaFormat.KEY_DURATION) : -1L;

        MediaCodec codec = MediaCodec.createDecoderByType(mime);
        if (android.os.Build.VERSION.SDK_INT >= 24) {
            try { format.setInteger(MediaFormat.KEY_PCM_ENCODING, AudioFormat.ENCODING_PCM_16BIT); }
            catch (Exception ignored) {}
        }
        codec.configure(format, null, null, 0);
        codec.start();
        return new DecoderState(ex, codec, sr, ch, durationUs);
    }

    private static final class DecoderState {
        final MediaExtractor extractor;
        final MediaCodec codec;
        final int sampleRate;
        final int channels;
        final long durationUs;

        DecoderState(MediaExtractor extractor, MediaCodec codec,
                     int sampleRate, int channels, long durationUs) {
            this.extractor = extractor;
            this.codec = codec;
            this.sampleRate = sampleRate;
            this.channels = channels;
            this.durationUs = durationUs;
        }

        void close() {
            try { codec.stop(); } catch (Throwable ignored) {}
            try { codec.release(); } catch (Throwable ignored) {}
            try { extractor.release(); } catch (Throwable ignored) {}
        }
    }
}
