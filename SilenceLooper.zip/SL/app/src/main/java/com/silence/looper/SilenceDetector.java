package com.silence.looper;

import android.content.Context;
import android.net.Uri;

/** Motor de deteção de silêncio da aplicação. */
public final class SilenceDetector {
    private SilenceDetector() {}

    public static AudioDecoder.AnalysisResult analyze(
            Context context, Uri uri, int silenceSeconds, int thresholdDb,
            long knownDurationMs, boolean reliableRandomAccess) throws Exception {
        return AudioDecoder.analyzeParallelFast(
                context, uri, silenceSeconds, thresholdDb,
                knownDurationMs, reliableRandomAccess);
    }
}
