package com.silence.looper;

import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.view.MotionEvent;
import android.view.View;

/**
 * Mantém o toque simples normal e transforma uma pressão longa numa repetição
 * progressivamente mais rápida. Útil para navegar por listas longas sem depender
 * da precisão de uma SeekBar.
 */
public final class HoldRepeatTouchListener implements View.OnTouchListener {
    private static final long INITIAL_DELAY_MS = 450L;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final Runnable repeatedAction;

    private View pressedView;
    private long pressedAtMs;
    private boolean pressed;
    private boolean repeated;

    private final Runnable repeater = new Runnable() {
        @Override public void run() {
            if (!pressed) return;

            repeated = true;
            repeatedAction.run();

            long elapsed = SystemClock.uptimeMillis() - pressedAtMs;
            long interval;
            if (elapsed < 1400L) {
                interval = 190L;
            } else if (elapsed < 2800L) {
                interval = 115L;
            } else if (elapsed < 4500L) {
                interval = 75L;
            } else {
                interval = 50L;
            }
            handler.postDelayed(this, interval);
        }
    };

    public HoldRepeatTouchListener(Runnable repeatedAction) {
        this.repeatedAction = repeatedAction;
    }

    @Override
    public boolean onTouch(View v, MotionEvent event) {
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                cancelPending();
                pressedView = v;
                pressed = true;
                repeated = false;
                pressedAtMs = SystemClock.uptimeMillis();
                v.setPressed(true);
                handler.postDelayed(repeater, INITIAL_DELAY_MS);
                return true;

            case MotionEvent.ACTION_UP:
                boolean wasRepeated = repeated;
                cancelPending();
                v.setPressed(false);
                if (!wasRepeated) {
                    // Preserva o comportamento normal do botão, incluindo
                    // acessibilidade e o OnClickListener já configurado.
                    v.performClick();
                }
                return true;

            case MotionEvent.ACTION_CANCEL:
                cancelPending();
                v.setPressed(false);
                return true;

            default:
                return true;
        }
    }

    private void cancelPending() {
        pressed = false;
        handler.removeCallbacks(repeater);
        if (pressedView != null) {
            pressedView.setPressed(false);
            pressedView = null;
        }
    }
}
