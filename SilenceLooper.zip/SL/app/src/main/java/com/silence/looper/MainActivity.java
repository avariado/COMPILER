package com.silence.looper;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.database.Cursor;
import android.content.res.AssetFileDescriptor;
import android.media.MediaMetadataRetriever;
import android.media.MediaExtractor;
import android.media.MediaFormat;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.os.Handler;
import android.os.Looper;
import android.os.SystemClock;
import android.system.Os;
import android.system.OsConstants;
import android.provider.OpenableColumns;
import android.provider.MediaStore;
import android.provider.Settings;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.LinearLayout;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.Nullable;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.appcompat.app.AppCompatActivity;
import androidx.media3.common.C;
import androidx.media3.common.MediaItem;
import androidx.media3.common.Player;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.source.DefaultMediaSourceFactory;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.extractor.DefaultExtractorsFactory;
import androidx.media3.extractor.mp4.FragmentedMp4Extractor;

import java.io.File;
import java.io.FileDescriptor;
import java.io.FileOutputStream;
import java.io.FileInputStream;
import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.nio.channels.FileChannel;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

@UnstableApi
public class MainActivity extends AppCompatActivity {
    private static final int REQ_OPEN = 1001;
    private static final int REQ_SAVE = 1002;
    private static final int REQ_NOTIFICATIONS = 1003;
    private static final long BUILT_IN_END_PADDING_MS = 200L;
    // Limite defensivo para a leitura rápida do cabeçalho ISO-BMFF. Um
    // content:// pode ser um pipe: nesse caso não é possível usar pread(), mas
    // os MP4 "fast start" colocam o moov no princípio do fluxo.
    private static final long MAX_MP4_HEADER_SCAN_BYTES = 16L * 1024L * 1024L;
    private static final int MAX_MOOV_BYTES = 8 * 1024 * 1024;
    private static final String SYMBOL_PREVIOUS = "⏮";
    private static final String SYMBOL_PLAY = "▶";
    private static final String SYMBOL_PAUSE = "⏸";
    private static final String SYMBOL_STOP = "■";
    private static final String SYMBOL_NEXT = "⏭";
    private static final long HEADPHONE_KEEP_ALIVE_PREROLL_MS = 500L;

    private TextView txtFile, txtSpeed, txtDb, txtStatus, txtPosition, txtSegments;
    private SeekBar seekSpeed, seekDb, seekPosition;
    private Spinner spnSilenceSeconds, spnRepeats, spnRepeatPause, spnOutputFormat,
            spnStartCorrection, spnEndCorrection;
    private Button btnOpen, btnAnalyze, btnPrevious, btnPlay, btnStop, btnNext, btnSave;
    private Button btnModeReading, btnModeAudio;
    private CheckBox chkHeadphoneKeepAlive;
    private LinearLayout panelReading, panelAudio;
    private ReadingController readingController;
    private HeadphoneKeepAlivePlayer headphoneKeepAlivePlayer;

    private Uri sourceUri;
    private Uri playbackUri;
    private File playbackCacheFile;
    private AudioDecoder.PcmFile decodedPcmFile;
    private List<AudioDecoder.Segment> baseSegments = new ArrayList<>();
    private List<AudioDecoder.Segment> segments = new ArrayList<>();
    private ExoPlayer player;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private int currentSegment = 0;
    private int currentRepeat = 0;
    private boolean sequencePlaying = false;
    private boolean userSeeking = false;
    private boolean pendingSaveMp3 = false;
    private boolean waitingInterItemPause = false;
    private boolean userPaused = false;
    private boolean wholeFilePlayback = false;
    private boolean sourceIsVideoContainer = false;
    private long pendingWholeFileStartMs = -1L;
    private long pendingUserSeekMs = -1L;
    private long pendingUserSeekStartedAtMs = 0L;

    private long sourceDurationMs = 0L;
    private long currentClipStartMs = 0L;
    private long currentClipEndMs = 0L;
    private long interItemPauseDueAtMs = 0L;
    private long interItemPauseRemainingMs = 0L;

    private final Runnable interItemPauseRunnable = new Runnable() {
        @Override public void run() {
            if (userPaused) return;
            waitingInterItemPause = false;
            interItemPauseDueAtMs = 0L;
            interItemPauseRemainingMs = 0L;
            if (sequencePlaying && player != null && currentSegment < segments.size()) {
                startCurrentSegment();
            }
        }
    };

    private final Runnable playbackWatcher = new Runnable() {
        @Override public void run() {
            try {
                updatePlaybackPositionFromPlayer();
            } catch (Throwable ignored) {
            } finally {
                handler.postDelayed(this, 100L);
            }
        }
    };

    private void restartPlaybackWatcher() {
        handler.removeCallbacks(playbackWatcher);
        handler.post(playbackWatcher);
    }

    private long resolvePlayerDurationMs() {
        // Num MediaItem recortado, getDuration() é a duração do trecho.
        // Nunca a podemos guardar como duração total da fonte.
        if (!wholeFilePlayback && !segments.isEmpty()) {
            return Math.max(0L, sourceDurationMs);
        }
        if (player != null) {
            try {
                long d = player.getDuration();
                if (d != C.TIME_UNSET && d > 0L) {
                    sourceDurationMs = d;
                    return d;
                }
            } catch (Exception ignored) {}
        }
        return Math.max(0L, sourceDurationMs);
    }

    private void updatePlaybackPositionFromPlayer() {
        if (player == null) return;

        long duration = wholeFilePlayback ? resolvePlayerDurationMs() : Math.max(0L, sourceDurationMs);
        long playerPosition;
        try {
            playerPosition = Math.max(0L, player.getCurrentPosition());
        } catch (Exception e) {
            return;
        }

        long absolutePosition = wholeFilePlayback
                ? playerPosition
                : Math.max(0L, currentClipStartMs + playerPosition);

        if (duration > 0L) {
            absolutePosition = Math.min(absolutePosition, duration);

            // Depois de o utilizador largar o slider, o seek do ExoPlayer pode
            // demorar alguns instantes a refletir-se em getCurrentPosition().
            // Enquanto isso acontece, mantemos visualmente a posição escolhida
            // em vez de deixar o watcher puxar o slider de volta para trás.
            if (wholeFilePlayback && pendingUserSeekMs >= 0L) {
                long now = SystemClock.uptimeMillis();
                long diff = Math.abs(playerPosition - pendingUserSeekMs);
                if (diff <= 750L || now - pendingUserSeekStartedAtMs >= 2500L) {
                    pendingUserSeekMs = -1L;
                    pendingUserSeekStartedAtMs = 0L;
                    userSeeking = false;
                } else {
                    long shown = Math.min(pendingUserSeekMs, duration);
                    seekPosition.setProgress((int) Math.min(1000L,
                            shown * 1000L / Math.max(1L, duration)));
                    txtPosition.setText(formatMs(shown) + " / " + formatMs(duration));
                    return;
                }
            }

            if (!userSeeking) {
                seekPosition.setProgress((int) Math.min(1000L,
                        absolutePosition * 1000L / Math.max(1L, duration)));
            }
            txtPosition.setText(formatMs(absolutePosition) + " / " + formatMs(duration));
        } else if (wholeFilePlayback) {
            // Mesmo antes de a duração total estar disponível, o relógio atual
            // deve avançar e refletir a posição real do ExoPlayer.
            txtPosition.setText(formatMs(absolutePosition) + " / --:--");
        }
    }

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        bindViews();
        headphoneKeepAlivePlayer = new HeadphoneKeepAlivePlayer(this);
        setupSpinners();
        setupControls();
        readingController = new ReadingController(this);
        switchMode(true);
        requestNotificationPermissionIfNeeded();
        restartPlaybackWatcher();
    }

    private void bindViews() {
        btnModeReading = findViewById(R.id.btnModeReading);
        btnModeAudio = findViewById(R.id.btnModeAudio);
        panelReading = findViewById(R.id.panelReading);
        panelAudio = findViewById(R.id.panelAudio);
        chkHeadphoneKeepAlive = findViewById(R.id.chkHeadphoneKeepAlive);
        txtFile = findViewById(R.id.txtFile);
        txtSpeed = findViewById(R.id.txtSpeed);
        txtDb = findViewById(R.id.txtDb);
        txtStatus = findViewById(R.id.txtStatus);
        txtPosition = findViewById(R.id.txtPosition);
        txtSegments = findViewById(R.id.txtSegments);
        seekSpeed = findViewById(R.id.seekSpeed);
        seekDb = findViewById(R.id.seekDb);
        seekPosition = findViewById(R.id.seekPosition);
        spnSilenceSeconds = findViewById(R.id.spnSilenceSeconds);
        spnRepeats = findViewById(R.id.spnRepeats);
        spnRepeatPause = findViewById(R.id.spnRepeatPause);
        spnOutputFormat = findViewById(R.id.spnOutputFormat);
        spnStartCorrection = findViewById(R.id.spnStartCorrection);
        spnEndCorrection = findViewById(R.id.spnEndCorrection);
        btnOpen = findViewById(R.id.btnOpen);
        btnAnalyze = findViewById(R.id.btnAnalyze);
        btnPrevious = findViewById(R.id.btnPrevious);
        btnPlay = findViewById(R.id.btnPlay);
        btnStop = findViewById(R.id.btnStop);
        btnNext = findViewById(R.id.btnNext);
        btnSave = findViewById(R.id.btnSave);
    }

    private void setupSpinners() {
        spnSilenceSeconds.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 segundo", "2 segundos", "3 segundos"}));
        spnSilenceSeconds.setSelection(0);

        spnRepeats.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 vez", "2 vezes", "3 vezes"}));
        spnRepeats.setSelection(1);

        String[] pauses = new String[10];
        for (int i = 0; i < pauses.length; i++) {
            pauses[i] = (i + 1) + ((i + 1) == 1 ? " segundo" : " segundos");
        }
        spnRepeatPause.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, pauses));
        spnRepeatPause.setSelection(1);

        spnOutputFormat.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"MP3 (192 kbps)", "WAV"}));
        spnOutputFormat.setSelection(0);

        String[] corrections = new String[21];
        for (int i = 0; i < corrections.length; i++) {
            double v = (i - 10) / 10.0;
            corrections[i] = String.format(Locale.getDefault(), "%+.1f s", v);
        }
        spnStartCorrection.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, corrections));
        spnEndCorrection.setAdapter(new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, corrections));
        spnStartCorrection.setSelection(10);
        spnEndCorrection.setSelection(10);
    }

    private void setupControls() {
        btnModeReading.setOnClickListener(v -> switchMode(true));
        btnModeAudio.setOnClickListener(v -> switchMode(false));

        boolean antiCutEnabled = getSharedPreferences("playback_prefs", MODE_PRIVATE)
                .getBoolean("headphone_anti_cut", false);
        chkHeadphoneKeepAlive.setChecked(antiCutEnabled);
        chkHeadphoneKeepAlive.setOnCheckedChangeListener((buttonView, isChecked) -> {
            getSharedPreferences("playback_prefs", MODE_PRIVATE).edit()
                    .putBoolean("headphone_anti_cut", isChecked)
                    .apply();
            if (!isChecked) {
                stopHeadphoneKeepAlive();
            } else if ((sequencePlaying && !userPaused)
                    || (readingController != null && readingController.isPlaybackActive())) {
                startHeadphoneKeepAliveIfEnabled();
            }
        });

        btnPrevious.setText(SYMBOL_PREVIOUS);
        btnPlay.setText(SYMBOL_PLAY);
        btnStop.setText(SYMBOL_STOP);
        btnNext.setText(SYMBOL_NEXT);
        btnPrevious.setContentDescription("Trecho anterior");
        btnPlay.setContentDescription("Reproduzir / pausar");
        btnStop.setContentDescription("Parar");
        btnNext.setContentDescription("Trecho seguinte");

        btnOpen.setOnClickListener(v -> openFile());
        btnAnalyze.setOnClickListener(v -> analyze());
        btnPrevious.setOnClickListener(v -> changeAudioSegment(-1));
        btnPlay.setOnClickListener(v -> togglePlayPause());
        btnStop.setOnClickListener(v -> stopPlayback());
        btnNext.setOnClickListener(v -> changeAudioSegment(1));
        btnSave.setOnClickListener(v -> requestSave());

        // Toque simples = um trecho. Pressão longa = navegação acelerada,
        // com repetição progressivamente mais rápida enquanto o botão estiver premido.
        btnPrevious.setOnTouchListener(
                new HoldRepeatTouchListener(() -> changeAudioSegment(-1)));
        btnNext.setOnTouchListener(
                new HoldRepeatTouchListener(() -> changeAudioSegment(1)));

        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                txtSpeed.setText(String.format(Locale.getDefault(), "%.2f×", getSpeed()));
                applySpeed();
            }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) {}
        });

        seekDb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                txtDb.setText("-" + p + " dB");
            }
            @Override public void onStartTrackingTouch(SeekBar b) {}
            @Override public void onStopTrackingTouch(SeekBar b) {}
        });

        AdapterView.OnItemSelectedListener correctionListener =
                new AdapterView.OnItemSelectedListener() {
                    @Override public void onItemSelected(
                            AdapterView<?> parent, android.view.View view, int position, long id) {
                        if (!baseSegments.isEmpty() && sourceDurationMs > 0L) {
                            stopPlayback();
                            applySegmentCorrections();
                            txtStatus.setText("Correções aplicadas aos trechos.");
                        }
                    }

                    @Override public void onNothingSelected(AdapterView<?> parent) {}
                };
        spnStartCorrection.setOnItemSelectedListener(correctionListener);
        spnEndCorrection.setOnItemSelectedListener(correctionListener);

        seekPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar b, int p, boolean fromUser) {
                if (!fromUser) return;

                long duration = resolvePlayerDurationMs();
                if (duration > 0L) {
                    long target = duration * p / 1000L;
                    txtPosition.setText(formatMs(target) + " / " + formatMs(duration));
                }
            }

            @Override public void onStartTrackingTouch(SeekBar b) {
                userSeeking = true;
                cancelInterItemPause();
            }

            @Override public void onStopTrackingTouch(SeekBar b) {
                long duration = resolvePlayerDurationMs();
                if (duration <= 0L) {
                    userSeeking = false;
                    toast("A duração ainda está a ser lida. Tente novamente dentro de instantes.");
                    return;
                }

                long target = duration * b.getProgress() / 1000L;
                if (segments.isEmpty()) {
                    if (wholeFilePlayback && player != null) {
                        long safeTarget = Math.max(0L, Math.min(target, Math.max(0L, duration - 1L)));
                        pendingUserSeekMs = safeTarget;
                        pendingUserSeekStartedAtMs = SystemClock.uptimeMillis();
                        userSeeking = true;
                        seekPosition.setProgress((int) Math.min(1000L,
                                safeTarget * 1000L / Math.max(1L, duration)));
                        txtPosition.setText(formatMs(safeTarget) + " / " + formatMs(duration));
                        try { player.seekTo(safeTarget); } catch (Exception ignored) {
                            pendingUserSeekMs = -1L;
                            pendingUserSeekStartedAtMs = 0L;
                            userSeeking = false;
                        }
                        applySpeed();
                        if (sequencePlaying && !userPaused) player.play();
                        restartPlaybackWatcher();
                        txtStatus.setText(userPaused
                                ? "Reprodução em pausa."
                                : "Reprodução contínua — "
                                + String.format(Locale.getDefault(), "%.2f×", getSpeed()) + ".");
                    } else {
                        playWholeFile(target);
                    }
                    return;
                }

                userSeeking = false;
                pendingUserSeekMs = -1L;
                pendingUserSeekStartedAtMs = 0L;
                int idx = findSegmentForPosition(target);
                if (idx < 0) return;

                wholeFilePlayback = false;
                currentSegment = idx;
                currentRepeat = 0;
                sequencePlaying = true;
                userPaused = false;
                waitingInterItemPause = false;
                updatePlayButton();
                setPlaybackScreenOn(true);
                startBackgroundPlaybackSupport();
                long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();

                AudioDecoder.Segment seg = segments.get(currentSegment);
                long start = Math.max(seg.startMs, Math.min(target, seg.endMs - 1L));
                if (target < seg.startMs || target >= seg.endMs) start = seg.startMs;
                final long clipStart = start;
                final long clipEnd = seg.endMs;
                if (antiCutDelay > 0L) {
                    handler.postDelayed(() -> {
                        if (sequencePlaying && !userPaused) startClip(clipStart, clipEnd);
                    }, antiCutDelay);
                } else {
                    startClip(clipStart, clipEnd);
                }
            }
        });
    }

    public void setPlaybackScreenOn(boolean keepOn) {
        if (keepOn) {
            getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void switchMode(boolean reading) {
        if (reading) {
            stopPlayback();
            panelReading.setVisibility(View.VISIBLE);
            panelAudio.setVisibility(View.GONE);
            btnModeReading.setSelected(true);
            btnModeAudio.setSelected(false);
            btnModeReading.setEnabled(true);
            btnModeAudio.setEnabled(true);
        } else {
            if (readingController != null) readingController.stop();
            panelReading.setVisibility(View.GONE);
            panelAudio.setVisibility(View.VISIBLE);
            btnModeReading.setSelected(false);
            btnModeAudio.setSelected(true);
            btnModeReading.setEnabled(true);
            btnModeAudio.setEnabled(true);
        }
    }

    private void openFile() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{"audio/*", "video/*"});
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        startActivityForResult(Intent.createChooser(i, "Abrir ficheiro com"), REQ_OPEN);
    }

    private void analyze() {
        if (sourceUri == null) {
            toast("Selecione primeiro um ficheiro.");
            return;
        }

        stopPlayback();
        setBusy(true);
        txtStatus.setText(sourceIsVideoContainer
                ? "A criar acesso local rápido para a análise…"
                : "A detetar silêncios…");
        txtSegments.setText("Trechos detetados: …");

        final int silenceSeconds = spnSilenceSeconds.getSelectedItemPosition() + 1;
        final int thresholdDb = -seekDb.getProgress();
        final long knownDurationMs = sourceDurationMs;
        final Uri sourceAtStart = sourceUri;
        final boolean copyForRandomAccess = sourceIsVideoContainer;
        final long started = SystemClock.elapsedRealtime();

        executor.execute(() -> {
            File analysisCopy = null;
            try {
                Uri analysisUri = sourceAtStart;
                if (copyForRandomAccess) {
                    analysisCopy = copySourceForAnalysis(sourceAtStart);
                    analysisUri = Uri.fromFile(analysisCopy);
                    runOnUiThread(() -> {
                        if (sourceAtStart.equals(sourceUri)) {
                            txtStatus.setText("A detetar silêncios…");
                        }
                    });
                }
                AudioDecoder.AnalysisResult ar = SilenceDetector.analyze(
                        this, analysisUri, silenceSeconds, thresholdDb,
                        knownDurationMs, copyForRandomAccess);
                final double elapsedSeconds =
                        (SystemClock.elapsedRealtime() - started) / 1000.0;

                runOnUiThread(() -> {
                    clearDecodedPcmCache();
                    baseSegments = new ArrayList<>(ar.segments);
                    sourceDurationMs = ar.durationMs;
                    applySegmentCorrections();
                    currentClipStartMs = 0L;
                    currentClipEndMs = 0L;
                    seekPosition.setProgress(0);
                    txtPosition.setText("00:00 / " + formatMs(sourceDurationMs));
                    txtSegments.setText("Trechos detetados: " + segments.size());
                    txtStatus.setText("Deteção concluída em "
                            + String.format(Locale.getDefault(), "%.1f s", elapsedSeconds)
                            + " — motor: " + ar.engine
                            + " — " + ar.sampleRate + " Hz, " + ar.channels
                            + " canal(is), " + formatMs(ar.durationMs) + ".");
                    setBusy(false);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    txtSegments.setText("Trechos detetados: 0");
                    String msg = e.getMessage();
                    if (msg == null || msg.trim().isEmpty()) {
                        msg = e.getClass().getSimpleName();
                    }
                    txtStatus.setText("Erro na análise: " + msg);
                    setBusy(false);
                });
            } finally {
                if (analysisCopy != null) {
                    try { analysisCopy.delete(); } catch (Exception ignored) {}
                }
            }
        });
    }

    private File copySourceForAnalysis(Uri uri) throws Exception {
        File out = new File(getCacheDir(), "silence_analysis_source.mp4");
        if (out.exists() && !out.delete()) {
            throw new IllegalStateException("Não foi possível substituir a cópia temporária da análise.");
        }
        try (InputStream in = getContentResolver().openInputStream(uri);
             OutputStream os = new FileOutputStream(out, false)) {
            if (in == null) throw new IllegalStateException("Não foi possível abrir o MP4 para análise.");
            byte[] buffer = new byte[1024 * 1024];
            int n;
            while ((n = in.read(buffer)) >= 0) {
                if (n > 0) os.write(buffer, 0, n);
            }
            os.flush();
        } catch (Throwable e) {
            try { out.delete(); } catch (Exception ignored) {}
            if (e instanceof Exception) throw (Exception) e;
            throw new Exception(e);
        }
        return out;
    }

    private void ensurePlayer() {
        if (player != null) return;
        DefaultExtractorsFactory extractorsFactory = new DefaultExtractorsFactory()
                .setFragmentedMp4ExtractorFlags(
                        FragmentedMp4Extractor.FLAG_READ_MFRA_FOR_SEEK_MAP);
        player = new ExoPlayer.Builder(this)
                .setMediaSourceFactory(
                        new DefaultMediaSourceFactory(this, extractorsFactory))
                .setWakeMode(C.WAKE_MODE_LOCAL)
                .build();
        // A aplicação só precisa do áudio. Desativar a faixa de vídeo evita
        // descodificação desnecessária e permite usar diretamente o índice do MP4.
        player.setTrackSelectionParameters(
                player.getTrackSelectionParameters()
                        .buildUpon()
                        .setTrackTypeDisabled(C.TRACK_TYPE_VIDEO, true)
                        .build());
        player.addListener(new Player.Listener() {
            @Override public void onPlaybackStateChanged(int playbackState) {
                if (playbackState == Player.STATE_READY) {
                    long duration = resolvePlayerDurationMs();
                    if (duration > 0L && sourceUri != null) {
                        sourceDurationMs = duration;
                        if (!sequencePlaying && !userSeeking) {
                            seekPosition.setProgress(0);
                            txtPosition.setText("00:00 / " + formatMs(duration));
                        }
                    }

                    if (wholeFilePlayback && pendingWholeFileStartMs >= 0L) {
                        long target = pendingWholeFileStartMs;
                        if (duration > 0L) {
                            target = Math.min(target, Math.max(0L, duration - 1L));
                        }
                        pendingWholeFileStartMs = -1L;
                        try { player.seekTo(Math.max(0L, target)); } catch (Exception ignored) {}
                    }

                    updatePlaybackPositionFromPlayer();
                    restartPlaybackWatcher();
                }
                if (playbackState == Player.STATE_ENDED
                        && sequencePlaying
                        && !userPaused
                        && !waitingInterItemPause) {
                    if (wholeFilePlayback) {
                        handler.post(MainActivity.this::finishWholeFilePlayback);
                    } else {
                        handler.post(MainActivity.this::advanceSequence);
                    }
                }
            }
        });
        applySpeed();
    }

    private void togglePlayPause() {
        if (sequencePlaying) {
            pauseOrResume();
        } else {
            playSequence();
        }
    }

    private void updatePlayButton() {
        btnPlay.setText(sequencePlaying && !userPaused ? SYMBOL_PAUSE : SYMBOL_PLAY);
    }

    private void changeAudioSegment(int delta) {
        if (segments.isEmpty()) {
            toast("Execute primeiro a deteção dos silêncios.");
            return;
        }

        int next = Math.max(0, Math.min(segments.size() - 1, currentSegment + delta));
        if (next == currentSegment) return;

        boolean active = sequencePlaying;
        boolean paused = userPaused;
        cancelInterItemPause();
        if (player != null) {
            try { player.pause(); } catch (Exception ignored) {}
        }
        currentSegment = next;
        currentRepeat = 0;

        AudioDecoder.Segment seg = segments.get(currentSegment);
        long position = seg.startMs;
        seekPosition.setProgress((int) (position * 1000L / Math.max(1L, sourceDurationMs)));
        txtPosition.setText(formatMs(position) + " / " + formatMs(sourceDurationMs));

        if (active) {
            sequencePlaying = true;
            userPaused = paused;
            startCurrentSegment();
            if (paused) {
                if (player != null) player.pause();
                txtStatus.setText("Reprodução em pausa — trecho "
                        + (currentSegment + 1) + "/" + segments.size() + ".");
            }
        } else {
            txtStatus.setText("Trecho " + (currentSegment + 1) + "/" + segments.size() + ".");
        }
        updatePlayButton();
    }

    private void playSequence() {
        if (sourceUri == null) {
            toast("Selecione primeiro um ficheiro.");
            return;
        }
        if (segments.isEmpty()) {
            long duration = resolvePlayerDurationMs();
            long start = duration > 0L
                    ? duration * seekPosition.getProgress() / 1000L : 0L;
            playWholeFile(start);
            return;
        }

        wholeFilePlayback = false;
        cancelInterItemPause();
        ensurePlayer();
        if (currentSegment < 0 || currentSegment >= segments.size()) currentSegment = 0;
        currentRepeat = 0;
        sequencePlaying = true;
        userPaused = false;
        updatePlayButton();
        setPlaybackScreenOn(true);
        startBackgroundPlaybackSupport();
        long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
        if (antiCutDelay > 0L) {
            handler.postDelayed(() -> {
                if (sequencePlaying && !userPaused) startCurrentSegment();
            }, antiCutDelay);
        } else {
            startCurrentSegment();
        }
    }

    private void playWholeFile(long startMs) {
        cancelInterItemPause();
        ensurePlayer();
        wholeFilePlayback = true;
        sequencePlaying = true;
        userPaused = false;
        currentClipStartMs = 0L;
        currentClipEndMs = sourceDurationMs;

        long duration = resolvePlayerDurationMs();

        long safeStart = Math.max(0L, startMs);
        if (duration > 0L) {
            safeStart = Math.min(safeStart, Math.max(0L, duration - 1L));
        }

        // Guardamos a posição pretendida e voltamos a aplicá-la quando o ExoPlayer
        // entrar em STATE_READY. Isto evita fornecedores content:// que ignoram a
        // posição inicial durante a preparação do MediaItem.
        pendingWholeFileStartMs = safeStart;
        pendingUserSeekMs = -1L;
        pendingUserSeekStartedAtMs = 0L;
        userSeeking = false;
        MediaItem item = new MediaItem.Builder().setUri(getPlaybackUri()).build();
        player.setMediaItem(item);
        player.prepare();
        applySpeed();
        try { player.seekTo(safeStart); } catch (Exception ignored) {}
        updatePlayButton();
        setPlaybackScreenOn(true);
        startBackgroundPlaybackSupport();
        long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
        restartPlaybackWatcher();
        txtStatus.setText("Reprodução contínua — "
                + String.format(Locale.getDefault(), "%.2f×", getSpeed()) + ".");
        if (antiCutDelay > 0L) {
            handler.postDelayed(() -> {
                if (sequencePlaying && !userPaused && wholeFilePlayback && player != null) {
                    applySpeed();
                    player.play();
                }
            }, antiCutDelay);
        } else {
            player.play();
        }
    }

    private void finishWholeFilePlayback() {
        sequencePlaying = false;
        userPaused = false;
        wholeFilePlayback = false;
        pendingWholeFileStartMs = -1L;
        updatePlayButton();
        setPlaybackScreenOn(false);
        stopBackgroundPlaybackSupport();
        stopHeadphoneKeepAlive();
        seekPosition.setProgress(0);
        txtPosition.setText("00:00 / " + formatMs(sourceDurationMs));
        txtStatus.setText("Reprodução concluída.");
    }

    private void startCurrentSegment() {
        if (segments.isEmpty() || currentSegment < 0 || currentSegment >= segments.size()) return;
        AudioDecoder.Segment seg = segments.get(currentSegment);
        startClip(seg.startMs, seg.endMs);
    }

    private void startClip(long startMs, long endMs) {
        if (sourceUri == null || endMs <= startMs) return;
        ensurePlayer();
        waitingInterItemPause = false;

        currentClipStartMs = Math.max(0L, startMs);
        currentClipEndMs = Math.max(currentClipStartMs + 1L, endMs);

        MediaItem.ClippingConfiguration clipping =
                new MediaItem.ClippingConfiguration.Builder()
                        .setStartPositionMs(currentClipStartMs)
                        .setEndPositionMs(currentClipEndMs)
                        .setStartsAtKeyFrame(false)
                        .build();

        MediaItem item = new MediaItem.Builder()
                .setUri(getPlaybackUri())
                .setClippingConfiguration(clipping)
                .build();

        player.setMediaItem(item);
        player.prepare();
        applySpeed();

        txtStatus.setText("Trecho " + (currentSegment + 1) + "/" + segments.size()
                + " — repetição " + (currentRepeat + 1) + "/" + getRepeats());

        if (!userPaused) player.play();
    }

    private void advanceSequence() {
        if (!sequencePlaying || player == null || segments.isEmpty()
                || waitingInterItemPause || userPaused) return;

        player.pause();
        currentRepeat++;
        if (currentRepeat >= getRepeats()) {
            currentRepeat = 0;
            currentSegment++;
        }

        if (currentSegment >= segments.size()) {
            sequencePlaying = false;
            userPaused = false;
            currentSegment = 0;
            currentRepeat = 0;
            updatePlayButton();
            setPlaybackScreenOn(false);
            stopBackgroundPlaybackSupport();
            stopHeadphoneKeepAlive();
            seekPosition.setProgress(0);
            txtPosition.setText("00:00 / " + formatMs(sourceDurationMs));
            txtStatus.setText("Reprodução concluída.");
            return;
        }

        startInterItemPause();
    }

    private void startInterItemPause() {
        cancelInterItemPause();
        waitingInterItemPause = true;
        interItemPauseRemainingMs = getRepeatPauseSeconds() * 1000L;
        updatePauseStatus();
        scheduleInterItemPause(interItemPauseRemainingMs);
    }

    private void scheduleInterItemPause(long delayMs) {
        interItemPauseRemainingMs = Math.max(0L, delayMs);
        interItemPauseDueAtMs = SystemClock.uptimeMillis() + interItemPauseRemainingMs;
        handler.postDelayed(interItemPauseRunnable, interItemPauseRemainingMs);
    }

    private void updatePauseStatus() {
        int seconds = getRepeatPauseSeconds();
        String next;
        if (currentRepeat > 0) {
            next = "repetição " + (currentRepeat + 1) + "/" + getRepeats()
                    + " do trecho " + (currentSegment + 1);
        } else {
            next = "trecho " + (currentSegment + 1) + "/" + segments.size();
        }
        txtStatus.setText("Pausa de " + seconds
                + (seconds == 1 ? " segundo" : " segundos")
                + " — a seguir: " + next + ".");
    }

    private void cancelInterItemPause() {
        handler.removeCallbacks(interItemPauseRunnable);
        waitingInterItemPause = false;
        interItemPauseDueAtMs = 0L;
        interItemPauseRemainingMs = 0L;
    }

    private void pauseOrResume() {
        if (!sequencePlaying || player == null) {
            toast("Não existe reprodução ativa.");
            return;
        }

        if (!userPaused) {
            userPaused = true;
            if (waitingInterItemPause) {
                interItemPauseRemainingMs = Math.max(
                        0L, interItemPauseDueAtMs - SystemClock.uptimeMillis());
                handler.removeCallbacks(interItemPauseRunnable);
            } else {
                player.pause();
            }
            stopBackgroundPlaybackSupport();
            stopHeadphoneKeepAlive();
            setPlaybackScreenOn(false);
            updatePlayButton();
            txtStatus.setText("Reprodução em pausa.");
        } else {
            userPaused = false;
            updatePlayButton();
            setPlaybackScreenOn(true);
            startBackgroundPlaybackSupport();
            long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
            if (waitingInterItemPause) {
                updatePauseStatus();
                scheduleInterItemPause(interItemPauseRemainingMs);
            } else {
                Runnable resumeAudio = () -> {
                    if (!sequencePlaying || userPaused || player == null) return;
                    applySpeed();
                    player.play();
                    if (wholeFilePlayback) {
                        txtStatus.setText("Reprodução contínua — "
                                + String.format(Locale.getDefault(), "%.2f×", getSpeed()) + ".");
                    } else {
                        txtStatus.setText("Trecho " + (currentSegment + 1) + "/" + segments.size()
                                + " — repetição " + (currentRepeat + 1) + "/" + getRepeats());
                    }
                };
                if (antiCutDelay > 0L) handler.postDelayed(resumeAudio, antiCutDelay);
                else resumeAudio.run();
            }
        }
    }

    private void stopPlayback() {
        sequencePlaying = false;
        userPaused = false;
        wholeFilePlayback = false;
        pendingWholeFileStartMs = -1L;
        pendingUserSeekMs = -1L;
        pendingUserSeekStartedAtMs = 0L;
        userSeeking = false;
        currentSegment = 0;
        currentRepeat = 0;
        cancelInterItemPause();
        setPlaybackScreenOn(false);
        stopBackgroundPlaybackSupport();
        stopHeadphoneKeepAlive();
        long durationAtStop = resolvePlayerDurationMs();
        if (durationAtStop > 0L) sourceDurationMs = durationAtStop;
        if (player != null) {
            try {
                player.pause();
                player.seekTo(0L);
                player.stop();
            } catch (Exception ignored) {}
        }
        currentClipStartMs = 0L;
        currentClipEndMs = 0L;
        updatePlayButton();
        seekPosition.setProgress(0);
        txtPosition.setText("00:00 / " + formatMs(sourceDurationMs));
        txtStatus.setText(sourceUri == null
                ? "Abra um ficheiro para começar."
                : "Reprodução parada.");
    }

    private int findSegmentForPosition(long targetMs) {
        if (segments.isEmpty()) return -1;
        for (int i = 0; i < segments.size(); i++) {
            AudioDecoder.Segment s = segments.get(i);
            if (targetMs >= s.startMs && targetMs < s.endMs) return i;
            if (targetMs < s.startMs) return i;
        }
        return segments.size() - 1;
    }

    private void requestSave() {
        if (sourceUri == null) {
            toast("Selecione primeiro um ficheiro.");
            return;
        }
        pendingSaveMp3 = spnOutputFormat.getSelectedItemPosition() == 0;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(pendingSaveMp3 ? "audio/mpeg" : "audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,
                pendingSaveMp3 ? "silence_looper.mp3" : "silence_looper.wav");
        startActivityForResult(i, REQ_SAVE);
    }

    private void exportTo(Uri outUri, boolean mp3) {
        setBusy(true);
        final boolean useDetectedSegments = !segments.isEmpty();
        txtStatus.setText(mp3
                ? (useDetectedSegments
                    ? "A criar MP3 com velocidade, trechos, repetições e pausas…"
                    : "A criar MP3 com a velocidade selecionada…")
                : (useDetectedSegments
                    ? "A criar WAV com velocidade, trechos, repetições e pausas…"
                    : "A criar WAV com a velocidade selecionada…"));

        final int repeats = useDetectedSegments ? getRepeats() : 1;
        final int pauseSeconds = useDetectedSegments ? getRepeatPauseSeconds() : 0;
        final float speed = getSpeed();

        executor.execute(() -> {
            try {
                AudioDecoder.PcmFile audio = decodedPcmFile;
                if (audio == null || audio.file == null || !audio.file.exists()) {
                    audio = AudioDecoder.decodeToPcmFile(this, sourceUri);
                    decodedPcmFile = audio;
                }

                List<AudioDecoder.Segment> exportSegments;
                if (useDetectedSegments) {
                    exportSegments = new ArrayList<>(segments);
                } else {
                    exportSegments = new ArrayList<>();
                    exportSegments.add(new AudioDecoder.Segment(0L, audio.durationMs()));
                }

                if (mp3) {
                    Mp3Exporter.export(this, outUri, audio, exportSegments,
                            repeats, speed, pauseSeconds);
                } else {
                    WavExporter.export(this, outUri, audio, exportSegments,
                            repeats, speed, pauseSeconds);
                }

                runOnUiThread(() -> {
                    txtStatus.setText(mp3
                            ? "MP3 gravado com sucesso."
                            : "WAV gravado com sucesso.");
                    setBusy(false);
                });
            } catch (Throwable e) {
                runOnUiThread(() -> {
                    String msg = e.getMessage();
                    if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
                    txtStatus.setText("Erro ao gravar: " + msg);
                    setBusy(false);
                });
            }
        });
    }

    private void applySpeed() {
        if (player == null) return;
        try { player.setPlaybackSpeed(getSpeed()); } catch (Exception ignored) {}
    }

    private float getSpeed() {
        return 0.5f + seekSpeed.getProgress() / 100f;
    }

    private void applySegmentCorrections() {
        List<AudioDecoder.Segment> corrected = new ArrayList<>();
        long startOffsetMs = Math.round(getStartCorrectionSeconds() * 1000.0);
        // Margem base incorporada: +0,2 s no fim de cada trecho.
        // Assim, a correção visível +0,0 s corresponde ao comportamento
        // que anteriormente exigia selecionar manualmente +0,2 s.
        long endOffsetMs = BUILT_IN_END_PADDING_MS
                + Math.round(getEndCorrectionSeconds() * 1000.0);

        for (AudioDecoder.Segment s : baseSegments) {
            long start = Math.max(0L, Math.min(sourceDurationMs, s.startMs + startOffsetMs));
            long end = Math.max(0L, Math.min(sourceDurationMs, s.endMs + endOffsetMs));

            // Nunca deixamos uma correção inverter ou apagar um trecho.
            if (end <= start + 50L) {
                start = Math.max(0L, Math.min(sourceDurationMs - 51L, s.startMs));
                end = Math.max(start + 51L, Math.min(sourceDurationMs, s.endMs));
            }
            if (end > start) corrected.add(new AudioDecoder.Segment(start, end));
        }

        segments = corrected;
        txtSegments.setText("Trechos detetados: " + segments.size());
    }

    private double getStartCorrectionSeconds() {
        return (spnStartCorrection.getSelectedItemPosition() - 10) / 10.0;
    }

    private double getEndCorrectionSeconds() {
        return (spnEndCorrection.getSelectedItemPosition() - 10) / 10.0;
    }

    private String formatCorrection(double seconds) {
        return String.format(Locale.getDefault(), "%+.1f s", seconds);
    }

    private int getRepeats() {
        return spnRepeats.getSelectedItemPosition() + 1;
    }

    private int getRepeatPauseSeconds() {
        return spnRepeatPause.getSelectedItemPosition() + 1;
    }

    public boolean isHeadphoneKeepAliveEnabled() {
        return chkHeadphoneKeepAlive != null && chkHeadphoneKeepAlive.isChecked();
    }

    public void startHeadphoneKeepAliveIfEnabled() {
        if (!isHeadphoneKeepAliveEnabled() || headphoneKeepAlivePlayer == null) return;
        headphoneKeepAlivePlayer.start();
    }

    public long startHeadphoneKeepAliveAndGetPreRollMs() {
        if (!isHeadphoneKeepAliveEnabled() || headphoneKeepAlivePlayer == null) return 0L;
        boolean alreadyRunning = headphoneKeepAlivePlayer.isRunning();
        headphoneKeepAlivePlayer.start();
        return alreadyRunning ? 0L : HEADPHONE_KEEP_ALIVE_PREROLL_MS;
    }

    public void stopHeadphoneKeepAlive() {
        if (headphoneKeepAlivePlayer != null) headphoneKeepAlivePlayer.stop();
    }

    private void requestNotificationPermissionIfNeeded() {
        if (Build.VERSION.SDK_INT >= 33
                && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.POST_NOTIFICATIONS},
                    REQ_NOTIFICATIONS);
        }
    }

    private void startBackgroundPlaybackSupport() {
        PlaybackForegroundService.start(this);
        requestBatteryOptimizationExemptionOnce();
    }

    private void stopBackgroundPlaybackSupport() {
        PlaybackForegroundService.stop(this);
    }

    private void requestBatteryOptimizationExemptionOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;

        boolean alreadyAsked = getSharedPreferences("playback_prefs", MODE_PRIVATE)
                .getBoolean("battery_exemption_prompted", false);
        if (alreadyAsked) return;

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(getPackageName())) return;

        getSharedPreferences("playback_prefs", MODE_PRIVATE).edit()
                .putBoolean("battery_exemption_prompted", true).apply();
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } catch (Exception ignored) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignoredToo) {}
        }
    }

    private Uri getPlaybackUri() {
        return playbackUri != null ? playbackUri : sourceUri;
    }

    private void clearPlaybackCache() {
        playbackUri = null;
        File old = playbackCacheFile;
        playbackCacheFile = null;
        if (old != null) {
            try { old.delete(); } catch (Exception ignored) {}
        }
    }

    private static String safeExtension(String name) {
        if (name == null) return ".audio";
        int dot = name.lastIndexOf('.');
        if (dot < 0 || dot >= name.length() - 1) return ".audio";
        String ext = name.substring(dot);
        return ext.length() <= 10 ? ext : ".audio";
    }

    private static boolean isVideoContainerForAudioPlayback(String name) {
        if (name == null) return false;
        String lower = name.toLowerCase(Locale.ROOT);
        return lower.endsWith(".mp4") || lower.endsWith(".m4v") || lower.endsWith(".mov");
    }

    /**
     * Prepara a fonte usada pela reprodução interativa. MP4/MOV/M4V usam
     * diretamente o Uri original; para áudio puro mantemos uma cópia local.
     */
    private void prepareLocalPlaybackCopy(Uri originalUri, String displayName) {
        if (isVideoContainerForAudioPlayback(displayName)) {
            // O Media3 usa diretamente o índice mfra/tfra do MP4 original.
            playbackUri = originalUri;
            playbackCacheFile = null;
            sourceDurationMs = 0L;

            txtFile.setText(displayName);
            txtSegments.setText("Trechos detetados: 0");
            seekPosition.setProgress(0);
            seekPosition.setEnabled(false);
            txtPosition.setText("00:00 / --:--");
            txtStatus.setText("MP4 carregado. A ler duração…");
            setBusy(false);

            // Não preparamos o ExoPlayer aqui. Em alguns providers, player.prepare()
            // inicia uma análise longa do MP4 e compete com a leitura rápida da
            // metadata. O player só é preparado quando o utilizador carregar em ▶.

            // A Media3 atual lê diretamente o mfra/tfra do MP4 fragmentado.
            // Não é necessário copiar ou remuxar a faixa para permitir seek.
            final Uri sourceAtStart = originalUri;
            executor.execute(() -> {
                final long quickDuration = readMp4DurationFast(sourceAtStart);
                runOnUiThread(() -> {
                    if (!sourceAtStart.equals(sourceUri)) return;
                    if (quickDuration > 0L && sourceDurationMs <= 0L) {
                        sourceDurationMs = quickDuration;
                    }
                    if (sourceDurationMs > 0L && !sequencePlaying && !userSeeking) {
                        txtPosition.setText("00:00 / " + formatMs(sourceDurationMs));
                    }
                    seekPosition.setEnabled(sourceDurationMs > 0L);
                    txtStatus.setText(sourceDurationMs > 0L
                            ? "MP4 pronto. Pode reproduzir, navegar ou detetar silêncios."
                            : "MP4 carregado, mas não foi possível determinar a duração.");
                });
            });
            return;
        }

        setBusy(true);
        txtStatus.setText("A preparar ficheiro para reprodução…");
        executor.execute(() -> {
            File out = null;
            try {
                String ext = safeExtension(displayName);
                out = new File(getCacheDir(), "audio_playback_source" + ext);
                try (InputStream in = getContentResolver().openInputStream(originalUri);
                     OutputStream os = new FileOutputStream(out, false)) {
                    if (in == null) throw new IllegalStateException("Não foi possível abrir o ficheiro selecionado.");
                    byte[] buffer = new byte[256 * 1024];
                    int n;
                    while ((n = in.read(buffer)) >= 0) {
                        if (n > 0) os.write(buffer, 0, n);
                    }
                    os.flush();
                }

                long duration = probeLocalDurationMs(out);
                final File localFile = out;
                final long localDuration = Math.max(0L, duration);
                runOnUiThread(() -> {
                    if (!originalUri.equals(sourceUri)) {
                        try { localFile.delete(); } catch (Exception ignored) {}
                        return;
                    }
                    clearPlaybackCache();
                    playbackCacheFile = localFile;
                    playbackUri = Uri.fromFile(localFile);
                    sourceDurationMs = localDuration;
                    seekPosition.setEnabled(sourceDurationMs > 0L);
                    txtFile.setText(displayName);
                    txtSegments.setText("Trechos detetados: 0");
                    seekPosition.setProgress(0);
                    txtPosition.setText("00:00 / " + (sourceDurationMs > 0L ? formatMs(sourceDurationMs) : "--:--"));
                    txtStatus.setText("Ficheiro carregado. Pode reproduzir, detetar trechos ou gravar diretamente com a velocidade selecionada.");
                    setBusy(false);
                });
            } catch (Throwable e) {
                if (out != null) { try { out.delete(); } catch (Exception ignored) {} }
                runOnUiThread(() -> {
                    if (!originalUri.equals(sourceUri)) return;
                    clearPlaybackCache();
                    String msg = e.getMessage();
                    if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
                    txtStatus.setText("Erro ao preparar o ficheiro: " + msg);
                    setBusy(false);
                });
            }
        });
    }

    private void clearDecodedPcmCache() {
        AudioDecoder.PcmFile old = decodedPcmFile;
        decodedPcmFile = null;
        if (old != null) old.delete();
    }

    private void setBusy(boolean busy) {
        btnAnalyze.setEnabled(!busy);
        btnOpen.setEnabled(!busy);
        btnSave.setEnabled(!busy);
        btnPrevious.setEnabled(!busy);
        btnPlay.setEnabled(!busy);
        btnStop.setEnabled(!busy);
        btnNext.setEnabled(!busy);
    }

    @Override protected void onActivityResult(
            int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (readingController != null
                && readingController.handleActivityResult(requestCode, resultCode, data)) {
            return;
        }
        if (resultCode != RESULT_OK || data == null || data.getData() == null) return;
        Uri uri = data.getData();

        if (requestCode == REQ_OPEN) {
            sourceUri = uri;
            clearDecodedPcmCache();
            clearPlaybackCache();
            baseSegments.clear();
            segments.clear();
            sourceDurationMs = 0L;
            sequencePlaying = false;
            wholeFilePlayback = false;
            pendingWholeFileStartMs = -1L;
            userPaused = false;
            currentSegment = 0;
            currentRepeat = 0;
            updatePlayButton();
            cancelInterItemPause();
            releasePlayer();

            String displayName = getDisplayName(uri);
            sourceIsVideoContainer = isVideoContainerForAudioPlayback(displayName);
            txtFile.setText(displayName);
            txtSegments.setText("Trechos detetados: 0");
            txtPosition.setText("00:00 / --:--");
            seekPosition.setProgress(0);
            prepareLocalPlaybackCopy(uri, displayName);
        } else if (requestCode == REQ_SAVE) {
            exportTo(uri, pendingSaveMp3);
        }
    }

    /**
     * Obtém a duração de um MP4 sem percorrer o conteúdo multimédia.
     * A via principal usa pread() diretamente no descritor do ficheiro para
     * saltar entre os atoms ISO-BMFF e ler apenas moov/mvhd. Não usa
     * MediaExtractor, MediaMetadataRetriever nem consultas genéricas ao provider.
     */
    private long readMp4DurationFast(Uri uri) {
        if (uri == null) return 0L;

        long direct = readIsoBmffMvhdDurationMsPread(uri);
        if (direct > 0L) return direct;

        // Num MP4 fragmentado, mvhd costuma declarar duração zero. O mfra
        // no fim do ficheiro permite ao MediaExtractor saltar diretamente para
        // o último fragmento; percorremos apenas as últimas amostras AAC.
        long fragmented = readFragmentedMp4DurationMs(uri);
        if (fragmented > 0L) return fragmented;

        // ACTION_GET_CONTENT devolve frequentemente um content:// suportado por
        // pipe. Os.pread()/lseek() falham com ESPIPE nesses descritores, apesar de
        // o cabeçalho moov estar logo no início e poder ser lido imediatamente.
        long streamed = readIsoBmffMvhdDurationMsFromStart(uri);
        if (streamed > 0L) return streamed;

        // Fallback muito restrito apenas para URIs do próprio MediaStore.
        // Nunca fazemos query(null), pois alguns providers calculam metadata
        // pesada e podem bloquear durante muito tempo.
        return queryMediaStoreDurationMs(uri);
    }

    /**
     * Obtém a duração de MP4 fragmentado sem percorrer todos os moof/mdat.
     * SEEK_TO_PREVIOUS_SYNC usa o índice mfra/tfra para abrir o último
     * fragmento. Depois basta contar os timestamps comprimidos desse fragmento.
     */
    private long readFragmentedMp4DurationMs(Uri uri) {
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(this, uri, null);
            int audioTrack = -1;
            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (mime != null && mime.startsWith("audio/")) {
                    audioTrack = i;
                    break;
                }
            }
            if (audioTrack < 0) return 0L;

            extractor.selectTrack(audioTrack);
            extractor.seekTo(Long.MAX_VALUE, MediaExtractor.SEEK_TO_PREVIOUS_SYNC);

            long previousUs = -1L;
            long lastUs = -1L;
            long positiveDeltaSumUs = 0L;
            int positiveDeltaCount = 0;
            int samples = 0;
            while (samples < 200_000) { // limite defensivo; um fragmento é pequeno
                long sampleUs = extractor.getSampleTime();
                if (sampleUs < 0L) break;
                if (previousUs >= 0L && sampleUs > previousUs) {
                    long delta = sampleUs - previousUs;
                    if (delta < 1_000_000L) {
                        positiveDeltaSumUs += delta;
                        positiveDeltaCount++;
                    }
                }
                previousUs = sampleUs;
                lastUs = sampleUs;
                samples++;
                if (!extractor.advance()) break;
            }

            if (lastUs < 0L) return 0L;
            long tailUs = positiveDeltaCount > 0
                    ? positiveDeltaSumUs / positiveDeltaCount
                    : 20_000L;
            tailUs = Math.max(1_000L, Math.min(tailUs, 1_000_000L));
            return Math.max(1L, (lastUs + tailUs + 500L) / 1000L);
        } catch (Throwable ignored) {
            return 0L;
        } finally {
            try { extractor.release(); } catch (Throwable ignored) {}
        }
    }

    /**
     * Lê apenas o início de um MP4 por InputStream. Esta via funciona também
     * quando o fornecedor expõe o ficheiro como pipe (ESPIPE). Nunca atravessa
     * um mdat grande à procura do moov, portanto não transforma a obtenção da
     * duração numa leitura integral do vídeo.
     */
    private long readIsoBmffMvhdDurationMsFromStart(Uri uri) {
        try (InputStream raw = getContentResolver().openInputStream(uri);
             BufferedInputStream in = raw == null ? null : new BufferedInputStream(raw, 64 * 1024)) {
            if (in == null) return 0L;

            long scanned = 0L;
            byte[] header = new byte[16];
            while (scanned + 8L <= MAX_MP4_HEADER_SCAN_BYTES) {
                if (!readFully(in, header, 0, 8)) return 0L;
                scanned += 8L;

                long size32 = uint32(header, 0);
                int type = int32(header, 4);
                long boxSize = size32;
                int headerSize = 8;

                if (size32 == 1L) {
                    if (!readFully(in, header, 8, 8)) return 0L;
                    scanned += 8L;
                    boxSize = int64(header, 8);
                    headerSize = 16;
                } else if (size32 == 0L) {
                    // Caixa até EOF: se não for moov não há forma rápida
                    // e segura de chegar à caixa seguinte num pipe.
                    return 0L;
                }

                if (boxSize < headerSize) return 0L;
                long payloadSize = boxSize - headerSize;

                if (type == fourCc("moov")) {
                    if (payloadSize <= 0L || payloadSize > MAX_MOOV_BYTES) return 0L;
                    byte[] moov = new byte[(int) payloadSize];
                    if (!readFully(in, moov, 0, moov.length)) return 0L;
                    return readMvhdDurationMs(moov);
                }

                // Saltar um mdat grande num pipe obrigaria a ler o filme inteiro.
                if (type == fourCc("mdat") || scanned + payloadSize > MAX_MP4_HEADER_SCAN_BYTES) {
                    return 0L;
                }
                if (!skipFully(in, payloadSize)) return 0L;
                scanned += payloadSize;
            }
        } catch (Throwable ignored) {
        }
        return 0L;
    }

    private long readMvhdDurationMs(byte[] moov) {
        int pos = 0;
        while (pos + 8 <= moov.length) {
            long size32 = uint32(moov, pos);
            int type = int32(moov, pos + 4);
            long boxSize = size32;
            int headerSize = 8;
            if (size32 == 1L) {
                if (pos + 16 > moov.length) return 0L;
                boxSize = int64(moov, pos + 8);
                headerSize = 16;
            } else if (size32 == 0L) {
                boxSize = moov.length - pos;
            }
            if (boxSize < headerSize || boxSize > moov.length - pos) return 0L;

            if (type == fourCc("mvhd")) {
                int payload = pos + headerSize;
                int payloadSize = (int) boxSize - headerSize;
                if (payloadSize < 20) return 0L;
                int version = moov[payload] & 0xFF;
                int timing = payload + (version == 1 ? 20 : 12);
                int required = version == 1 ? 12 : 8;
                if (timing < 0 || timing + required > payload + payloadSize) return 0L;
                long timescale = uint32(moov, timing);
                long duration = version == 1
                        ? int64(moov, timing + 4)
                        : uint32(moov, timing + 4);
                return durationToMs(timescale, duration);
            }
            pos += (int) boxSize;
        }
        return 0L;
    }

    private static long durationToMs(long timescale, long duration) {
        if (timescale <= 0L || duration <= 0L) return 0L;
        double ms = duration * 1000.0 / timescale;
        if (!Double.isFinite(ms) || ms <= 0.0 || ms > Long.MAX_VALUE) return 0L;
        return Math.max(1L, Math.round(ms));
    }

    private static boolean readFully(InputStream in, byte[] dst, int offset, int count)
            throws Exception {
        int done = 0;
        while (done < count) {
            int n = in.read(dst, offset + done, count - done);
            if (n < 0) return false;
            if (n == 0) continue;
            done += n;
        }
        return true;
    }

    private static boolean skipFully(InputStream in, long count) throws Exception {
        long done = 0L;
        while (done < count) {
            long n = in.skip(count - done);
            if (n > 0L) {
                done += n;
            } else if (in.read() >= 0) {
                done++;
            } else {
                return false;
            }
        }
        return true;
    }

    private static long uint32(byte[] value, int offset) {
        return Integer.toUnsignedLong(int32(value, offset));
    }

    private static int int32(byte[] value, int offset) {
        return ((value[offset] & 0xFF) << 24)
                | ((value[offset + 1] & 0xFF) << 16)
                | ((value[offset + 2] & 0xFF) << 8)
                | (value[offset + 3] & 0xFF);
    }

    private static long int64(byte[] value, int offset) {
        return ((long) (value[offset] & 0xFF) << 56)
                | ((long) (value[offset + 1] & 0xFF) << 48)
                | ((long) (value[offset + 2] & 0xFF) << 40)
                | ((long) (value[offset + 3] & 0xFF) << 32)
                | ((long) (value[offset + 4] & 0xFF) << 24)
                | ((long) (value[offset + 5] & 0xFF) << 16)
                | ((long) (value[offset + 6] & 0xFF) << 8)
                | (long) (value[offset + 7] & 0xFF);
    }

    private long queryMediaStoreDurationMs(Uri uri) {
        String authority = uri.getAuthority();
        if (authority == null || !authority.toLowerCase(Locale.ROOT).contains("media")) {
            return 0L;
        }

        Cursor c = null;
        try {
            c = getContentResolver().query(
                    uri,
                    new String[]{MediaStore.Video.VideoColumns.DURATION},
                    null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(MediaStore.Video.VideoColumns.DURATION);
                if (idx >= 0 && !c.isNull(idx)) {
                    long d = c.getLong(idx);
                    if (d > 0L) return d;
                }
            }
        } catch (Throwable ignored) {
        } finally {
            if (c != null) try { c.close(); } catch (Exception ignored) {}
        }
        return 0L;
    }

    /**
     * Leitor ISO-BMFF de acesso aleatório. Usa pread(), que não altera a posição
     * do descritor e permite saltar diretamente sobre o mdat, mesmo quando este
     * ocupa vários GB.
     */
    private long readIsoBmffMvhdDurationMsPread(Uri uri) {
        AssetFileDescriptor afd = null;
        try {
            afd = getContentResolver().openAssetFileDescriptor(uri, "r");
            if (afd == null) return 0L;

            FileDescriptor fd = afd.getFileDescriptor();
            long base = Math.max(0L, afd.getStartOffset());
            long length = afd.getLength();

            if (length <= 0L) {
                try {
                    long end = Os.lseek(fd, 0L, OsConstants.SEEK_END);
                    if (end > base) length = end - base;
                } catch (Throwable ignored) {
                    return 0L; // descritor não seekable (pipe/stream)
                }
            }
            if (length < 8L) return 0L;

            long pos = 0L;
            while (pos + 8L <= length) {
                BoxHeader box = readBoxHeaderPread(fd, base + pos, length - pos);
                if (box == null || box.size < box.headerSize || box.size <= 0L) break;

                if (box.type == fourCc("moov")) {
                    long d = readMvhdInsideMoovPread(
                            fd, base + pos + box.headerSize, box.size - box.headerSize);
                    if (d > 0L) return d;
                }

                if (box.size > length - pos) break;
                pos += box.size;
            }
        } catch (Throwable ignored) {
        } finally {
            if (afd != null) try { afd.close(); } catch (Exception ignored) {}
        }
        return 0L;
    }

    private long readMvhdInsideMoovPread(FileDescriptor fd, long payloadStart,
                                         long payloadSize) throws Exception {
        long pos = 0L;
        while (pos + 8L <= payloadSize) {
            BoxHeader child = readBoxHeaderPread(fd, payloadStart + pos, payloadSize - pos);
            if (child == null || child.size < child.headerSize || child.size <= 0L) break;

            if (child.type == fourCc("mvhd")) {
                return parseMvhdPread(fd, payloadStart + pos + child.headerSize,
                        child.size - child.headerSize);
            }

            if (child.size > payloadSize - pos) break;
            pos += child.size;
        }
        return 0L;
    }

    private long parseMvhdPread(FileDescriptor fd, long payloadStart,
                                long payloadSize) throws Exception {
        if (payloadSize < 20L) return 0L;
        int wanted = (int) Math.min(40L, payloadSize);
        byte[] raw = new byte[wanted];
        if (!preadFully(fd, raw, 0, wanted, payloadStart)) return 0L;

        ByteBuffer b = ByteBuffer.wrap(raw).order(ByteOrder.BIG_ENDIAN);
        int version = b.get() & 0xFF;
        b.get(); b.get(); b.get(); // flags

        long timescale;
        long duration;
        if (version == 1) {
            if (b.remaining() < 28) return 0L;
            b.position(b.position() + 16);
            timescale = Integer.toUnsignedLong(b.getInt());
            duration = b.getLong();
            if (duration < 0L) return 0L;
        } else {
            if (b.remaining() < 16) return 0L;
            b.position(b.position() + 8);
            timescale = Integer.toUnsignedLong(b.getInt());
            duration = Integer.toUnsignedLong(b.getInt());
        }

        if (timescale <= 0L || duration <= 0L) return 0L;
        double ms = (duration * 1000.0) / timescale;
        if (!Double.isFinite(ms) || ms <= 0.0 || ms > Long.MAX_VALUE) return 0L;
        return Math.max(1L, Math.round(ms));
    }

    private BoxHeader readBoxHeaderPread(FileDescriptor fd, long absolutePos,
                                         long remaining) throws Exception {
        if (remaining < 8L) return null;
        byte[] h = new byte[16];
        if (!preadFully(fd, h, 0, 8, absolutePos)) return null;
        ByteBuffer b = ByteBuffer.wrap(h).order(ByteOrder.BIG_ENDIAN);
        long size32 = Integer.toUnsignedLong(b.getInt());
        int type = b.getInt();
        long size = size32;
        int headerSize = 8;

        if (size32 == 1L) {
            if (!preadFully(fd, h, 8, 8, absolutePos + 8L)) return null;
            ByteBuffer ext = ByteBuffer.wrap(h, 8, 8).order(ByteOrder.BIG_ENDIAN);
            size = ext.getLong();
            headerSize = 16;
        } else if (size32 == 0L) {
            size = remaining;
        }

        if (size < headerSize) return null;
        return new BoxHeader(size, headerSize, type);
    }

    private boolean preadFully(FileDescriptor fd, byte[] dst, int dstOffset,
                               int byteCount, long fileOffset) throws Exception {
        int done = 0;
        while (done < byteCount) {
            int n = Os.pread(fd, dst, dstOffset + done, byteCount - done, fileOffset + done);
            if (n <= 0) return false;
            done += n;
        }
        return true;
    }

    private static int fourCc(String s) {
        return ((s.charAt(0) & 0xFF) << 24)
                | ((s.charAt(1) & 0xFF) << 16)
                | ((s.charAt(2) & 0xFF) << 8)
                | (s.charAt(3) & 0xFF);
    }

    private static final class BoxHeader {
        final long size;
        final int headerSize;
        final int type;

        BoxHeader(long size, int headerSize, int type) {
            this.size = size;
            this.headerSize = headerSize;
            this.type = type;
        }
    }

    private long probeLocalDurationMs(File file) {
        if (file == null || !file.exists()) return 0L;

        // 1) Metadata normal: rápido e suficiente para a maioria dos ficheiros.
        MediaMetadataRetriever mmr = new MediaMetadataRetriever();
        try {
            mmr.setDataSource(file.getAbsolutePath());
            String value = mmr.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION);
            if (value != null) {
                long d = Long.parseLong(value);
                if (d > 0L) return d;
            }
        } catch (Throwable ignored) {
        } finally {
            try { mmr.release(); } catch (Exception ignored) {}
        }

        // 2) Para MP4/M4A e outros containers: procurar KEY_DURATION diretamente
        // nas faixas. O valor de MediaFormat é expresso em microssegundos.
        MediaExtractor extractor = new MediaExtractor();
        try {
            extractor.setDataSource(file.getAbsolutePath());
            long bestDurationUs = 0L;
            int preferredTrack = -1;

            for (int i = 0; i < extractor.getTrackCount(); i++) {
                MediaFormat format = extractor.getTrackFormat(i);
                String mime = format.getString(MediaFormat.KEY_MIME);
                if (preferredTrack < 0 && mime != null && mime.startsWith("audio/")) {
                    preferredTrack = i;
                }
                if (format.containsKey(MediaFormat.KEY_DURATION)) {
                    try {
                        bestDurationUs = Math.max(bestDurationUs,
                                format.getLong(MediaFormat.KEY_DURATION));
                    } catch (Exception ignored) {}
                }
            }
            if (bestDurationUs > 0L) return Math.max(1L, bestDurationUs / 1000L);

            // 3) Alguns MP4 não publicam KEY_DURATION. Nesse caso percorremos só
            // os timestamps das amostras comprimidas de UMA faixa. Isto é muito
            // mais leve do que descodificar o ficheiro e dá ao slider uma duração
            // fiável mesmo em MP4 problemáticos.
            if (preferredTrack < 0 && extractor.getTrackCount() > 0) preferredTrack = 0;
            if (preferredTrack >= 0) {
                extractor.selectTrack(preferredTrack);
                long previousUs = -1L;
                long lastUs = -1L;
                long typicalStepUs = 0L;
                int stepSamples = 0;

                while (true) {
                    long t = extractor.getSampleTime();
                    if (t < 0L) break;
                    if (previousUs >= 0L && t > previousUs) {
                        long delta = t - previousUs;
                        // Evitar que uma descontinuidade anormal contamine a estimativa.
                        if (delta > 0L && delta < 5_000_000L) {
                            typicalStepUs += delta;
                            stepSamples++;
                        }
                    }
                    previousUs = t;
                    lastUs = t;
                    if (!extractor.advance()) break;
                }

                if (lastUs >= 0L) {
                    long tailUs = stepSamples > 0 ? typicalStepUs / stepSamples : 20_000L;
                    tailUs = Math.max(1_000L, Math.min(tailUs, 1_000_000L));
                    return Math.max(1L, (lastUs + tailUs) / 1000L);
                }
            }
        } catch (Throwable ignored) {
        } finally {
            try { extractor.release(); } catch (Exception ignored) {}
        }
        return 0L;
    }

    private String getDisplayName(Uri uri) {
        String name = uri.getLastPathSegment();
        Cursor c = null;
        try {
            c = getContentResolver().query(
                    uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return name == null ? "Ficheiro selecionado" : name;
    }

    private String formatMs(long ms) {
        long t = Math.max(0L, ms) / 1000L;
        long h = t / 3600L;
        long m = (t % 3600L) / 60L;
        long s = t % 60L;
        return h > 0L
                ? String.format(Locale.getDefault(), "%d:%02d:%02d", h, m, s)
                : String.format(Locale.getDefault(), "%02d:%02d", m, s);
    }

    private void toast(String s) {
        Toast.makeText(this, s, Toast.LENGTH_SHORT).show();
    }

    private void releasePlayer() {
        cancelInterItemPause();
        setPlaybackScreenOn(false);
        stopBackgroundPlaybackSupport();
        stopHeadphoneKeepAlive();
        if (player != null) {
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
    }

    @Override protected void onDestroy() {
        if (readingController != null) readingController.destroy();
        handler.removeCallbacks(playbackWatcher);
        cancelInterItemPause();
        releasePlayer();
        if (headphoneKeepAlivePlayer != null) headphoneKeepAlivePlayer.release();
        clearDecodedPcmCache();
        executor.shutdownNow();
        super.onDestroy();
    }
}
