package com.silence.looper;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.AudioDeviceInfo;
import android.media.AudioFormat;
import android.media.AudioManager;
import android.media.AudioTrack;
import android.os.Build;
import android.os.Process;

/**
 * Mantém a saída dos auriculares ativa com um sinal contínuo, muito baixo e
 * abafado. O nível é compensado pela atenuação REAL (em dB) do stream MEDIA
 * para o dispositivo de saída, para que baixar o volume do sistema não faça
 * desaparecer o sinal anti-corte.
 *
 * O sinal é apenas para reprodução em tempo real; não entra nas exportações.
 */
public final class HeadphoneKeepAlivePlayer {
    private static final int SAMPLE_RATE = 48_000;
    private static final int CHANNELS = 2;

    // Este é o nível que já se mostrou praticamente impercetível com o volume
    // alto. Em volumes mais baixos é aumentado ANTES da atenuação do sistema,
    // para que o nível efetivo à saída se mantenha aproximadamente constante.
    private static final int BASE_NOISE_AMPLITUDE = 128;

    // Permite compensar atenuações grandes sem chegar imediatamente ao limite
    // do PCM. O valor continua bem abaixo de full-scale e só é atingido com
    // volumes do sistema muito baixos.
    private static final int MAX_NOISE_AMPLITUDE = 24_000;

    private static final float LOW_PASS_ALPHA = 0.08f;
    private static final float AMPLITUDE_SMOOTHING = 0.16f;
    private static final int FRAMES_PER_BLOCK = 960; // 20 ms @ 48 kHz

    private final Object lock = new Object();
    private final AudioManager audioManager;
    private volatile boolean running = false;
    private volatile Thread worker;

    public HeadphoneKeepAlivePlayer(Context context) {
        Context app = context.getApplicationContext();
        audioManager = (AudioManager) app.getSystemService(Context.AUDIO_SERVICE);
    }

    public void start() {
        synchronized (lock) {
            if (running) return;
            running = true;
            worker = new Thread(this::runLoop, "SilenceLooper-AntiCut");
            worker.setDaemon(true);
            worker.start();
        }
    }

    public void stop() {
        Thread toInterrupt;
        synchronized (lock) {
            if (!running && worker == null) return;
            running = false;
            toInterrupt = worker;
            worker = null;
        }
        if (toInterrupt != null) toInterrupt.interrupt();
    }

    public boolean isRunning() {
        return running;
    }

    public void release() {
        stop();
    }

    private void runLoop() {
        AudioTrack track = null;
        try {
            Process.setThreadPriority(Process.THREAD_PRIORITY_AUDIO);

            AudioAttributes attributes = new AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build();

            AudioFormat format = new AudioFormat.Builder()
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setSampleRate(SAMPLE_RATE)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build();

            int minBytes = AudioTrack.getMinBufferSize(
                    SAMPLE_RATE,
                    AudioFormat.CHANNEL_OUT_STEREO,
                    AudioFormat.ENCODING_PCM_16BIT);
            if (minBytes <= 0) minBytes = SAMPLE_RATE / 5 * CHANNELS * 2;
            int bufferBytes = Math.max(minBytes, SAMPLE_RATE / 5 * CHANNELS * 2);

            track = new AudioTrack(
                    attributes,
                    format,
                    bufferBytes,
                    AudioTrack.MODE_STREAM,
                    AudioManager.AUDIO_SESSION_ID_GENERATE);

            if (track.getState() != AudioTrack.STATE_INITIALIZED) {
                running = false;
                return;
            }

            short[] pcm = new short[FRAMES_PER_BLOCK * CHANNELS];
            int state = 0x5A17C9E3;
            float filtered = 0.0f;
            int targetAmplitude = BASE_NOISE_AMPLITUDE;
            float currentAmplitude = BASE_NOISE_AMPLITUDE;
            int blocksUntilVolumeRefresh = 0;

            track.play();

            while (running && Thread.currentThread() == worker
                    && !Thread.currentThread().isInterrupted()) {

                // Recalcula aproximadamente 4 vezes por segundo. A API de dB
                // já incorpora a curva NÃO linear do volume Android.
                if (blocksUntilVolumeRefresh-- <= 0) {
                    targetAmplitude = calculateAdaptiveAmplitude(track);
                    blocksUntilVolumeRefresh = 12;
                }

                // Suaviza a transição para que mudar o volume do telemóvel não
                // produza degraus/clicks audíveis no sinal de fundo.
                currentAmplitude += (targetAmplitude - currentAmplitude)
                        * AMPLITUDE_SMOOTHING;
                int blockAmplitude = Math.max(1,
                        Math.min(MAX_NOISE_AMPLITUDE, Math.round(currentAmplitude)));

                for (int i = 0; i < FRAMES_PER_BLOCK; i++) {
                    state ^= (state << 13);
                    state ^= (state >>> 17);
                    state ^= (state << 5);

                    int raw = (state & 0x7FFFFFFF) % (blockAmplitude * 2 + 1)
                            - blockAmplitude;

                    // Ruído abafado: mantém energia elétrica contínua mas evita
                    // o carácter agudo/áspero do ruído branco puro.
                    filtered += LOW_PASS_ALPHA * (raw - filtered);
                    short out = (short) Math.max(Short.MIN_VALUE,
                            Math.min(Short.MAX_VALUE, Math.round(filtered)));

                    int p = i * CHANNELS;
                    pcm[p] = out;
                    pcm[p + 1] = out;
                }

                int offset = 0;
                while (running && Thread.currentThread() == worker
                        && offset < pcm.length) {
                    int written = track.write(
                            pcm,
                            offset,
                            pcm.length - offset,
                            AudioTrack.WRITE_BLOCKING);
                    if (written <= 0) {
                        running = false;
                        break;
                    }
                    offset += written;
                }
            }
        } catch (Throwable ignored) {
            if (Thread.currentThread() == worker) running = false;
        } finally {
            if (track != null) {
                try { track.pause(); } catch (Throwable ignored) {}
                try { track.flush(); } catch (Throwable ignored) {}
                try { track.stop(); } catch (Throwable ignored) {}
                try { track.release(); } catch (Throwable ignored) {}
            }
            synchronized (lock) {
                if (Thread.currentThread() == worker) {
                    worker = null;
                    running = false;
                }
            }
        }
    }

    /**
     * Calcula a amplitude necessária para compensar a atenuação REAL em dB do
     * STREAM_MUSIC. Por exemplo, se o sistema estiver a aplicar -20 dB, o PCM
     * do anti-corte é elevado ~10x antes dessa atenuação, mantendo aproximadamente
     * o mesmo nível efetivo que teria no volume máximo.
     */
    private int calculateAdaptiveAmplitude(AudioTrack track) {
        try {
            if (audioManager == null) return BASE_NOISE_AMPLITUDE;

            int current = audioManager.getStreamVolume(AudioManager.STREAM_MUSIC);
            if (current <= 0) {
                // Com o stream totalmente mudo o Android multiplica a saída por
                // zero; nenhum sinal MEDIA pode contornar legitimamente isso.
                return BASE_NOISE_AMPLITUDE;
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                int deviceType = resolveOutputDeviceType(track);
                float attenuationDb = audioManager.getStreamVolumeDb(
                        AudioManager.STREAM_MUSIC,
                        current,
                        deviceType);

                if (!Float.isNaN(attenuationDb)
                        && !Float.isInfinite(attenuationDb)
                        && attenuationDb <= 0.0f) {
                    double compensation = Math.pow(10.0d, -attenuationDb / 20.0d);
                    int amplitude = (int) Math.round(
                            BASE_NOISE_AMPLITUDE * compensation);
                    return clampAmplitude(amplitude);
                }
            }

            // Fallback para Android 7/8 ou para implementações que rejeitem a
            // consulta em dB. É deliberadamente mais agressivo que a fórmula
            // antiga baseada numa percentagem linear do slider.
            int max = audioManager.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
            if (max <= 0) return BASE_NOISE_AMPLITUDE;
            int stepsBelowMax = Math.max(0, max - current);
            double compensation = Math.pow(10.0d,
                    (stepsBelowMax * 2.5d) / 20.0d);
            return clampAmplitude((int) Math.round(
                    BASE_NOISE_AMPLITUDE * compensation));

        } catch (Throwable ignored) {
            return BASE_NOISE_AMPLITUDE;
        }
    }

    private int clampAmplitude(int amplitude) {
        return Math.max(BASE_NOISE_AMPLITUDE,
                Math.min(MAX_NOISE_AMPLITUDE, amplitude));
    }

    private int resolveOutputDeviceType(AudioTrack track) {
        try {
            AudioDeviceInfo routed = track.getRoutedDevice();
            if (routed != null && routed.isSink()) {
                return routed.getType();
            }
        } catch (Throwable ignored) {
        }

        try {
            if (audioManager != null) {
                AudioDeviceInfo[] outputs = audioManager.getDevices(
                        AudioManager.GET_DEVICES_OUTPUTS);

                int best = AudioDeviceInfo.TYPE_BUILTIN_SPEAKER;
                int bestPriority = -1;
                for (AudioDeviceInfo info : outputs) {
                    if (info == null || !info.isSink()) continue;
                    int priority = devicePriority(info.getType());
                    if (priority > bestPriority) {
                        bestPriority = priority;
                        best = info.getType();
                    }
                }
                return best;
            }
        } catch (Throwable ignored) {
        }

        return AudioDeviceInfo.TYPE_BUILTIN_SPEAKER;
    }

    private int devicePriority(int type) {
        if (Build.VERSION.SDK_INT >= 31) {
            if (type == AudioDeviceInfo.TYPE_BLE_HEADSET) return 100;
            if (type == AudioDeviceInfo.TYPE_BLE_SPEAKER) return 95;
        }
        if (type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP) return 90;
        if (type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES) return 85;
        if (type == AudioDeviceInfo.TYPE_WIRED_HEADSET) return 84;
        if (type == AudioDeviceInfo.TYPE_USB_HEADSET) return 80;
        if (type == AudioDeviceInfo.TYPE_USB_DEVICE) return 75;
        if (type == AudioDeviceInfo.TYPE_BUILTIN_SPEAKER) return 10;
        return 1;
    }
}
