package com.silence.looper;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.graphics.pdf.PdfRenderer;
import android.net.Uri;
import android.os.ParcelFileDescriptor;
import android.text.Html;

import com.google.android.gms.tasks.Tasks;
import com.google.android.gms.common.moduleinstall.ModuleInstall;
import com.google.android.gms.common.moduleinstall.ModuleInstallClient;
import com.google.android.gms.common.moduleinstall.ModuleInstallRequest;
import com.google.mlkit.vision.common.InputImage;
import com.google.mlkit.vision.text.Text;
import com.google.mlkit.vision.text.TextRecognition;
import com.google.mlkit.vision.text.TextRecognizer;
import com.google.mlkit.vision.text.latin.TextRecognizerOptions;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

import javax.xml.parsers.DocumentBuilderFactory;

/** Lê TXT, EPUB e PDF (PDF por OCR local). */
public final class TextDocumentLoader {
    public interface ProgressListener {
        void onProgress(String message);
    }

    private TextDocumentLoader() {}

    public static String load(Context context, Uri uri, String displayName,
                              ProgressListener progress) throws Exception {
        String lower = displayName == null ? "" : displayName.toLowerCase(Locale.ROOT);
        String type = context.getContentResolver().getType(uri);
        if (type == null) type = "";

        if (lower.endsWith(".pdf") || type.equals("application/pdf")) {
            return loadPdfOcr(context, uri, progress);
        }
        if (lower.endsWith(".epub") || type.equals("application/epub+zip")) {
            if (progress != null) progress.onProgress("A extrair texto do EPUB…");
            return loadEpub(context, uri);
        }
        if (progress != null) progress.onProgress("A ler texto…");
        return loadTxt(context, uri);
    }

    private static String loadTxt(Context context, Uri uri) throws Exception {
        byte[] bytes;
        try (InputStream in = context.getContentResolver().openInputStream(uri)) {
            if (in == null) throw new IllegalStateException("Não foi possível abrir o ficheiro.");
            bytes = readAll(in, 64 * 1024 * 1024);
        }
        if (bytes.length >= 3 && (bytes[0] & 0xff) == 0xef
                && (bytes[1] & 0xff) == 0xbb && (bytes[2] & 0xff) == 0xbf) {
            return new String(bytes, 3, bytes.length - 3, StandardCharsets.UTF_8);
        }
        String utf8 = new String(bytes, StandardCharsets.UTF_8);
        if (utf8.indexOf('\uFFFD') >= 0) {
            try {
                return new String(bytes, Charset.forName("windows-1252"));
            } catch (Exception ignored) {}
        }
        return utf8;
    }

    private static String loadPdfOcr(Context context, Uri uri,
                                     ProgressListener progress) throws Exception {
        File tempPdf = new File(context.getCacheDir(), "reading_ocr_" + System.nanoTime() + ".pdf");
        try (InputStream in = context.getContentResolver().openInputStream(uri);
             FileOutputStream out = new FileOutputStream(tempPdf)) {
            if (in == null) throw new IllegalStateException("Não foi possível abrir o PDF.");
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (n > 0) out.write(buf, 0, n);
            }
        }

        StringBuilder all = new StringBuilder();
        TextRecognizer recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS);
        ensureOcrModule(context, recognizer, progress);
        try (ParcelFileDescriptor fd = ParcelFileDescriptor.open(
                tempPdf, ParcelFileDescriptor.MODE_READ_ONLY);
             PdfRenderer renderer = new PdfRenderer(fd)) {
            int count = renderer.getPageCount();
            if (count <= 0) throw new IllegalStateException("O PDF não contém páginas.");

            for (int i = 0; i < count; i++) {
                if (progress != null) {
                    progress.onProgress("OCR do PDF: página " + (i + 1) + "/" + count + "…");
                }
                try (PdfRenderer.Page page = renderer.openPage(i)) {
                    int srcW = Math.max(1, page.getWidth());
                    int srcH = Math.max(1, page.getHeight());
                    int targetW = Math.min(1800, Math.max(1000, srcW * 2));
                    int targetH = Math.max(1, Math.round(targetW * (srcH / (float) srcW)));
                    if (targetH > 2600) {
                        targetH = 2600;
                        targetW = Math.max(1, Math.round(targetH * (srcW / (float) srcH)));
                    }

                    Bitmap bitmap = Bitmap.createBitmap(targetW, targetH, Bitmap.Config.ARGB_8888);
                    bitmap.eraseColor(Color.WHITE);
                    try {
                        page.render(bitmap, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY);
                        Text text = Tasks.await(recognizer.process(InputImage.fromBitmap(bitmap, 0)));
                        String pageText = text == null ? "" : text.getText();
                        if (pageText != null && !pageText.trim().isEmpty()) {
                            if (all.length() > 0) all.append("\n\n");
                            all.append(pageText.trim());
                        }
                    } finally {
                        bitmap.recycle();
                    }
                }
            }
        } finally {
            recognizer.close();
            try { tempPdf.delete(); } catch (Exception ignored) {}
        }

        String result = all.toString().trim();
        if (result.isEmpty()) {
            throw new IllegalStateException("O OCR não conseguiu extrair texto do PDF.");
        }
        return result;
    }

    private static void ensureOcrModule(Context context, TextRecognizer recognizer,
                                        ProgressListener progress) throws Exception {
        ModuleInstallClient client = ModuleInstall.getClient(context);
        boolean available = Tasks.await(client.areModulesAvailable(recognizer)).areModulesAvailable();
        if (available) return;

        if (progress != null) progress.onProgress("A descarregar modelo OCR…");
        ModuleInstallRequest request = ModuleInstallRequest.newBuilder()
                .addApi(recognizer)
                .build();
        Tasks.await(client.installModules(request));

        long deadline = android.os.SystemClock.elapsedRealtime() + 90000L;
        while (android.os.SystemClock.elapsedRealtime() < deadline) {
            if (Tasks.await(client.areModulesAvailable(recognizer)).areModulesAvailable()) {
                return;
            }
            Thread.sleep(500L);
        }
        throw new IllegalStateException(
                "O modelo OCR ainda não terminou de descarregar. Verifique a ligação à Internet e tente novamente.");
    }

    private static String loadEpub(Context context, Uri uri) throws Exception {
        Map<String, byte[]> textEntries = new HashMap<>();
        try (InputStream raw = context.getContentResolver().openInputStream(uri)) {
            if (raw == null) throw new IllegalStateException("Não foi possível abrir o EPUB.");
            try (ZipInputStream zin = new ZipInputStream(raw)) {
                ZipEntry e;
                while ((e = zin.getNextEntry()) != null) {
                    if (e.isDirectory()) continue;
                    String name = normalizePath(e.getName());
                    String lower = name.toLowerCase(Locale.ROOT);
                    boolean wanted = lower.equals("meta-inf/container.xml")
                            || lower.endsWith(".opf")
                            || lower.endsWith(".xhtml")
                            || lower.endsWith(".html")
                            || lower.endsWith(".htm");
                    if (wanted) {
                        textEntries.put(name, readAll(zin, 8 * 1024 * 1024));
                    }
                    zin.closeEntry();
                }
            }
        }

        byte[] container = textEntries.get("META-INF/container.xml");
        if (container == null) container = textEntries.get("meta-inf/container.xml");
        String opfPath = null;
        if (container != null) {
            Document doc = parseXml(container);
            NodeList roots = doc.getElementsByTagNameNS("*", "rootfile");
            if (roots.getLength() > 0) {
                opfPath = ((Element) roots.item(0)).getAttribute("full-path");
            }
        }
        if (opfPath == null || opfPath.trim().isEmpty()) {
            for (String key : textEntries.keySet()) {
                if (key.toLowerCase(Locale.ROOT).endsWith(".opf")) {
                    opfPath = key;
                    break;
                }
            }
        }
        if (opfPath == null) throw new IllegalStateException("Estrutura EPUB inválida: OPF não encontrado.");
        opfPath = normalizePath(opfPath);
        byte[] opfBytes = textEntries.get(opfPath);
        if (opfBytes == null) throw new IllegalStateException("Estrutura EPUB inválida: OPF inacessível.");

        Document opf = parseXml(opfBytes);
        Map<String, String> hrefById = new HashMap<>();
        NodeList items = opf.getElementsByTagNameNS("*", "item");
        for (int i = 0; i < items.getLength(); i++) {
            Element item = (Element) items.item(i);
            String id = item.getAttribute("id");
            String href = item.getAttribute("href");
            String media = item.getAttribute("media-type");
            if (!id.isEmpty() && !href.isEmpty()
                    && (media.contains("html") || href.toLowerCase(Locale.ROOT).matches(".*\\.x?html?$"))) {
                hrefById.put(id, href);
            }
        }

        String base = "";
        int slash = opfPath.lastIndexOf('/');
        if (slash >= 0) base = opfPath.substring(0, slash + 1);

        List<String> spineFiles = new ArrayList<>();
        NodeList refs = opf.getElementsByTagNameNS("*", "itemref");
        for (int i = 0; i < refs.getLength(); i++) {
            Element ref = (Element) refs.item(i);
            String href = hrefById.get(ref.getAttribute("idref"));
            if (href != null) spineFiles.add(resolvePath(base, href));
        }
        if (spineFiles.isEmpty()) {
            for (String href : hrefById.values()) spineFiles.add(resolvePath(base, href));
        }

        StringBuilder out = new StringBuilder();
        for (String path : spineFiles) {
            byte[] data = textEntries.get(normalizePath(path));
            if (data == null) continue;
            String html = new String(data, StandardCharsets.UTF_8);
            String plain = Html.fromHtml(html, Html.FROM_HTML_MODE_LEGACY).toString().trim();
            if (!plain.isEmpty()) {
                if (out.length() > 0) out.append("\n\n");
                out.append(plain);
            }
        }
        String result = out.toString().trim();
        if (result.isEmpty()) throw new IllegalStateException("Não foi possível extrair texto do EPUB.");
        return result;
    }

    private static Document parseXml(byte[] data) throws Exception {
        DocumentBuilderFactory f = DocumentBuilderFactory.newInstance();
        f.setNamespaceAware(true);
        try { f.setFeature("http://apache.org/xml/features/disallow-doctype-decl", true); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { f.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        return f.newDocumentBuilder().parse(new ByteArrayInputStream(data));
    }

    private static byte[] readAll(InputStream in, int maxBytes) throws Exception {
        ByteArrayOutputStream out = new ByteArrayOutputStream();
        byte[] buf = new byte[32 * 1024];
        int total = 0;
        int n;
        while ((n = in.read(buf)) >= 0) {
            if (n == 0) continue;
            total += n;
            if (total > maxBytes) throw new IllegalArgumentException("Ficheiro demasiado grande para leitura direta.");
            out.write(buf, 0, n);
        }
        return out.toByteArray();
    }

    private static String normalizePath(String p) {
        if (p == null) return "";
        p = p.replace('\\', '/');
        while (p.startsWith("./")) p = p.substring(2);
        List<String> parts = new ArrayList<>();
        for (String part : p.split("/")) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!parts.isEmpty()) parts.remove(parts.size() - 1);
            } else {
                parts.add(part);
            }
        }
        StringBuilder sb = new StringBuilder();
        for (String part : parts) {
            if (sb.length() > 0) sb.append('/');
            sb.append(part);
        }
        return sb.toString();
    }

    private static String resolvePath(String base, String href) {
        String cleanHref = href == null ? "" : href.split("#", 2)[0];
        return normalizePath(base + cleanHref);
    }
}
