package com.silence.looper;

import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/** Divide texto em blocos curtos, privilegiando pontuação e tamanhos equilibrados. */
public final class TextSegmenter {
    private static final Pattern WORD = Pattern.compile("\\S+");

    private TextSegmenter() {}

    private static final class Token {
        final String text;
        final boolean paragraphAfter;

        Token(String text, boolean paragraphAfter) {
            this.text = text;
            this.paragraphAfter = paragraphAfter;
        }
    }

    public static List<String> segment(String input) {
        return segment(input, 2, 5);
    }

    public static List<String> segment(String input, int minWords, int maxWords) {
        List<String> result = new ArrayList<>();
        if (input == null) return result;

        int min = Math.max(1, Math.min(10, minWords));
        int max = Math.max(min, Math.min(10, maxWords));

        String text = normalize(input);
        if (text.isEmpty()) return result;

        List<Token> tokens = tokenize(text);
        int n = tokens.size();
        if (n == 0) return result;

        int i = 0;
        while (i < n) {
            int remaining = n - i;

            if (remaining <= max) {
                if (remaining < min && !result.isEmpty()) {
                    int last = result.size() - 1;
                    int lastCount = countWords(result.get(last));
                    if (lastCount + remaining <= max) {
                        result.set(last, result.get(last) + " " + join(tokens, i, n));
                    } else {
                        result.add(join(tokens, i, n));
                    }
                } else {
                    result.add(join(tokens, i, n));
                }
                break;
            }

            int bestLen = -1;
            int bestScore = Integer.MIN_VALUE;
            for (int len = min; len <= max && i + len <= n; len++) {
                int end = i + len;
                int rem = n - end;
                if (rem > 0 && rem < min) continue;

                Token last = tokens.get(end - 1);
                int score = punctuationScore(last.text, last.paragraphAfter);
                score += lengthBalanceScore(len, min, max);

                if (score > bestScore) {
                    bestScore = score;
                    bestLen = len;
                }
            }

            if (bestLen < 0) {
                bestLen = Math.min(max, remaining);
            }
            result.add(join(tokens, i, i + bestLen));
            i += bestLen;
        }

        return result;
    }

    private static String normalize(String s) {
        s = s.replace('\u00A0', ' ')
                .replace("\r\n", "\n")
                .replace('\r', '\n');
        s = s.replaceAll("[ \\t\\f]+", " ");
        s = s.replaceAll(" *\\n+ *", "\n");
        return s.trim();
    }

    private static List<Token> tokenize(String text) {
        List<Token> out = new ArrayList<>();
        Matcher m = WORD.matcher(text);
        int previousEnd = -1;
        List<String> words = new ArrayList<>();
        List<Boolean> paragraphAfter = new ArrayList<>();
        while (m.find()) {
            if (!words.isEmpty()) {
                String between = text.substring(previousEnd, m.start());
                paragraphAfter.set(paragraphAfter.size() - 1, between.indexOf('\n') >= 0);
            }
            words.add(m.group());
            paragraphAfter.add(false);
            previousEnd = m.end();
        }
        for (int i = 0; i < words.size(); i++) {
            out.add(new Token(words.get(i), paragraphAfter.get(i)));
        }
        return out;
    }

    private static int punctuationScore(String raw, boolean paragraphAfter) {
        if (paragraphAfter) return 140;
        if (raw == null || raw.isEmpty()) return 0;
        String s = raw.replaceAll("[\\\"'»”’\\)\\]\\}]+$", "");
        if (s.endsWith(".") || s.endsWith("!") || s.endsWith("?") || s.endsWith("…")) return 120;
        if (s.endsWith(";") || s.endsWith(":")) return 95;
        if (s.endsWith(",")) return 75;
        if (s.endsWith("—") || s.endsWith("–")) return 55;
        return 0;
    }

    private static int lengthBalanceScore(int len, int min, int max) {
        int preferred = Math.max(min, Math.min(max, 4));
        int distance = Math.abs(len - preferred);
        return 30 - distance * 6;
    }

    private static int countWords(String text) {
        if (text == null || text.trim().isEmpty()) return 0;
        return text.trim().split("\\s+").length;
    }

    private static String join(List<Token> tokens, int start, int end) {
        StringBuilder sb = new StringBuilder();
        for (int i = start; i < end; i++) {
            if (sb.length() > 0) sb.append(' ');
            sb.append(tokens.get(i).text);
        }
        return sb.toString().trim();
    }
}
