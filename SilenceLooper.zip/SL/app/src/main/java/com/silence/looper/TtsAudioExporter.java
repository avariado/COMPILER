package com.silence.looper;

import android.content.Context;
import android.net.Uri;
import android.os.Bundle;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;

import com.naman14.androidlame.AndroidLame;
import com.naman14.androidlame.LameBuilder;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.RandomAccessFile;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/** Exporta uma sequência TTS para WAV ou MP3 sem depender da reprodução em tempo real. */
public final class TtsAudioExporter {
    public interface ProgressListener {
        void onProgress(String message);
    }

    private TtsAudioExporter() {}

    public static void export(Context context, Uri outputUri, boolean mp3,
                              List<String> segments, int repeats, int pauseSeconds,
                              float speechRate, String voiceName, String languageTag,
                              ProgressListener progress) throws Exception {
        if (segments == null || segments.isEmpty()) {
            throw new IllegalArgumentException("Não existem trechos de texto para gravar.");
        }
        File work = new File(context.getCacheDir(), "tts_export_" + System.nanoTime());
        if (!work.mkdirs()) throw new IllegalStateException("Não foi possível criar a pasta temporária.");

        TextToSpeech tts = null;
        try {
            tts = createTtsBlocking(context);
            tts.setSpeechRate(Math.max(0.1f, speechRate));
            applyVoiceSelection(tts, voiceName, languageTag);

            List<File> wavs = new ArrayList<>();
            for (int i = 0; i < segments.size(); i++) {
                if (progress != null) {
                    progress.onProgress("A sintetizar trecho " + (i + 1) + "/" + segments.size() + "…");
                }
                File f = new File(work, String.format(Locale.ROOT, "seg_%05d.wav", i));
                synthesizeBlocking(tts, segments.get(i), f, i);
                wavs.add(f);
            }

            if (progress != null) progress.onProgress("A montar a gravação…");
            File combined = new File(work, "combined.wav");
            combineWavs(wavs, Math.max(1, repeats), Math.max(0, pauseSeconds), combined);

            if (mp3) {
                if (progress != null) progress.onProgress("A codificar MP3…");
                encodeWavToMp3(context, combined, outputUri);
            } else {
                copyFileToUri(context, combined, outputUri);
            }
        } finally {
            if (tts != null) {
                try { tts.stop(); } catch (Exception ignored) {}
                try { tts.shutdown(); } catch (Exception ignored) {}
            }
            deleteRecursive(work);
        }
    }

    private static TextToSpeech createTtsBlocking(Context context) throws Exception {
        CountDownLatch latch = new CountDownLatch(1);
        AtomicInteger status = new AtomicInteger(TextToSpeech.ERROR);
        final TextToSpeech[] holder = new TextToSpeech[1];
        holder[0] = new TextToSpeech(context.getApplicationContext(), s -> {
            status.set(s);
            latch.countDown();
        });
        if (!latch.await(15, TimeUnit.SECONDS)) {
            try { holder[0].shutdown(); } catch (Exception ignored) {}
            throw new IllegalStateException("O TTS não respondeu.");
        }
        if (status.get() != TextToSpeech.SUCCESS) {
            try { holder[0].shutdown(); } catch (Exception ignored) {}
            throw new IllegalStateException("Não foi possível iniciar o TTS do Android.");
        }
        return holder[0];
    }

    private static void applyVoiceSelection(TextToSpeech tts, String voiceName,
                                            String languageTag) {
        if (tts == null) return;
        if (voiceName != null && !voiceName.isEmpty()) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice voice : voices) {
                        if (voiceName.equals(voice.getName())) {
                            if (tts.setVoice(voice) == TextToSpeech.SUCCESS) return;
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        try {
            Locale locale = (languageTag == null || languageTag.isEmpty())
                    ? Locale.getDefault() : Locale.forLanguageTag(languageTag);
            tts.setLanguage(locale);
        } catch (Exception ignored) {}
    }

    private static void synthesizeBlocking(TextToSpeech tts, String text, File file, int index)
            throws Exception {
        String id = "export_" + index + "_" + UUID.randomUUID();
        CountDownLatch latch = new CountDownLatch(1);
        AtomicBoolean failed = new AtomicBoolean(false);

        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}
            @Override public void onDone(String utteranceId) {
                if (id.equals(utteranceId)) latch.countDown();
            }
            @Override public void onError(String utteranceId) {
                if (id.equals(utteranceId)) {
                    failed.set(true);
                    latch.countDown();
                }
            }
            @Override public void onError(String utteranceId, int errorCode) {
                onError(utteranceId);
            }
        });

        int queued = tts.synthesizeToFile(text, new Bundle(), file, id);
        if (queued != TextToSpeech.SUCCESS) {
            throw new IllegalStateException("O TTS recusou a síntese do trecho " + (index + 1) + ".");
        }
        if (!latch.await(120, TimeUnit.SECONDS)) {
            throw new IllegalStateException("Tempo esgotado ao sintetizar o trecho " + (index + 1) + ".");
        }
        if (failed.get() || !file.exists() || file.length() < 44L) {
            throw new IllegalStateException("Falha do TTS ao sintetizar o trecho " + (index + 1) + ".");
        }
    }

    private static final class WavInfo {
        final File file;
        final int audioFormat;
        final int channels;
        final int sampleRate;
        final int bitsPerSample;
        final long dataOffset;
        final long dataSize;

        WavInfo(File file, int audioFormat, int channels, int sampleRate, int bitsPerSample,
                long dataOffset, long dataSize) {
            this.file = file;
            this.audioFormat = audioFormat;
            this.channels = channels;
            this.sampleRate = sampleRate;
            this.bitsPerSample = bitsPerSample;
            this.dataOffset = dataOffset;
            this.dataSize = dataSize;
        }
    }

    private static WavInfo readWavInfo(File file) throws Exception {
        try (RandomAccessFile raf = new RandomAccessFile(file, "r")) {
            byte[] id = new byte[4];
            raf.readFully(id);
            if (!new String(id, "US-ASCII").equals("RIFF")) {
                throw new IllegalArgumentException("O TTS produziu um formato de áudio não suportado.");
            }
            raf.skipBytes(4);
            raf.readFully(id);
            if (!new String(id, "US-ASCII").equals("WAVE")) {
                throw new IllegalArgumentException("O TTS produziu um WAV inválido.");
            }

            int format = -1, channels = -1, rate = -1, bits = -1;
            long dataOffset = -1L, dataSize = -1L;
            while (raf.getFilePointer() + 8 <= raf.length()) {
                raf.readFully(id);
                String chunk = new String(id, "US-ASCII");
                long size = readLE32(raf);
                long next = raf.getFilePointer() + size + (size & 1L);
                if (chunk.equals("fmt ")) {
                    format = readLE16(raf);
                    channels = readLE16(raf);
                    rate = (int) readLE32(raf);
                    raf.skipBytes(6);
                    bits = readLE16(raf);
                } else if (chunk.equals("data")) {
                    dataOffset = raf.getFilePointer();
                    dataSize = size;
                    break;
                }
                raf.seek(Math.min(next, raf.length()));
            }
            if (format != 1 || bits != 16 || channels < 1 || channels > 2
                    || rate <= 0 || dataOffset < 0 || dataSize < 0) {
                throw new IllegalArgumentException(
                        "O motor TTS não produziu PCM WAV de 16 bits compatível com a gravação.");
            }
            return new WavInfo(file, format, channels, rate, bits, dataOffset, dataSize);
        }
    }

    private static void combineWavs(List<File> files, int repeats, int pauseSeconds, File output)
            throws Exception {
        if (files.isEmpty()) throw new IllegalArgumentException("Sem áudio TTS para combinar.");
        List<WavInfo> infos = new ArrayList<>();
        for (File f : files) infos.add(readWavInfo(f));
        WavInfo first = infos.get(0);
        for (WavInfo w : infos) {
            if (w.channels != first.channels || w.sampleRate != first.sampleRate
                    || w.bitsPerSample != first.bitsPerSample || w.audioFormat != first.audioFormat) {
                throw new IllegalStateException("O motor TTS alterou o formato de áudio entre trechos.");
            }
        }

        long bytesPerFrame = first.channels * 2L;
        long pauseBytes = (long) pauseSeconds * first.sampleRate * bytesPerFrame;
        long itemCount = (long) infos.size() * repeats;
        long dataBytes = 0L;
        for (WavInfo w : infos) dataBytes += w.dataSize * repeats;
        if (itemCount > 1) dataBytes += pauseBytes * (itemCount - 1L);
        if (dataBytes > 0xFFFFFFFFL - 44L) {
            throw new IllegalArgumentException("A gravação WAV resultante seria demasiado grande.");
        }

        try (BufferedOutputStream out = new BufferedOutputStream(new FileOutputStream(output), 128 * 1024)) {
            writeWavHeader(out, first.sampleRate, first.channels, dataBytes);
            byte[] buf = new byte[64 * 1024];
            byte[] zeros = new byte[64 * 1024];
            long emitted = 0L;
            long totalItems = itemCount;
            for (WavInfo w : infos) {
                for (int r = 0; r < repeats; r++) {
                    try (RandomAccessFile raf = new RandomAccessFile(w.file, "r")) {
                        raf.seek(w.dataOffset);
                        long remaining = w.dataSize;
                        while (remaining > 0L) {
                            int n = raf.read(buf, 0, (int) Math.min(buf.length, remaining));
                            if (n < 0) break;
                            out.write(buf, 0, n);
                            remaining -= n;
                        }
                    }
                    emitted++;
                    if (emitted < totalItems && pauseBytes > 0L) {
                        long remainPause = pauseBytes;
                        while (remainPause > 0L) {
                            int n = (int) Math.min(zeros.length, remainPause);
                            out.write(zeros, 0, n);
                            remainPause -= n;
                        }
                    }
                }
            }
        }
    }

    private static void encodeWavToMp3(Context context, File wav, Uri outputUri) throws Exception {
        WavInfo info = readWavInfo(wav);
        int channels = info.channels;
        AndroidLame lame = new LameBuilder()
                .setInSampleRate(info.sampleRate)
                .setOutSampleRate(info.sampleRate)
                .setOutChannels(channels)
                .setOutBitrate(192)
                .setQuality(5)
                .build();
        OutputStream raw = context.getContentResolver().openOutputStream(outputUri, "w");
        if (raw == null) {
            try { lame.close(); } catch (Exception ignored) {}
            throw new IllegalStateException("Não foi possível criar o MP3.");
        }

        byte[] bytes = new byte[8192 * channels * 2];
        short[] interleaved = new short[8192 * channels];
        short[] left = new short[8192];
        short[] right = new short[8192];
        byte[] mp3 = new byte[65536];

        try (RandomAccessFile raf = new RandomAccessFile(wav, "r");
             BufferedOutputStream out = new BufferedOutputStream(raw, 128 * 1024)) {
            raf.seek(info.dataOffset);
            long remaining = info.dataSize;
            while (remaining > 0L) {
                int want = (int) Math.min(bytes.length, remaining);
                int got = raf.read(bytes, 0, want);
                if (got <= 0) break;
                int samples = got / 2;
                int frames = samples / channels;
                for (int i = 0, p = 0; i < frames * channels; i++, p += 2) {
                    interleaved[i] = (short) ((bytes[p] & 0xff) | (bytes[p + 1] << 8));
                }
                int encoded;
                if (channels == 1) {
                    encoded = lame.encode(interleaved, interleaved, frames, mp3);
                } else {
                    for (int i = 0; i < frames; i++) {
                        left[i] = interleaved[i * 2];
                        right[i] = interleaved[i * 2 + 1];
                    }
                    encoded = lame.encode(left, right, frames, mp3);
                }
                if (encoded > 0) out.write(mp3, 0, encoded);
                remaining -= got;
            }
            int flush = lame.flush(mp3);
            if (flush > 0) out.write(mp3, 0, flush);
            out.flush();
        } finally {
            try { lame.close(); } catch (Exception ignored) {}
        }
    }

    private static void copyFileToUri(Context context, File input, Uri outputUri) throws Exception {
        OutputStream raw = context.getContentResolver().openOutputStream(outputUri, "w");
        if (raw == null) throw new IllegalStateException("Não foi possível criar o WAV.");
        try (InputStream in = new BufferedInputStream(new FileInputStream(input), 128 * 1024);
             OutputStream out = new BufferedOutputStream(raw, 128 * 1024)) {
            byte[] buf = new byte[64 * 1024];
            int n;
            while ((n = in.read(buf)) >= 0) {
                if (n > 0) out.write(buf, 0, n);
            }
            out.flush();
        }
    }

    private static void writeWavHeader(OutputStream out, int sampleRate, int channels,
                                       long dataBytes) throws Exception {
        long byteRate = (long) sampleRate * channels * 2L;
        int blockAlign = channels * 2;
        out.write(new byte[]{'R','I','F','F'});
        writeLE32(out, 36L + dataBytes);
        out.write(new byte[]{'W','A','V','E','f','m','t',' '});
        writeLE32(out, 16L);
        writeLE16(out, 1);
        writeLE16(out, channels);
        writeLE32(out, sampleRate);
        writeLE32(out, byteRate);
        writeLE16(out, blockAlign);
        writeLE16(out, 16);
        out.write(new byte[]{'d','a','t','a'});
        writeLE32(out, dataBytes);
    }

    private static int readLE16(RandomAccessFile raf) throws Exception {
        int a = raf.readUnsignedByte();
        int b = raf.readUnsignedByte();
        return a | (b << 8);
    }

    private static long readLE32(RandomAccessFile raf) throws Exception {
        long a = raf.readUnsignedByte();
        long b = raf.readUnsignedByte();
        long c = raf.readUnsignedByte();
        long d = raf.readUnsignedByte();
        return a | (b << 8) | (c << 16) | (d << 24);
    }

    private static void writeLE16(OutputStream out, int v) throws Exception {
        out.write(v & 0xff);
        out.write((v >> 8) & 0xff);
    }

    private static void writeLE32(OutputStream out, long v) throws Exception {
        out.write((int) (v & 0xff));
        out.write((int) ((v >> 8) & 0xff));
        out.write((int) ((v >> 16) & 0xff));
        out.write((int) ((v >> 24) & 0xff));
    }

    private static void deleteRecursive(File f) {
        if (f == null || !f.exists()) return;
        if (f.isDirectory()) {
            File[] children = f.listFiles();
            if (children != null) for (File c : children) deleteRecursive(c);
        }
        try { f.delete(); } catch (Exception ignored) {}
    }
}
