package com.silence.looper;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.database.Cursor;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.os.PowerManager;
import android.provider.Settings;
import android.provider.OpenableColumns;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.speech.tts.Voice;
import android.view.View;
import android.view.WindowManager;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

/** Controla o modo Leitura: TXT/EPUB/PDF+OCR, segmentação, TTS e gravação. */
public final class ReadingController {
    public static final int REQ_OPEN = 2001;
    public static final int REQ_SAVE = 2002;

    private final Activity activity;
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ExecutorService executor = Executors.newSingleThreadExecutor();

    private final TextView txtFile;
    private final TextView txtSpeed;
    private final TextView txtStatus;
    private final TextView txtSegments;
    private final TextView txtCurrent;
    private final TextView txtPosition;
    private final SeekBar seekSpeed;
    private final SeekBar seekPosition;
    private final Spinner spnRepeats;
    private final Spinner spnPause;
    private final Spinner spnOutput;
    private final Spinner spnMinWords;
    private final Spinner spnMaxWords;
    private final Button btnOpen;
    private final Button btnVoice;
    private final Button btnPrepare;
    private final Button btnPrevious;
    private final Button btnPlay;
    private final Button btnStop;
    private final Button btnNext;
    private final Button btnSave;

    private TextToSpeech tts;
    private boolean ttsReady = false;
    private Voice selectedVoice;
    private Locale selectedLocale = Locale.getDefault();
    private Uri documentUri;
    private String documentName = "";
    private String documentText = "";
    private List<String> segments = new ArrayList<>();

    private int currentSegment = 0;
    private int currentRepeat = 0;
    private boolean sequencePlaying = false;
    private boolean userPaused = false;
    private boolean waitingPause = false;
    private long pauseRemainingMs = 0L;
    private long pauseDueAtMs = 0L;
    private boolean pendingSaveMp3 = true;
    private boolean continuousMode = false;
    private boolean loadingContinuous = false;
    private List<String> continuousChunks = new ArrayList<>();
    private int continuousIndex = 0;

    private final Runnable pauseRunnable = new Runnable() {
        @Override public void run() {
            if (userPaused || !sequencePlaying) return;
            waitingPause = false;
            pauseRemainingMs = 0L;
            pauseDueAtMs = 0L;
            speakCurrent();
        }
    };

    public ReadingController(Activity activity) {
        this.activity = activity;
        txtFile = activity.findViewById(R.id.txtReadFile);
        txtSpeed = activity.findViewById(R.id.txtReadSpeed);
        txtStatus = activity.findViewById(R.id.txtReadStatus);
        txtSegments = activity.findViewById(R.id.txtReadSegments);
        txtCurrent = activity.findViewById(R.id.txtReadCurrent);
        txtPosition = activity.findViewById(R.id.txtReadPosition);
        seekSpeed = activity.findViewById(R.id.seekReadSpeed);
        seekPosition = activity.findViewById(R.id.seekReadPosition);
        spnRepeats = activity.findViewById(R.id.spnReadRepeats);
        spnPause = activity.findViewById(R.id.spnReadPause);
        spnOutput = activity.findViewById(R.id.spnReadOutputFormat);
        spnMinWords = activity.findViewById(R.id.spnReadMinWords);
        spnMaxWords = activity.findViewById(R.id.spnReadMaxWords);
        btnOpen = activity.findViewById(R.id.btnReadOpen);
        btnVoice = activity.findViewById(R.id.btnReadVoice);
        btnPrepare = activity.findViewById(R.id.btnReadPrepare);
        btnPrevious = activity.findViewById(R.id.btnReadPrevious);
        btnPlay = activity.findViewById(R.id.btnReadPlay);
        btnStop = activity.findViewById(R.id.btnReadStop);
        btnNext = activity.findViewById(R.id.btnReadNext);
        btnSave = activity.findViewById(R.id.btnReadSave);

        setupUi();
        initTts();
    }

    private void setupUi() {
        String[] wordCounts = new String[10];
        for (int i = 0; i < wordCounts.length; i++) {
            int n = i + 1;
            wordCounts[i] = n + (n == 1 ? " palavra" : " palavras");
        }
        spnMinWords.setAdapter(new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item, wordCounts));
        spnMaxWords.setAdapter(new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item, wordCounts));
        spnMinWords.setSelection(1); // 2 palavras
        spnMaxWords.setSelection(5); // 6 palavras

        android.widget.AdapterView.OnItemSelectedListener wordRangeListener =
                new android.widget.AdapterView.OnItemSelectedListener() {
                    private boolean adjusting = false;

                    @Override public void onItemSelected(android.widget.AdapterView<?> parent,
                            View view, int position, long id) {
                        if (adjusting) return;
                        int min = spnMinWords.getSelectedItemPosition() + 1;
                        int max = spnMaxWords.getSelectedItemPosition() + 1;
                        if (min <= max) return;
                        adjusting = true;
                        if (parent.getId() == R.id.spnReadMinWords) {
                            spnMaxWords.setSelection(min - 1);
                        } else {
                            spnMinWords.setSelection(max - 1);
                        }
                        adjusting = false;
                    }

                    @Override public void onNothingSelected(android.widget.AdapterView<?> parent) {}
                };
        spnMinWords.setOnItemSelectedListener(wordRangeListener);
        spnMaxWords.setOnItemSelectedListener(wordRangeListener);

        spnRepeats.setAdapter(new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"1 vez", "2 vezes", "3 vezes"}));
        spnRepeats.setSelection(1);

        String[] pauses = new String[10];
        for (int i = 0; i < pauses.length; i++) {
            pauses[i] = (i + 1) + ((i + 1) == 1 ? " segundo" : " segundos");
        }
        spnPause.setAdapter(new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item, pauses));
        spnPause.setSelection(1);

        spnOutput.setAdapter(new ArrayAdapter<>(activity,
                android.R.layout.simple_spinner_dropdown_item,
                new String[]{"MP3 (192 kbps)", "WAV"}));
        spnOutput.setSelection(0);

        btnOpen.setOnClickListener(v -> openDocument());
        btnVoice.setOnClickListener(v -> showVoiceLanguageDialog());
        btnPrepare.setOnClickListener(v -> prepareDocument());
        btnPrevious.setOnClickListener(v -> changeSegment(-1));
        btnPlay.setOnClickListener(v -> togglePlayPause());
        btnStop.setOnClickListener(v -> stop());
        btnNext.setOnClickListener(v -> changeSegment(1));
        btnSave.setOnClickListener(v -> requestSave());

        // Toque simples = um trecho. Pressão longa = navegação acelerada,
        // também no modo de leitura contínua.
        btnPrevious.setOnTouchListener(
                new HoldRepeatTouchListener(() -> changeSegment(-1)));
        btnNext.setOnTouchListener(
                new HoldRepeatTouchListener(() -> changeSegment(1)));

        btnPrevious.setText("⏮");
        btnPlay.setText("▶");
        btnStop.setText("■");
        btnNext.setText("⏭");
        btnPrevious.setContentDescription("Trecho anterior");
        btnPlay.setContentDescription("Reproduzir / pausar leitura");
        btnStop.setContentDescription("Parar leitura");
        btnNext.setContentDescription("Trecho seguinte");

        seekSpeed.setMax(150);
        seekSpeed.setProgress(50);
        txtSpeed.setText("1,00×");
        seekSpeed.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                txtSpeed.setText(String.format(Locale.getDefault(), "%.2f×", getSpeed()));
                if (ttsReady && tts != null) tts.setSpeechRate(getSpeed());
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });

        seekPosition.setMax(1000);
        seekPosition.setProgress(0);
        seekPosition.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!fromUser) return;
                if (!segments.isEmpty()) {
                    int idx = Math.min(segments.size() - 1,
                            Math.max(0, Math.round((segments.size() - 1) * progress / 1000f)));
                    showSegment(idx);
                } else if (!continuousChunks.isEmpty()) {
                    int idx = Math.min(continuousChunks.size() - 1,
                            Math.max(0, Math.round((continuousChunks.size() - 1) * progress / 1000f)));
                    txtCurrent.setText(continuousChunks.get(idx));
                    txtPosition.setText("Leitura contínua " + (idx + 1)
                            + " / " + continuousChunks.size());
                }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                boolean wasPlaying = sequencePlaying && !userPaused;
                if (!segments.isEmpty()) {
                    int idx = Math.min(segments.size() - 1,
                            Math.max(0, Math.round((segments.size() - 1) * seekBar.getProgress() / 1000f)));
                    if (tts != null) tts.stop();
                    cancelPause();
                    currentSegment = idx;
                    currentRepeat = 0;
                    if (wasPlaying) {
                        sequencePlaying = true;
                        userPaused = false;
                        speakCurrent();
                    }
                } else if (!continuousChunks.isEmpty()) {
                    int idx = Math.min(continuousChunks.size() - 1,
                            Math.max(0, Math.round((continuousChunks.size() - 1) * seekBar.getProgress() / 1000f)));
                    if (tts != null) tts.stop();
                    continuousIndex = idx;
                    if (wasPlaying) {
                        continuousMode = true;
                        sequencePlaying = true;
                        userPaused = false;
                        speakContinuousCurrent();
                    }
                }
            }
        });
    }

    private void initTts() {
        txtStatus.setText("A iniciar o TTS do Android…");
        tts = new TextToSpeech(activity.getApplicationContext(), status -> {
            if (status == TextToSpeech.SUCCESS) {
                ttsReady = true;
                tts.setSpeechRate(getSpeed());
                restoreVoiceSelection();
                installTtsListener();
                activity.runOnUiThread(() -> txtStatus.setText(
                        "Abra um TXT, PDF ou EPUB para começar."));
            } else {
                ttsReady = false;
                activity.runOnUiThread(() -> txtStatus.setText(
                        "Não foi possível iniciar o TTS do Android."));
            }
        });
    }

    private void restoreVoiceSelection() {
        String voiceName = activity.getSharedPreferences("tts_prefs", Activity.MODE_PRIVATE)
                .getString("voice_name", "");
        String languageTag = activity.getSharedPreferences("tts_prefs", Activity.MODE_PRIVATE)
                .getString("language_tag", Locale.getDefault().toLanguageTag());
        selectedLocale = Locale.forLanguageTag(languageTag);
        selectedVoice = null;

        if (voiceName != null && !voiceName.isEmpty() && tts != null) {
            try {
                Set<Voice> voices = tts.getVoices();
                if (voices != null) {
                    for (Voice voice : voices) {
                        if (voiceName.equals(voice.getName())) {
                            selectedVoice = voice;
                            selectedLocale = voice.getLocale();
                            break;
                        }
                    }
                }
            } catch (Exception ignored) {}
        }
        applySelectedVoice();
    }

    private void applySelectedVoice() {
        if (tts == null || !ttsReady) return;
        try {
            if (selectedVoice != null) {
                int result = tts.setVoice(selectedVoice);
                if (result == TextToSpeech.SUCCESS) return;
            }
        } catch (Exception ignored) {}
        Locale locale = selectedLocale == null ? Locale.getDefault() : selectedLocale;
        tts.setLanguage(locale);
    }

    private void showVoiceLanguageDialog() {
        if (!ttsReady || tts == null) {
            toast("O TTS ainda não está disponível.");
            return;
        }

        List<Voice> voices = new ArrayList<>();
        try {
            Set<Voice> set = tts.getVoices();
            if (set != null) voices.addAll(set);
        } catch (Exception ignored) {}

        Collections.sort(voices, new Comparator<Voice>() {
            private int priority(Voice voice) {
                Locale locale = voice == null ? null : voice.getLocale();
                if (locale != null && "en".equalsIgnoreCase(locale.getLanguage())) {
                    if ("US".equalsIgnoreCase(locale.getCountry())) return 0;
                    if ("GB".equalsIgnoreCase(locale.getCountry())) return 1;
                }
                return 2;
            }

            @Override public int compare(Voice a, Voice b) {
                int pa = priority(a);
                int pb = priority(b);
                if (pa != pb) return Integer.compare(pa, pb);
                String la = voiceLabel(a).toLowerCase(Locale.ROOT);
                String lb = voiceLabel(b).toLowerCase(Locale.ROOT);
                return la.compareTo(lb);
            }
        });

        final List<Voice> availableVoices = voices;
        String[] items = new String[availableVoices.size() + 1];
        items[0] = "Automático — idioma do sistema (" + localeLabel(Locale.getDefault()) + ")";
        int checked = 0;
        for (int i = 0; i < availableVoices.size(); i++) {
            Voice voice = availableVoices.get(i);
            items[i + 1] = voiceLabel(voice);
            if (selectedVoice != null && selectedVoice.getName().equals(voice.getName())) {
                checked = i + 1;
            }
        }

        new AlertDialog.Builder(activity)
                .setTitle("Voz / idioma do TTS")
                .setSingleChoiceItems(items, checked, (dialog, which) -> {
                    if (which == 0) {
                        selectedVoice = null;
                        selectedLocale = Locale.getDefault();
                    } else {
                        selectedVoice = availableVoices.get(which - 1);
                        selectedLocale = selectedVoice.getLocale();
                    }
                    applySelectedVoice();
                    saveVoiceSelection();
                    dialog.dismiss();
                    toast("Voz TTS: " + currentVoiceLabel());
                })
                .setNegativeButton("Cancelar", null)
                .show();
    }

    private void saveVoiceSelection() {
        String voiceName = selectedVoice == null ? "" : selectedVoice.getName();
        Locale locale = selectedVoice != null ? selectedVoice.getLocale()
                : (selectedLocale == null ? Locale.getDefault() : selectedLocale);
        activity.getSharedPreferences("tts_prefs", Activity.MODE_PRIVATE).edit()
                .putString("voice_name", voiceName)
                .putString("language_tag", locale.toLanguageTag())
                .apply();
    }

    private String currentVoiceLabel() {
        if (selectedVoice != null) return voiceLabel(selectedVoice);
        return "Automático — " + localeLabel(selectedLocale == null ? Locale.getDefault() : selectedLocale);
    }

    private static String voiceLabel(Voice voice) {
        if (voice == null) return "Voz desconhecida";
        StringBuilder sb = new StringBuilder();
        sb.append(localeLabel(voice.getLocale()));
        sb.append(" — ").append(voice.getName());
        if (voice.isNetworkConnectionRequired()) sb.append(" (rede)");
        return sb.toString();
    }

    private static String localeLabel(Locale locale) {
        if (locale == null) return "Idioma desconhecido";
        String language = locale.getDisplayLanguage(Locale.getDefault());
        String country = locale.getDisplayCountry(Locale.getDefault());
        if (language == null || language.isEmpty()) language = locale.toLanguageTag();
        if (country != null && !country.isEmpty()) return language + " (" + country + ")";
        return language;
    }

    private void installTtsListener() {
        tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
            @Override public void onStart(String utteranceId) {}
            @Override public void onDone(String utteranceId) {
                if (utteranceId == null) return;
                if (utteranceId.startsWith("read_")) {
                    handler.post(ReadingController.this::advance);
                } else if (utteranceId.startsWith("continuous_")) {
                    handler.post(ReadingController.this::advanceContinuous);
                }
            }
            @Override public void onError(String utteranceId) {
                handler.post(() -> {
                    sequencePlaying = false;
                    userPaused = false;
                    updatePlayButton();
                    setScreenAwake(false);
                    PlaybackForegroundService.stop(activity);
                    stopHeadphoneKeepAlive();
                    txtStatus.setText("O TTS encontrou um erro durante a leitura.");
                });
            }
            @Override public void onError(String utteranceId, int errorCode) {
                onError(utteranceId);
            }
        });
    }

    private void openDocument() {
        Intent i = new Intent(Intent.ACTION_GET_CONTENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType("*/*");
        i.putExtra(Intent.EXTRA_MIME_TYPES, new String[]{
                "text/plain", "application/pdf", "application/epub+zip"
        });
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        activity.startActivityForResult(Intent.createChooser(i, "Abrir documento com"), REQ_OPEN);
    }

    private void prepareDocument() {
        if (documentUri == null) {
            toast("Selecione primeiro um TXT, PDF ou EPUB.");
            return;
        }
        stop();
        continuousMode = false;
        setBusy(true);
        txtStatus.setText("A preparar o texto…");
        txtSegments.setText("Trechos: …");
        executor.execute(() -> {
            try {
                String text = TextDocumentLoader.load(activity, documentUri, documentName,
                        message -> activity.runOnUiThread(() -> txtStatus.setText(message)));
                List<String> built = TextSegmenter.segment(text, getMinWords(), getMaxWords());
                if (built.isEmpty()) throw new IllegalStateException("Não foi encontrado texto legível.");
                documentText = text;
                segments = built;
                currentSegment = 0;
                currentRepeat = 0;
                activity.runOnUiThread(() -> {
                    txtSegments.setText("Trechos: " + segments.size());
                    txtStatus.setText("Texto preparado.");
                    seekPosition.setProgress(0);
                    showSegment(0);
                    setBusy(false);
                });
            } catch (Throwable e) {
                activity.runOnUiThread(() -> {
                    segments.clear();
                    txtSegments.setText("Trechos: 0");
                    txtCurrent.setText("");
                    String msg = e.getMessage();
                    if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
                    txtStatus.setText("Erro ao preparar texto: " + msg);
                    setBusy(false);
                });
            }
        });
    }

    private void setScreenAwake(boolean keepOn) {
        if (keepOn) {
            activity.getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        } else {
            activity.getWindow().clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        }
    }

    private void togglePlayPause() {
        if (sequencePlaying) {
            pauseOrResume();
        } else {
            play();
        }
    }

    private void updatePlayButton() {
        btnPlay.setText(sequencePlaying && !userPaused ? "⏸" : "▶");
    }

    private void changeSegment(int delta) {
        if (segments.isEmpty()) {
            if (continuousChunks.isEmpty()) {
                toast("Ainda não existem trechos nem leitura contínua preparada.");
                return;
            }
            int next = Math.max(0, Math.min(continuousChunks.size() - 1, continuousIndex + delta));
            if (next == continuousIndex) return;
            boolean active = sequencePlaying;
            boolean paused = userPaused;
            if (tts != null) tts.stop();
            continuousIndex = next;
            txtCurrent.setText(continuousChunks.get(continuousIndex));
            txtPosition.setText("Leitura contínua " + (continuousIndex + 1)
                    + " / " + continuousChunks.size());
            if (active && !paused) {
                continuousMode = true;
                sequencePlaying = true;
                userPaused = false;
                speakContinuousCurrent();
            }
            return;
        }

        int next = Math.max(0, Math.min(segments.size() - 1, currentSegment + delta));
        if (next == currentSegment) {
            showSegment(currentSegment);
            return;
        }

        boolean active = sequencePlaying;
        boolean paused = userPaused;
        cancelPause();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }
        currentSegment = next;
        currentRepeat = 0;
        showSegment(currentSegment);

        if (active && !paused) {
            sequencePlaying = true;
            userPaused = false;
            updatePlayButton();
            setScreenAwake(true);
            PlaybackForegroundService.start(activity);
            startHeadphoneKeepAliveIfEnabled();
            speakCurrent();
        } else if (active) {
            sequencePlaying = true;
            userPaused = true;
            txtStatus.setText("Leitura em pausa — trecho " + (currentSegment + 1)
                    + "/" + segments.size() + ".");
        } else {
            txtStatus.setText("Trecho " + (currentSegment + 1) + "/" + segments.size() + ".");
        }
        updatePlayButton();
    }

    private void play() {
        if (!ttsReady || tts == null) {
            toast("O TTS ainda não está disponível.");
            return;
        }
        if (documentUri == null) {
            toast("Selecione primeiro um TXT, PDF ou EPUB.");
            return;
        }
        if (segments.isEmpty()) {
            startContinuousReading();
            return;
        }

        continuousMode = false;
        int requestedStart = currentSegment;
        stopInternal(false);
        currentSegment = Math.max(0, Math.min(segments.size() - 1, requestedStart));
        currentRepeat = 0;
        sequencePlaying = true;
        userPaused = false;
        updatePlayButton();
        setScreenAwake(true);
        PlaybackForegroundService.start(activity);
        long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
        requestBatteryOptimizationExemptionOnce();
        Runnable beginSpeech = () -> {
            if (sequencePlaying && !userPaused && !continuousMode) speakCurrent();
        };
        if (antiCutDelay > 0L) handler.postDelayed(beginSpeech, antiCutDelay);
        else beginSpeech.run();
    }

    private void startContinuousReading() {
        if (loadingContinuous) return;
        if (documentText == null || documentText.trim().isEmpty()) {
            loadingContinuous = true;
            setBusy(true);
            txtStatus.setText("A preparar leitura contínua…");
            executor.execute(() -> {
                try {
                    String text = TextDocumentLoader.load(activity, documentUri, documentName,
                            message -> activity.runOnUiThread(() -> txtStatus.setText(message)));
                    List<String> chunks = buildContinuousChunks(text);
                    if (chunks.isEmpty()) {
                        throw new IllegalStateException("Não foi encontrado texto legível.");
                    }
                    documentText = text;
                    continuousChunks = chunks;
                    activity.runOnUiThread(() -> {
                        loadingContinuous = false;
                        setBusy(false);
                        beginContinuousPlayback(0);
                    });
                } catch (Throwable e) {
                    activity.runOnUiThread(() -> {
                        loadingContinuous = false;
                        setBusy(false);
                        String msg = e.getMessage();
                        if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
                        txtStatus.setText("Erro ao preparar leitura: " + msg);
                    });
                }
            });
            return;
        }

        if (continuousChunks.isEmpty()) continuousChunks = buildContinuousChunks(documentText);
        beginContinuousPlayback(Math.max(0, Math.min(continuousChunks.size() - 1, continuousIndex)));
    }

    private void beginContinuousPlayback(int startIndex) {
        if (continuousChunks.isEmpty()) return;
        if (tts != null) tts.stop();
        cancelPause();
        continuousMode = true;
        continuousIndex = Math.max(0, Math.min(continuousChunks.size() - 1, startIndex));
        sequencePlaying = true;
        userPaused = false;
        updatePlayButton();
        setScreenAwake(true);
        PlaybackForegroundService.start(activity);
        long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
        requestBatteryOptimizationExemptionOnce();
        Runnable beginSpeech = () -> {
            if (sequencePlaying && !userPaused && continuousMode) speakContinuousCurrent();
        };
        if (antiCutDelay > 0L) handler.postDelayed(beginSpeech, antiCutDelay);
        else beginSpeech.run();
    }

    private void speakContinuousCurrent() {
        if (!continuousMode || !sequencePlaying || userPaused
                || continuousChunks.isEmpty() || continuousIndex >= continuousChunks.size()) return;
        String text = continuousChunks.get(continuousIndex);
        txtCurrent.setText(text);
        txtPosition.setText("Leitura contínua " + (continuousIndex + 1)
                + " / " + continuousChunks.size());
        if (continuousChunks.size() > 1) {
            seekPosition.setProgress(Math.round(continuousIndex * 1000f
                    / (continuousChunks.size() - 1)));
        } else {
            seekPosition.setProgress(0);
        }
        txtStatus.setText("Leitura contínua — "
                + String.format(Locale.getDefault(), "%.2f×", getSpeed()) + ".");
        tts.setSpeechRate(getSpeed());
        applySelectedVoice();
        String id = "continuous_" + continuousIndex + "_" + System.nanoTime();
        int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, new Bundle(), id);
        if (r != TextToSpeech.SUCCESS) {
            sequencePlaying = false;
            userPaused = false;
            continuousMode = false;
            updatePlayButton();
            setScreenAwake(false);
            PlaybackForegroundService.stop(activity);
            stopHeadphoneKeepAlive();
            txtStatus.setText("O TTS não conseguiu iniciar a leitura.");
        }
    }

    private void advanceContinuous() {
        if (!continuousMode || !sequencePlaying || userPaused) return;
        continuousIndex++;
        if (continuousIndex >= continuousChunks.size()) {
            sequencePlaying = false;
            userPaused = false;
            continuousMode = false;
            continuousIndex = 0;
            updatePlayButton();
            setScreenAwake(false);
            PlaybackForegroundService.stop(activity);
            stopHeadphoneKeepAlive();
            seekPosition.setProgress(0);
            txtPosition.setText("Leitura contínua 1 / " + continuousChunks.size());
            if (!continuousChunks.isEmpty()) txtCurrent.setText(continuousChunks.get(0));
            txtStatus.setText("Leitura concluída.");
            return;
        }
        speakContinuousCurrent();
    }

    private List<String> buildContinuousChunks(String text) {
        List<String> out = new ArrayList<>();
        if (text == null) return out;
        String normalized = text.replace('\r', '\n').replaceAll("[ \t]+", " ")
                .replaceAll("\n{3,}", "\n\n").trim();
        if (normalized.isEmpty()) return out;

        final int maxChars = 2400;
        int pos = 0;
        while (pos < normalized.length()) {
            int remaining = normalized.length() - pos;
            if (remaining <= maxChars) {
                String part = normalized.substring(pos).trim();
                if (!part.isEmpty()) out.add(part);
                break;
            }
            int hardEnd = pos + maxChars;
            int minEnd = Math.min(hardEnd, pos + 1000);
            int cut = -1;
            for (int i = hardEnd; i >= minEnd; i--) {
                char c = normalized.charAt(i - 1);
                if (c == '.' || c == '!' || c == '?' || c == '\n' || c == ';' || c == ':') {
                    cut = i;
                    break;
                }
            }
            if (cut < 0) {
                int space = normalized.lastIndexOf(' ', hardEnd);
                cut = space > pos ? space : hardEnd;
            }
            String part = normalized.substring(pos, cut).trim();
            if (!part.isEmpty()) out.add(part);
            pos = Math.max(cut, pos + 1);
            while (pos < normalized.length() && Character.isWhitespace(normalized.charAt(pos))) pos++;
        }
        return out;
    }

    private void speakCurrent() {
        if (!sequencePlaying || userPaused || segments.isEmpty()
                || currentSegment < 0 || currentSegment >= segments.size()) return;
        waitingPause = false;
        String text = segments.get(currentSegment);
        showSegment(currentSegment);
        txtStatus.setText("Trecho " + (currentSegment + 1) + "/" + segments.size()
                + " — repetição " + (currentRepeat + 1) + "/" + getRepeats());
        tts.setSpeechRate(getSpeed());
        applySelectedVoice();
        Bundle params = new Bundle();
        String id = "read_" + currentSegment + "_" + currentRepeat + "_" + System.nanoTime();
        int r = tts.speak(text, TextToSpeech.QUEUE_FLUSH, params, id);
        if (r != TextToSpeech.SUCCESS) {
            sequencePlaying = false;
            userPaused = false;
            updatePlayButton();
            setScreenAwake(false);
            PlaybackForegroundService.stop(activity);
            stopHeadphoneKeepAlive();
            txtStatus.setText("O TTS não conseguiu iniciar a leitura.");
        }
    }

    private void advance() {
        if (!sequencePlaying || userPaused) return;
        currentRepeat++;
        if (currentRepeat >= getRepeats()) {
            currentRepeat = 0;
            currentSegment++;
        }
        if (currentSegment >= segments.size()) {
            sequencePlaying = false;
            userPaused = false;
            currentSegment = 0;
            currentRepeat = 0;
            showSegment(0);
            updatePlayButton();
            setScreenAwake(false);
            PlaybackForegroundService.stop(activity);
            stopHeadphoneKeepAlive();
            txtStatus.setText("Leitura concluída.");
            return;
        }
        startPause();
    }

    private void startPause() {
        cancelPause();
        waitingPause = true;
        pauseRemainingMs = getPauseSeconds() * 1000L;
        pauseDueAtMs = android.os.SystemClock.uptimeMillis() + pauseRemainingMs;
        txtStatus.setText("Pausa — próximo: trecho " + (currentSegment + 1)
                + "/" + segments.size() + ".");
        handler.postDelayed(pauseRunnable, pauseRemainingMs);
    }

    private void pauseOrResume() {
        if (!sequencePlaying) {
            toast("Não existe leitura ativa.");
            return;
        }
        if (!userPaused) {
            userPaused = true;
            if (waitingPause) {
                pauseRemainingMs = Math.max(0L,
                        pauseDueAtMs - android.os.SystemClock.uptimeMillis());
                handler.removeCallbacks(pauseRunnable);
            } else if (tts != null) {
                // Android TTS não tem pausa real; ao retomar reinicia o trecho atual.
                tts.stop();
            }
            PlaybackForegroundService.stop(activity);
            stopHeadphoneKeepAlive();
            setScreenAwake(false);
            updatePlayButton();
            txtStatus.setText("Leitura em pausa.");
        } else {
            userPaused = false;
            updatePlayButton();
            setScreenAwake(true);
            PlaybackForegroundService.start(activity);
            long antiCutDelay = startHeadphoneKeepAliveAndGetPreRollMs();
            requestBatteryOptimizationExemptionOnce();
            if (waitingPause) {
                pauseDueAtMs = android.os.SystemClock.uptimeMillis() + pauseRemainingMs;
                handler.postDelayed(pauseRunnable, pauseRemainingMs);
            } else {
                Runnable resumeSpeech = () -> {
                    if (!sequencePlaying || userPaused) return;
                    if (continuousMode) speakContinuousCurrent();
                    else speakCurrent();
                };
                if (antiCutDelay > 0L) handler.postDelayed(resumeSpeech, antiCutDelay);
                else resumeSpeech.run();
            }
        }
    }

    public void stop() {
        stopInternal(true);
    }

    private void stopInternal(boolean updateStatus) {
        sequencePlaying = false;
        userPaused = false;
        continuousMode = false;
        continuousIndex = 0;
        currentSegment = 0;
        currentRepeat = 0;
        cancelPause();
        if (tts != null) {
            try { tts.stop(); } catch (Exception ignored) {}
        }
        setScreenAwake(false);
        PlaybackForegroundService.stop(activity);
        stopHeadphoneKeepAlive();
        seekPosition.setProgress(0);
        if (!segments.isEmpty()) {
            showSegment(0);
        } else if (!continuousChunks.isEmpty()) {
            continuousIndex = 0;
            txtCurrent.setText(continuousChunks.get(0));
            txtPosition.setText("Leitura contínua 1 / " + continuousChunks.size());
        } else {
            txtPosition.setText("Leitura contínua 0 / 0");
        }
        updatePlayButton();
        if (updateStatus) {
            txtStatus.setText(documentUri == null
                    ? "Abra um TXT, PDF ou EPUB para começar."
                    : "Leitura parada.");
        }
    }

    private void cancelPause() {
        handler.removeCallbacks(pauseRunnable);
        waitingPause = false;
        pauseRemainingMs = 0L;
        pauseDueAtMs = 0L;
    }

    private void showSegment(int idx) {
        if (segments.isEmpty() || idx < 0 || idx >= segments.size()) {
            txtCurrent.setText("");
            txtPosition.setText("Trecho 0 / 0");
            return;
        }
        txtCurrent.setText(segments.get(idx));
        txtPosition.setText("Trecho " + (idx + 1) + " / " + segments.size());
        if (segments.size() > 1) {
            seekPosition.setProgress(Math.round(idx * 1000f / (segments.size() - 1)));
        } else {
            seekPosition.setProgress(0);
        }
    }

    private void requestSave() {
        if (documentUri == null) {
            toast("Selecione primeiro um TXT, PDF ou EPUB.");
            return;
        }
        pendingSaveMp3 = spnOutput.getSelectedItemPosition() == 0;
        Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
        i.addCategory(Intent.CATEGORY_OPENABLE);
        i.setType(pendingSaveMp3 ? "audio/mpeg" : "audio/wav");
        i.putExtra(Intent.EXTRA_TITLE,
                pendingSaveMp3 ? "silence_looper_leitura.mp3" : "silence_looper_leitura.wav");
        activity.startActivityForResult(i, REQ_SAVE);
    }

    private void export(Uri outUri) {
        stop();
        setBusy(true);
        txtStatus.setText("A preparar gravação TTS…");
        List<String> snapshot = new ArrayList<>(segments);
        final boolean usePreparedSegments = !snapshot.isEmpty();
        int repeats = usePreparedSegments ? getRepeats() : 1;
        int pause = usePreparedSegments ? getPauseSeconds() : 0;
        float speed = getSpeed();
        boolean mp3 = pendingSaveMp3;

        executor.execute(() -> {
            try {
                List<String> exportText = snapshot;
                if (!usePreparedSegments) {
                    String text = documentText;
                    if (text == null || text.trim().isEmpty()) {
                        text = TextDocumentLoader.load(activity, documentUri, documentName,
                                message -> activity.runOnUiThread(() -> txtStatus.setText(message)));
                        documentText = text;
                    }
                    exportText = buildContinuousChunks(text);
                    if (exportText.isEmpty()) {
                        throw new IllegalStateException("Não foi encontrado texto legível.");
                    }
                }
                String voiceName = selectedVoice == null ? null : selectedVoice.getName();
                Locale locale = selectedVoice != null ? selectedVoice.getLocale()
                        : (selectedLocale == null ? Locale.getDefault() : selectedLocale);
                TtsAudioExporter.export(activity, outUri, mp3, exportText, repeats, pause, speed,
                        voiceName, locale.toLanguageTag(),
                        message -> activity.runOnUiThread(() -> txtStatus.setText(message)));
                activity.runOnUiThread(() -> {
                    txtStatus.setText(mp3 ? "MP3 da leitura gravado com sucesso."
                            : "WAV da leitura gravado com sucesso.");
                    setBusy(false);
                });
            } catch (Throwable e) {
                activity.runOnUiThread(() -> {
                    String msg = e.getMessage();
                    if (msg == null || msg.trim().isEmpty()) msg = e.getClass().getSimpleName();
                    txtStatus.setText("Erro ao gravar leitura: " + msg);
                    setBusy(false);
                });
            }
        });
    }

    public boolean handleActivityResult(int requestCode, int resultCode, Intent data) {
        if (requestCode != REQ_OPEN && requestCode != REQ_SAVE) return false;
        if (resultCode != Activity.RESULT_OK || data == null || data.getData() == null) return true;
        Uri uri = data.getData();
        if (requestCode == REQ_OPEN) {
            stop();
            documentUri = uri;
            documentName = getDisplayName(uri);
            documentText = "";
            continuousChunks.clear();
            continuousIndex = 0;
            continuousMode = false;
            segments.clear();
            currentSegment = 0;
            currentRepeat = 0;
            txtFile.setText(documentName);
            txtSegments.setText("Trechos: 0");
            txtCurrent.setText("");
            txtPosition.setText("Trecho 0 / 0");
            seekPosition.setProgress(0);
            txtStatus.setText("Ficheiro carregado. Pode ler diretamente ou preparar trechos para repetições.");
        } else {
            export(uri);
        }
        return true;
    }

    private String getDisplayName(Uri uri) {
        String name = uri.getLastPathSegment();
        Cursor c = null;
        try {
            c = activity.getContentResolver().query(
                    uri, new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null);
            if (c != null && c.moveToFirst()) {
                int idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME);
                if (idx >= 0) name = c.getString(idx);
            }
        } catch (Exception ignored) {
        } finally {
            if (c != null) c.close();
        }
        return name == null ? "Documento selecionado" : name;
    }

    private void requestBatteryOptimizationExemptionOnce() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return;
        boolean alreadyAsked = activity.getSharedPreferences("playback_prefs", Activity.MODE_PRIVATE)
                .getBoolean("battery_exemption_prompted", false);
        if (alreadyAsked) return;

        PowerManager pm = (PowerManager) activity.getSystemService(Activity.POWER_SERVICE);
        if (pm == null || pm.isIgnoringBatteryOptimizations(activity.getPackageName())) return;

        activity.getSharedPreferences("playback_prefs", Activity.MODE_PRIVATE).edit()
                .putBoolean("battery_exemption_prompted", true).apply();
        try {
            Intent intent = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            intent.setData(Uri.parse("package:" + activity.getPackageName()));
            activity.startActivity(intent);
        } catch (Exception ignored) {
            try {
                activity.startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception ignoredToo) {}
        }
    }

    boolean isPlaybackActive() {
        return sequencePlaying && !userPaused;
    }

    private void startHeadphoneKeepAliveIfEnabled() {
        if (activity instanceof MainActivity) {
            ((MainActivity) activity).startHeadphoneKeepAliveIfEnabled();
        }
    }

    private long startHeadphoneKeepAliveAndGetPreRollMs() {
        if (activity instanceof MainActivity) {
            return ((MainActivity) activity).startHeadphoneKeepAliveAndGetPreRollMs();
        }
        return 0L;
    }

    private void stopHeadphoneKeepAlive() {
        if (activity instanceof MainActivity) {
            ((MainActivity) activity).stopHeadphoneKeepAlive();
        }
    }

    private int getMinWords() {
        return spnMinWords.getSelectedItemPosition() + 1;
    }

    private int getMaxWords() {
        return spnMaxWords.getSelectedItemPosition() + 1;
    }

    private int getRepeats() {
        return spnRepeats.getSelectedItemPosition() + 1;
    }

    private int getPauseSeconds() {
        return spnPause.getSelectedItemPosition() + 1;
    }

    private float getSpeed() {
        return 0.5f + seekSpeed.getProgress() / 100f;
    }

    private void setBusy(boolean busy) {
        btnOpen.setEnabled(!busy);
        btnVoice.setEnabled(!busy);
        btnPrepare.setEnabled(!busy);
        btnPrevious.setEnabled(!busy);
        btnPlay.setEnabled(!busy);
        btnStop.setEnabled(!busy);
        btnNext.setEnabled(!busy);
        btnSave.setEnabled(!busy);
        spnMinWords.setEnabled(!busy);
        spnMaxWords.setEnabled(!busy);
    }

    private void toast(String s) {
        Toast.makeText(activity, s, Toast.LENGTH_SHORT).show();
    }

    public void destroy() {
        stopInternal(false);
        executor.shutdownNow();
        if (tts != null) {
            try { tts.shutdown(); } catch (Exception ignored) {}
            tts = null;
        }
    }
}
