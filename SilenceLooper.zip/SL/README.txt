Silence Looper 3.4.1

Projeto Android nativo para compilar com o APK Builder em modo "projeto Android existente".

Alterações desta versão:
- corrigida a barra de posição e o tempo na reprodução contínua sem trechos;
- arrastar a barra em reprodução contínua passa a fazer seek real sem reiniciar o ficheiro;
- reprodução de áudio contínua, com velocidade ajustável, sem necessidade de detetar trechos;
- leitura TTS contínua, com velocidade ajustável, sem necessidade de preparar trechos;
- gravação continua a funcionar com ou sem trechos preparados;
- seletor de abertura passa a usar ACTION_GET_CONTENT/chooser para permitir gestores de ficheiros de terceiros compatíveis;
- removido o descodificador antigo em memória que existia apenas por compatibilidade interna;
- modo por trechos, repetições, pausas, TTS, OCR, MP3/WAV e reprodução em segundo plano mantidos.

Build: SDK 36 / Java 17.
Package: com.silence.looper
Version: 3.4.1 (56)


Versão: 3.1.6


Versão 3.2.2
- MP4 aberto diretamente pelo Media3 em modo áudio-only (faixa de vídeo desativada).
- Duração lida pelo índice/timeline do container sem percorrer o ficheiro inteiro.
- Removida a preparação/remux obrigatório da faixa áudio antes de permitir seek.

Versão 3.2.3
- Corrigida a duração de MP4 fragmentados, nos quais mvhd declara duração zero.
- A duração passa a ser obtida saltando pelo índice mfra/tfra para o último
  fragmento de áudio, sem percorrer nem descodificar o vídeo inteiro.
- Adicionado fallback de leitura do moov inicial para content:// expostos como pipe.

Versão 3.2.4
- Corrigido o slider que regressava imediatamente a 00:00 em MP4 fragmentados.
- Depois de mostrar rapidamente a duração, a app remuxa apenas a faixa AAC para
  um M4A temporário, sem recodificação, criando um índice compatível com o Media3.
- O slider é ativado quando a faixa navegável fica pronta.

Versão 3.2.5
- A preparação da navegação do MP4 só começa no primeiro clique em Play.
- A deteção de silêncios pode ser executada primeiro, sem competir com a preparação.
- A reprodução arranca automaticamente quando a faixa navegável fica pronta.
- Eliminada uma segunda leitura de metadata no fim da remuxagem.

Versão 3.3.0
- Atualizada a Media3 para uma versão com suporte nativo ao índice mfra/tfra.
- Removida por completo a preparação/remuxagem lenta da navegação.
- Play e o slider usam diretamente o MP4 fragmentado e ficam disponíveis de imediato.
- Detetar trechos permanece uma operação independente e nunca dispara preparação.

Versão 3.3.1
- A deteção recebe a duração já calculada quando o MP4 fragmentado declara zero na faixa AAC.
- Ativado explicitamente FLAG_READ_MFRA_FOR_SEEK_MAP no player, sem depender dos defaults.

Versão 3.3.2
- MP4 fragmentado é analisado numa única passagem sequencial.
- Evitados os seeks paralelos incompatíveis do MediaExtractor que reiniciavam em zero
  e faziam a deteção descodificar o ficheiro várias vezes.

Versão 3.3.3
- A duração do MP4 continua a ser calculada automaticamente ao selecionar o ficheiro.
- Detetar trechos cria uma cópia local temporária e rápida apenas para a análise.
- A cópia fornece comprimento e acesso aleatório fiáveis aos blocos paralelos,
  evitando uma descodificação sequencial quase em tempo real.
- A cópia temporária é eliminada automaticamente no fim da deteção.

Versão 3.3.4
- A duração de um trecho já não substitui a duração total da fonte.
- Slider e relógio acompanham novamente cada trecho e cada repetição.
- Análise limitada a dois MediaCodec para evitar contenção do decoder AAC.
- Removida a segunda descodificação sequencial automática após a análise paralela.
- Envelope de silêncio reduzido para 800 amostras/s, mantendo 32 medições por janela.

Versão 3.3.5
- Análise AAC esparsa: dois pacotes consecutivos a cada 160 ms.
- Cerca de 70% menos pacotes enviados individualmente ao MediaCodec.
- Mantidas várias medições por pausa mínima de 1 segundo e margem conservadora
  nas transições entre fala e silêncio.

Versão 3.3.9
- Nova opção global «Anti-corte dos auriculares», válida nos modos Leitura e Áudio.
- Quando ativa, reproduz continuamente um ruído branco de nível muito baixo no stream multimédia para impedir que auriculares com noise gate/poupança de energia fechem a saída durante silêncios.
- O sinal mantém-se durante as pausas automáticas entre trechos/repetições e para em pausa manual, Stop ou fim da reprodução.
- O sinal anti-corte é apenas de reprodução e não é incluído nos ficheiros WAV/MP3 exportados.

Versão 3.4.1
- Renovação visual sem alteração do ambiente de compilação.
- Fundo e superfícies com hierarquia mais clara, painéis arredondados e melhor espaçamento.
- Botões Leitura/Áudio convertidos num seletor visual moderno.
- Botões de transporte redesenhados e botões de gravação destacados.
- Caixa de leitura com cartão próprio e cores consistentes.
- Suporte visual Day/Night através de paleta própria.
- Nenhuma alteração à lógica de reprodução, deteção, TTS, OCR, exportação ou anti-corte adaptativo.


Versão 3.4.2: pressão longa nos botões de trecho anterior/seguinte acelera progressivamente a navegação.
