# Sem regras especiais. O projeto não usa reflexão de bibliotecas externas.
