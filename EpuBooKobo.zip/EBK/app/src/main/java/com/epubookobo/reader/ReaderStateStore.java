package com.epubookobo.reader;

import android.content.Context;
import android.net.Uri;

import org.json.JSONObject;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.charset.StandardCharsets;

public final class ReaderStateStore {
    public static final int DEFAULT_FONT_SIZE = 18;
    public static final float DEFAULT_LINE_SPACING = 1.40f;
    public static final int MIN_FONT_SIZE = 10;
    public static final int MAX_FONT_SIZE = 28;
    public static final float MIN_LINE_SPACING = 1.10f;
    public static final float MAX_LINE_SPACING = 2.20f;
    public static final int DEFAULT_SIDE_MARGIN_DP = 20;
    public static final int MIN_SIDE_MARGIN_DP = 8;
    public static final int MAX_SIDE_MARGIN_DP = 80;
    public static final int DEFAULT_BACKGROUND_TEMPERATURE = 50;
    public static final int MIN_BACKGROUND_TEMPERATURE = 0;
    public static final int MAX_BACKGROUND_TEMPERATURE = 100;

    private final File stateFile;

    public ReaderStateStore(Context context) {
        stateFile = new File(context.getFilesDir(), "epubookobo.json");
    }

    public SavedState read(String bookKey) {
        JSONObject root = readRoot();
        JSONObject books = root.optJSONObject("books");
        JSONObject entry = books == null ? null : books.optJSONObject(bookKey);
        if (entry == null) {
            return new SavedState(0, DEFAULT_FONT_SIZE, DEFAULT_LINE_SPACING,
                    DEFAULT_SIDE_MARGIN_DP, DEFAULT_BACKGROUND_TEMPERATURE);
        }

        int page = Math.max(0, entry.optInt("page_index", 0));
        int font = entry.optInt("font_size", DEFAULT_FONT_SIZE);
        font = Math.max(MIN_FONT_SIZE, Math.min(MAX_FONT_SIZE, font));
        float spacing = (float) entry.optDouble("line_spacing", DEFAULT_LINE_SPACING);
        spacing = Math.max(MIN_LINE_SPACING, Math.min(MAX_LINE_SPACING, spacing));
        int sideMargin = entry.optInt("side_margin_dp", DEFAULT_SIDE_MARGIN_DP);
        sideMargin = Math.max(MIN_SIDE_MARGIN_DP, Math.min(MAX_SIDE_MARGIN_DP, sideMargin));

        int temperature = entry.optInt("background_temperature", DEFAULT_BACKGROUND_TEMPERATURE);
        temperature = Math.max(MIN_BACKGROUND_TEMPERATURE, Math.min(MAX_BACKGROUND_TEMPERATURE, temperature));
        return new SavedState(page, font, Math.round(spacing * 100f) / 100f, sideMargin, temperature);
    }

    public void save(BookData book,
                     Uri uri,
                     int currentPage,
                     int totalPages,
                     int fontSize,
                     float lineSpacing,
                     int sideMarginDp,
                     int backgroundTemperature) throws Exception {
        JSONObject root = readRoot();
        JSONObject books = root.optJSONObject("books");
        if (books == null) {
            books = new JSONObject();
            root.put("books", books);
        }

        JSONObject entry = new JSONObject();
        entry.put("book_id", book.key);
        entry.put("uri", uri == null ? "" : uri.toString());
        entry.put("title", book.title);
        entry.put("page_index", currentPage);
        entry.put("page_number", currentPage + 1);
        entry.put("total_pages", totalPages);
        entry.put("progress_percent", totalPages > 0
                ? Math.round((((currentPage + 1d) / totalPages) * 10000d)) / 100d
                : 0d);
        entry.put("font_size", fontSize);
        entry.put("line_spacing", Math.round(lineSpacing * 100f) / 100f);
        entry.put("side_margin_dp", Math.max(MIN_SIDE_MARGIN_DP,
                Math.min(MAX_SIDE_MARGIN_DP, sideMarginDp)));
        entry.put("background_temperature", Math.max(MIN_BACKGROUND_TEMPERATURE,
                Math.min(MAX_BACKGROUND_TEMPERATURE, backgroundTemperature)));
        books.put(book.key, entry);

        byte[] data = root.toString(2).getBytes(StandardCharsets.UTF_8);
        try (FileOutputStream out = new FileOutputStream(stateFile)) {
            out.write(data);
        }
    }

    public File getStateFile() {
        return stateFile;
    }

    private JSONObject readRoot() {
        if (!stateFile.isFile()) {
            return emptyRoot();
        }
        try (FileInputStream in = new FileInputStream(stateFile)) {
            byte[] data = new byte[(int) Math.min(Integer.MAX_VALUE, stateFile.length())];
            int offset = 0;
            while (offset < data.length) {
                int read = in.read(data, offset, data.length - offset);
                if (read < 0) break;
                offset += read;
            }
            JSONObject root = new JSONObject(new String(data, 0, offset, StandardCharsets.UTF_8));
            if (root.optJSONObject("books") == null) root.put("books", new JSONObject());
            return root;
        } catch (Exception ignored) {
            return emptyRoot();
        }
    }

    private JSONObject emptyRoot() {
        JSONObject root = new JSONObject();
        try {
            root.put("books", new JSONObject());
        } catch (Exception ignored) {
        }
        return root;
    }

    public static final class SavedState {
        public final int pageIndex;
        public final int fontSize;
        public final float lineSpacing;
        public final int sideMarginDp;
        public final int backgroundTemperature;

        SavedState(int pageIndex, int fontSize, float lineSpacing, int sideMarginDp, int backgroundTemperature) {
            this.pageIndex = pageIndex;
            this.fontSize = fontSize;
            this.lineSpacing = lineSpacing;
            this.sideMarginDp = sideMarginDp;
            this.backgroundTemperature = backgroundTemperature;
        }
    }
}
