package com.epubookobo.reader;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.util.AttributeSet;
import android.os.Build;
import android.os.Handler;
import android.os.Looper;
import android.view.DisplayCutout;
import android.view.HapticFeedbackConstants;
import android.view.MotionEvent;
import android.view.WindowInsets;
import android.view.View;
import android.view.ViewConfiguration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Locale;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public final class ReaderView extends View {
    private static final int FRAME_COLOR = Color.rgb(43, 43, 43);
    private static final int SCREEN_COLOR = Color.rgb(232, 230, 225);
    private static final int TEXT_COLOR = Color.rgb(26, 26, 26);
    private static final int META_COLOR = Color.rgb(58, 58, 58);
    private static final int LOGO_COLOR = Color.rgb(154, 154, 154);
    private static final Pattern WORD_PATTERN = Pattern.compile("\\S+");

    private final Paint framePaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint screenPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint metaPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint chapterPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint logoPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final Paint selectionPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint brightnessHudPaint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint brightnessHudTextPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final RectF screenRect = new RectF();
    private final List<WordHit> wordHits = new ArrayList<>();
    private final Handler gestureHandler = new Handler(Looper.getMainLooper());

    private BookData book;
    private List<PageData> pages = Collections.emptyList();
    private List<Integer> pageOfChapter = Collections.emptyList();
    private int currentPage = 0;
    private int fontSizeSp = ReaderStateStore.DEFAULT_FONT_SIZE;
    private float lineSpacing = ReaderStateStore.DEFAULT_LINE_SPACING;
    private int sideMarginDp = ReaderStateStore.DEFAULT_SIDE_MARGIN_DP;
    private int backgroundTemperature = ReaderStateStore.DEFAULT_BACKGROUND_TEMPERATURE;
    private int lineHeightPx = 1;
    private int systemSafeInsetTopPx = 0;
    private String loadingMessage;

    private float downX;
    private float downY;
    private boolean pointerDown;
    private boolean movedBeyondSlop;
    private boolean selectionActive;
    private int selectionStart = -1;
    private int selectionEnd = -1;
    private final int touchSlop;
    private final float swipeThresholdPx;
    private static final int GESTURE_NONE = 0;
    private static final int GESTURE_HORIZONTAL = 1;
    private static final int GESTURE_VERTICAL_BRIGHTNESS = 2;
    private int activeGesture = GESTURE_NONE;
    private int brightnessIndicatorPercent = -1;
    private Runnable hideBrightnessIndicatorRunnable;
    private Runnable longPressRunnable;

    private Listener listener;
    private SizeListener sizeListener;

    public ReaderView(Context context) {
        this(context, null);
    }

    public ReaderView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setFocusable(true);
        setClickable(true);
        framePaint.setColor(FRAME_COLOR);
        screenPaint.setColor(backgroundColorForTemperature(backgroundTemperature));
        selectionPaint.setColor(Color.argb(105, 120, 137, 150));
        brightnessHudPaint.setColor(Color.argb(210, 43, 43, 43));
        brightnessHudTextPaint.setColor(Color.WHITE);
        brightnessHudTextPaint.setTextAlign(Paint.Align.CENTER);
        brightnessHudTextPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        brightnessHudTextPaint.setTextSize(17f * getResources().getDisplayMetrics().scaledDensity);
        setBackgroundColor(FRAME_COLOR);
        touchSlop = ViewConfiguration.get(context).getScaledTouchSlop();
        swipeThresholdPx = Math.max(48f * getResources().getDisplayMetrics().density, touchSlop * 4f);
        configureStaticPaints();
    }

    private void configureStaticPaints() {
        float sd = getResources().getDisplayMetrics().scaledDensity;

        metaPaint.setColor(META_COLOR);
        metaPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        metaPaint.setTextAlign(Paint.Align.CENTER);
        metaPaint.setTextSize(11f * sd);

        chapterPaint.setColor(TEXT_COLOR);
        chapterPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.BOLD));
        chapterPaint.setTextAlign(Paint.Align.CENTER);
        chapterPaint.setTextSize(18f * sd);

        logoPaint.setColor(LOGO_COLOR);
        logoPaint.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.BOLD));
        logoPaint.setTextAlign(Paint.Align.CENTER);
        logoPaint.setTextSize(22f * sd);

        updateBodyPaint();
    }

    private void updateBodyPaint() {
        float sd = getResources().getDisplayMetrics().scaledDensity;
        bodyPaint.setColor(TEXT_COLOR);
        bodyPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        bodyPaint.setTextAlign(Paint.Align.LEFT);
        bodyPaint.setTextSize(fontSizeSp * sd);
        Paint.FontMetrics fm = bodyPaint.getFontMetrics();
        lineHeightPx = Math.max(1, Math.round((fm.descent - fm.ascent) * lineSpacing));
    }


    public void setBackgroundTemperature(int temperature) {
        backgroundTemperature = Math.max(ReaderStateStore.MIN_BACKGROUND_TEMPERATURE,
                Math.min(ReaderStateStore.MAX_BACKGROUND_TEMPERATURE, temperature));
        screenPaint.setColor(backgroundColorForTemperature(backgroundTemperature));
        invalidate();
    }

    private int backgroundColorForTemperature(int temperature) {
        int value = Math.max(ReaderStateStore.MIN_BACKGROUND_TEMPERATURE,
                Math.min(ReaderStateStore.MAX_BACKGROUND_TEMPERATURE, temperature));

        // 0 = branco ligeiramente frio; 50 = tom e-ink original; 100 = âmbar suave.
        if (value <= 50) {
            float t = value / 50f;
            return interpolateColor(
                    Color.rgb(238, 240, 242),
                    SCREEN_COLOR,
                    t
            );
        }
        float t = (value - 50) / 50f;
        return interpolateColor(
                SCREEN_COLOR,
                Color.rgb(241, 224, 188),
                t
        );
    }

    private int interpolateColor(int start, int end, float amount) {
        float t = Math.max(0f, Math.min(1f, amount));
        int red = Math.round(Color.red(start) + (Color.red(end) - Color.red(start)) * t);
        int green = Math.round(Color.green(start) + (Color.green(end) - Color.green(start)) * t);
        int blue = Math.round(Color.blue(start) + (Color.blue(end) - Color.blue(start)) * t);
        return Color.rgb(red, green, blue);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setSizeListener(SizeListener listener) {
        this.sizeListener = listener;
    }

    public void showLoading(String message) {
        loadingMessage = message;
        invalidate();
    }

    public void clearLoading() {
        loadingMessage = null;
        invalidate();
    }

    public boolean isLoading() {
        return loadingMessage != null;
    }

    public void setReaderContent(BookData book,
                                 PaginationResult pagination,
                                 int currentPage,
                                 int fontSizeSp,
                                 float lineSpacing,
                                 int sideMarginDp) {
        clearSelectionInternal(false);
        this.book = book;
        this.pages = pagination == null ? Collections.emptyList() : pagination.pages;
        this.pageOfChapter = pagination == null ? Collections.emptyList() : pagination.pageOfChapter;
        this.fontSizeSp = fontSizeSp;
        this.lineSpacing = lineSpacing;
        this.sideMarginDp = Math.max(ReaderStateStore.MIN_SIDE_MARGIN_DP,
                Math.min(ReaderStateStore.MAX_SIDE_MARGIN_DP, sideMarginDp));
        updateBodyPaint();
        setCurrentPage(currentPage);
        loadingMessage = null;
        invalidate();
    }

    public void setCurrentPage(int page) {
        int nextPage;
        if (pages.isEmpty()) {
            nextPage = 0;
        } else {
            nextPage = Math.max(0, Math.min(pages.size() - 1, page));
        }
        if (nextPage != currentPage) {
            clearSelectionInternal(false);
        }
        currentPage = nextPage;
        invalidate();
    }

    public void clearSelection() {
        clearSelectionInternal(true);
    }

    private void clearSelectionInternal(boolean redraw) {
        selectionActive = false;
        selectionStart = -1;
        selectionEnd = -1;
        if (redraw) invalidate();
    }

    public int getCurrentPage() {
        return currentPage;
    }

    public int getTotalPages() {
        return pages.size();
    }

    public int getCurrentChapterIndex() {
        int idx = 0;
        for (int i = 0; i < pageOfChapter.size(); i++) {
            if (currentPage >= pageOfChapter.get(i)) idx = i;
            else break;
        }
        return idx;
    }

    public int getChapterStartPage(int chapterIndex) {
        if (pageOfChapter.isEmpty()) return 0;
        int idx = Math.max(0, Math.min(pageOfChapter.size() - 1, chapterIndex));
        return pageOfChapter.get(idx);
    }

    public int getReaderScreenWidth() {
        return Math.max(0, Math.round(screenRect.width()));
    }

    public int getReaderScreenHeight() {
        return Math.max(0, Math.round(screenRect.height()));
    }

    public float getProgressFraction() {
        if (pages.size() <= 1) return 0f;
        return currentPage / (float) (pages.size() - 1);
    }

    @Override
    public WindowInsets onApplyWindowInsets(WindowInsets insets) {
        int safeTop = insets.getSystemWindowInsetTop();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
            DisplayCutout cutout = insets.getDisplayCutout();
            if (cutout != null) {
                safeTop = Math.max(safeTop, cutout.getSafeInsetTop());
            }
        }

        if (safeTop != systemSafeInsetTopPx) {
            systemSafeInsetTopPx = Math.max(0, safeTop);
            calculateScreenRect(getWidth(), getHeight());
            invalidate();
            if (sizeListener != null && getWidth() > 0 && getHeight() > 0) {
                post(() -> sizeListener.onReaderSizeChanged(
                        getReaderScreenWidth(), getReaderScreenHeight()));
            }
        }
        return super.onApplyWindowInsets(insets);
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.KITKAT_WATCH) {
            requestApplyInsets();
        }
    }

    @Override
    protected void onSizeChanged(int w, int h, int oldw, int oldh) {
        super.onSizeChanged(w, h, oldw, oldh);
        calculateScreenRect(w, h);
        if (sizeListener != null && w > 0 && h > 0 && (w != oldw || h != oldh)) {
            post(() -> sizeListener.onReaderSizeChanged(getReaderScreenWidth(), getReaderScreenHeight()));
        }
    }

    private void calculateScreenRect(int w, int h) {
        float d = getResources().getDisplayMetrics().density;
        // Nas laterais, a moldura Kobo fica reduzida a um fio vertical mínimo.
        float sideBezel = Math.max(1f, 1f * d);
        float topBezel = 8f * d;
        float bottomBezel = 8f * d;
        float logoZone = 42f * d;
        float left = sideBezel;
        // Android 15 desenha por defeito edge-to-edge. O ecrã do leitor começa
        // abaixo da barra de estado/cutout, para que a indicação do capítulo e
        // página nunca fique escondida pela câmara frontal.
        float top = Math.max(topBezel, systemSafeInsetTopPx + 4f * d);
        float right = Math.max(left + 1, w - sideBezel);
        float bottom = Math.max(top + 1, h - bottomBezel - logoZone);
        screenRect.set(left, top, right, bottom);
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (screenRect.width() <= 1 || screenRect.height() <= 1) {
            calculateScreenRect(getWidth(), getHeight());
        }

        canvas.drawColor(FRAME_COLOR);
        canvas.drawRect(screenRect, screenPaint);

        float d = getResources().getDisplayMetrics().density;
        float logoY = screenRect.bottom + 31f * d;
        canvas.drawText("kobo", screenRect.centerX(), logoY, logoPaint);

        int save = canvas.save();
        canvas.clipRect(screenRect);
        if (loadingMessage != null) {
            drawCenteredMultiline(canvas, loadingMessage, screenRect.centerX(), screenRect.centerY(), chapterPaint, 26f * d);
        } else if (book == null || pages.isEmpty()) {
            drawWelcome(canvas);
        } else {
            drawPage(canvas);
        }
        drawBrightnessIndicator(canvas);
        canvas.restoreToCount(save);
    }

    public void showBrightnessIndicator(int percent) {
        if (hideBrightnessIndicatorRunnable != null) {
            gestureHandler.removeCallbacks(hideBrightnessIndicatorRunnable);
            hideBrightnessIndicatorRunnable = null;
        }
        brightnessIndicatorPercent = Math.max(0, Math.min(100, percent));
        invalidate();
    }

    public void hideBrightnessIndicatorDelayed() {
        if (hideBrightnessIndicatorRunnable != null) {
            gestureHandler.removeCallbacks(hideBrightnessIndicatorRunnable);
        }
        hideBrightnessIndicatorRunnable = () -> {
            hideBrightnessIndicatorRunnable = null;
            brightnessIndicatorPercent = -1;
            invalidate();
        };
        gestureHandler.postDelayed(hideBrightnessIndicatorRunnable, 700L);
    }

    private void drawBrightnessIndicator(Canvas canvas) {
        if (brightnessIndicatorPercent < 0) return;
        float d = getResources().getDisplayMetrics().density;
        float width = Math.min(screenRect.width() - 32f * d, 205f * d);
        float height = 58f * d;
        float left = screenRect.centerX() - width / 2f;
        float top = screenRect.centerY() - height / 2f;
        RectF box = new RectF(left, top, left + width, top + height);
        canvas.drawRoundRect(box, 12f * d, 12f * d, brightnessHudPaint);

        Paint.FontMetrics fm = brightnessHudTextPaint.getFontMetrics();
        float baseline = box.centerY() - (fm.ascent + fm.descent) / 2f;
        canvas.drawText("Luminosidade: " + brightnessIndicatorPercent + "%",
                box.centerX(), baseline, brightnessHudTextPaint);
    }

    private void drawWelcome(Canvas canvas) {
        float d = getResources().getDisplayMetrics().density;
        Paint title = new Paint(chapterPaint);
        title.setTextSize(28f * getResources().getDisplayMetrics().scaledDensity);
        canvas.drawText("Kobo Reader", screenRect.centerX(), screenRect.centerY() - 65f * d, title);

        Paint info = new Paint(metaPaint);
        info.setTextSize(14f * getResources().getDisplayMetrics().scaledDensity);
        drawCenteredMultiline(
                canvas,
                "Toque para abrir um ficheiro EPUB",
                screenRect.centerX(),
                screenRect.centerY() - 5f * d,
                info,
                22f * d
        );

        Paint help = new Paint(metaPaint);
        help.setTextSize(10f * getResources().getDisplayMetrics().scaledDensity);
        drawCenteredMultiline(
                canvas,
                "Swipe horizontal: mudar página  •  Swipe vertical: luminosidade\nCentro: progresso e opções\nTopo: capítulos  •  Toque longo: selecionar",
                screenRect.centerX(),
                screenRect.centerY() + 60f * d,
                help,
                18f * d
        );
    }

    private void drawPage(Canvas canvas) {
        wordHits.clear();
        float d = getResources().getDisplayMetrics().density;
        int chapterIndex = getCurrentChapterIndex();
        BookData.Chapter chapter = book.chapters.get(Math.min(chapterIndex, book.chapters.size() - 1));
        int chapterStart = pageOfChapter.get(Math.min(chapterIndex, pageOfChapter.size() - 1));
        int chapterEnd = chapterIndex + 1 < pageOfChapter.size() ? pageOfChapter.get(chapterIndex + 1) : pages.size();
        int pageInChapter = currentPage - chapterStart + 1;
        int pagesInChapter = Math.max(1, chapterEnd - chapterStart);
        String chapterLabel = chapter.title == null || chapter.title.trim().isEmpty()
                ? "CAPÍTULO " + (chapterIndex + 1)
                : chapter.title;

        String header = (chapterLabel + " • " + pageInChapter + " de " + pagesInChapter).toUpperCase(Locale.ROOT);
        float headerY = screenRect.top + 22f * d;
        canvas.drawText(header, screenRect.centerX(), headerY, metaPaint);

        float bodyTop = screenRect.top + 50f * d;
        float y = bodyTop - bodyPaint.getFontMetrics().ascent;
        if (currentPage == chapterStart && chapter.title != null && !chapter.title.trim().isEmpty()) {
            float titleBaseline = bodyTop - chapterPaint.getFontMetrics().ascent;
            canvas.drawText(chapter.title, screenRect.centerX(), titleBaseline, chapterPaint);
            y += 40f * d;
        }

        float marginX = sideMarginDp * d;
        float xLeft = screenRect.left + marginX;
        float availableWidth = screenRect.width() - 2f * marginX;
        float footerY = screenRect.bottom - 28f * d;
        float bodyBottom = footerY - 24f * d;

        PageData page = pages.get(currentPage);
        for (PageData.Line line : page.lines) {
            Paint linePaint = paintForLine(line);
            if (y + linePaint.getFontMetrics().descent > bodyBottom) break;
            if (!line.text.isEmpty()) {
                float indent = Math.min(availableWidth * 0.45f, line.firstLineIndentPx);
                drawJustifiedLine(
                        canvas,
                        line.text,
                        xLeft + indent,
                        y,
                        Math.max(20f, availableWidth - indent),
                        !line.paragraphEnd,
                        linePaint
                );
            }
            y += lineHeightPx;
        }

        int readPercent = Math.round(((currentPage + 1f) / pages.size()) * 100f);
        String footer = book.title.toUpperCase(Locale.ROOT) + " • " + readPercent + "% LIDO";
        canvas.drawText(footer, screenRect.centerX(), footerY, metaPaint);
    }

    private Paint paintForLine(PageData.Line line) {
        if (!line.italic && !line.bold) return bodyPaint;
        Paint paint = new Paint(bodyPaint);
        int style;
        if (line.bold && line.italic) style = Typeface.BOLD_ITALIC;
        else if (line.bold) style = Typeface.BOLD;
        else style = Typeface.ITALIC;
        paint.setTypeface(Typeface.create(Typeface.SERIF, style));
        return paint;
    }

    private void drawJustifiedLine(Canvas canvas,
                                   String text,
                                   float x,
                                   float baseline,
                                   float availableWidth,
                                   boolean justify,
                                   Paint paint) {
        String trimmed = text == null ? "" : text.trim();
        if (trimmed.isEmpty()) return;

        String[] words = trimmed.split("\\s+");
        if (!justify || words.length < 2) {
            drawNaturalLineWithSelection(canvas, text, x, baseline, paint);
            return;
        }

        float wordsWidth = 0f;
        for (String word : words) wordsWidth += paint.measureText(word);
        float gap = (availableWidth - wordsWidth) / (words.length - 1);
        if (gap < 0f) {
            drawNaturalLineWithSelection(canvas, text, x, baseline, paint);
            return;
        }

        float cursor = x;
        for (String word : words) {
            float width = paint.measureText(word);
            int index = addWordHit(word, cursor, baseline, width, paint);
            drawSelectionIfNeeded(canvas, index);
            canvas.drawText(word, cursor, baseline, paint);
            cursor += width + gap;
        }
    }

    private void drawNaturalLineWithSelection(Canvas canvas,
                                              String text,
                                              float x,
                                              float baseline,
                                              Paint paint) {
        Matcher matcher = WORD_PATTERN.matcher(text);
        while (matcher.find()) {
            String word = matcher.group();
            float wordX = x + paint.measureText(text, 0, matcher.start());
            float width = paint.measureText(word);
            int index = addWordHit(word, wordX, baseline, width, paint);
            drawSelectionIfNeeded(canvas, index);
        }
        canvas.drawText(text, x, baseline, paint);
    }

    private int addWordHit(String text, float x, float baseline, float width, Paint paint) {
        Paint.FontMetrics fm = paint.getFontMetrics();
        float pad = 2f * getResources().getDisplayMetrics().density;
        RectF rect = new RectF(
                x - pad,
                baseline + fm.ascent - pad,
                x + width + pad,
                baseline + fm.descent + pad
        );
        int index = wordHits.size();
        wordHits.add(new WordHit(text, rect));
        return index;
    }

    private void drawSelectionIfNeeded(Canvas canvas, int index) {
        if (!isSelectedIndex(index)) return;
        canvas.drawRoundRect(wordHits.get(index).bounds,
                2f * getResources().getDisplayMetrics().density,
                2f * getResources().getDisplayMetrics().density,
                selectionPaint);
    }

    private boolean isSelectedIndex(int index) {
        if (selectionStart < 0 || selectionEnd < 0) return false;
        int first = Math.min(selectionStart, selectionEnd);
        int last = Math.max(selectionStart, selectionEnd);
        return index >= first && index <= last;
    }

    private int findWordAt(float x, float y) {
        for (int i = 0; i < wordHits.size(); i++) {
            if (wordHits.get(i).bounds.contains(x, y)) return i;
        }
        return -1;
    }

    private int findNearestWord(float x, float y) {
        int exact = findWordAt(x, y);
        if (exact >= 0) return exact;
        if (wordHits.isEmpty()) return -1;

        int best = -1;
        float bestDistance = Float.MAX_VALUE;
        for (int i = 0; i < wordHits.size(); i++) {
            RectF r = wordHits.get(i).bounds;
            float dx = r.centerX() - x;
            float dy = r.centerY() - y;
            float distance = dx * dx + dy * dy;
            if (distance < bestDistance) {
                bestDistance = distance;
                best = i;
            }
        }
        return best;
    }

    private String selectedText() {
        if (selectionStart < 0 || selectionEnd < 0 || wordHits.isEmpty()) return "";
        int first = Math.max(0, Math.min(selectionStart, selectionEnd));
        int last = Math.min(wordHits.size() - 1, Math.max(selectionStart, selectionEnd));
        StringBuilder text = new StringBuilder();
        for (int i = first; i <= last; i++) {
            if (text.length() > 0) text.append(' ');
            text.append(wordHits.get(i).text);
        }
        return text.toString().trim();
    }

    private void drawCenteredMultiline(Canvas canvas,
                                       String text,
                                       float centerX,
                                       float centerY,
                                       Paint paint,
                                       float lineGap) {
        String[] lines = text.split("\\n", -1);
        float firstY = centerY - ((lines.length - 1) * lineGap) / 2f;
        for (int i = 0; i < lines.length; i++) {
            canvas.drawText(lines[i], centerX, firstY + i * lineGap, paint);
        }
    }

    private void cancelPendingLongPress() {
        if (longPressRunnable != null) {
            gestureHandler.removeCallbacks(longPressRunnable);
            longPressRunnable = null;
        }
    }

    private void scheduleLongPress(float x, float y) {
        cancelPendingLongPress();
        if (findWordAt(x, y) < 0) return;
        longPressRunnable = () -> {
            longPressRunnable = null;
            if (!pointerDown || movedBeyondSlop || loadingMessage != null) return;
            int index = findWordAt(downX, downY);
            if (index < 0) return;
            selectionStart = index;
            selectionEnd = index;
            selectionActive = true;
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS);
            invalidate();
        };
        gestureHandler.postDelayed(longPressRunnable, ViewConfiguration.getLongPressTimeout());
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (listener == null) return true;

        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                pointerDown = true;
                movedBeyondSlop = false;
                activeGesture = GESTURE_NONE;
                downX = event.getX();
                downY = event.getY();
                if (loadingMessage == null && book != null && !pages.isEmpty()
                        && screenRect.contains(downX, downY)) {
                    scheduleLongPress(downX, downY);
                }
                return true;

            case MotionEvent.ACTION_MOVE:
                if (!pointerDown) return true;
                if (selectionActive) {
                    int index = findNearestWord(event.getX(), event.getY());
                    if (index >= 0 && index != selectionEnd) {
                        selectionEnd = index;
                        invalidate();
                    }
                    return true;
                }

                float moveDx = event.getX() - downX;
                float moveDy = event.getY() - downY;

                if (activeGesture == GESTURE_VERTICAL_BRIGHTNESS) {
                    float screenHeight = Math.max(1f, screenRect.height());
                    // Um percurso vertical equivalente à altura do ecrã altera
                    // cerca de 65 pontos percentuais. Isto dá precisão suficiente
                    // para escolher valores de 1% sem exigir deslocamentos enormes.
                    float deltaFraction = (-moveDy / screenHeight) * 0.65f;
                    listener.onBrightnessAdjustmentChanged(deltaFraction);
                    return true;
                }

                if (activeGesture == GESTURE_HORIZONTAL) {
                    return true;
                }

                float absDx = Math.abs(moveDx);
                float absDy = Math.abs(moveDy);
                if (absDx > touchSlop || absDy > touchSlop) {
                    movedBeyondSlop = true;
                    cancelPendingLongPress();

                    if (absDy > absDx * 1.2f) {
                        activeGesture = GESTURE_VERTICAL_BRIGHTNESS;
                        clearSelectionInternal(false);
                        listener.onBrightnessAdjustmentStarted();
                        float screenHeight = Math.max(1f, screenRect.height());
                        float deltaFraction = (-moveDy / screenHeight) * 0.65f;
                        listener.onBrightnessAdjustmentChanged(deltaFraction);
                    } else if (absDx > absDy * 1.2f) {
                        activeGesture = GESTURE_HORIZONTAL;
                    }
                }
                return true;

            case MotionEvent.ACTION_UP:
                pointerDown = false;
                cancelPendingLongPress();

                if (selectionActive) {
                    int index = findNearestWord(event.getX(), event.getY());
                    if (index >= 0) selectionEnd = index;
                    invalidate();
                    String text = selectedText();
                    if (!text.isEmpty()) {
                        listener.onSelectionRequested(text, event.getRawX(), event.getRawY());
                    } else {
                        clearSelectionInternal(true);
                    }
                    activeGesture = GESTURE_NONE;
                    return true;
                }

                if (activeGesture == GESTURE_VERTICAL_BRIGHTNESS) {
                    listener.onBrightnessAdjustmentEnded();
                    activeGesture = GESTURE_NONE;
                    return true;
                }

                if (loadingMessage != null) {
                    activeGesture = GESTURE_NONE;
                    return true;
                }
                if (book == null || pages.isEmpty()) {
                    if (!movedBeyondSlop) {
                        performClick();
                        listener.onOpenRequested();
                    }
                    activeGesture = GESTURE_NONE;
                    return true;
                }

                float dx = event.getX() - downX;
                float dy = event.getY() - downY;
                if (activeGesture == GESTURE_HORIZONTAL || movedBeyondSlop) {
                    if (Math.abs(dx) >= swipeThresholdPx && Math.abs(dx) > Math.abs(dy) * 1.2f) {
                        clearSelectionInternal(false);
                        if (dx < 0f) listener.onNextPageRequested();
                        else listener.onPreviousPageRequested();
                    }
                    activeGesture = GESTURE_NONE;
                    return true;
                }

                activeGesture = GESTURE_NONE;
                performClick();
                handleTap(event.getX(), event.getY());
                return true;

            case MotionEvent.ACTION_CANCEL:
                pointerDown = false;
                cancelPendingLongPress();
                if (activeGesture == GESTURE_VERTICAL_BRIGHTNESS) {
                    listener.onBrightnessAdjustmentEnded();
                }
                activeGesture = GESTURE_NONE;
                if (selectionActive) clearSelectionInternal(true);
                return true;

            default:
                return true;
        }
    }

    private void handleTap(float x, float y) {
        if (!screenRect.contains(x, y)) return;

        float localX = x - screenRect.left;
        float localY = y - screenRect.top;
        float chapterZoneWidth = screenRect.width() * 0.42f;
        float chapterZoneHeight = Math.max(
                70f * getResources().getDisplayMetrics().density,
                screenRect.height() * 0.12f
        );
        float chapterLeft = (screenRect.width() - chapterZoneWidth) / 2f;
        float chapterRight = (screenRect.width() + chapterZoneWidth) / 2f;

        if (localX >= chapterLeft && localX <= chapterRight && localY <= chapterZoneHeight) {
            listener.onChaptersRequested();
            return;
        }

        float third = screenRect.width() / 3f;
        if (localX < third) listener.onPreviousPageRequested();
        else if (localX > 2f * third) listener.onNextPageRequested();
        else listener.onProgressRequested();
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    @Override
    protected void onDetachedFromWindow() {
        cancelPendingLongPress();
        if (hideBrightnessIndicatorRunnable != null) {
            gestureHandler.removeCallbacks(hideBrightnessIndicatorRunnable);
            hideBrightnessIndicatorRunnable = null;
        }
        super.onDetachedFromWindow();
    }

    private static final class WordHit {
        final String text;
        final RectF bounds;

        WordHit(String text, RectF bounds) {
            this.text = text == null ? "" : text;
            this.bounds = bounds;
        }
    }

    public interface Listener {
        void onOpenRequested();
        void onPreviousPageRequested();
        void onNextPageRequested();
        void onProgressRequested();
        void onChaptersRequested();
        void onSelectionRequested(String text, float rawX, float rawY);
        void onBrightnessAdjustmentStarted();
        void onBrightnessAdjustmentChanged(float deltaFraction);
        void onBrightnessAdjustmentEnded();
    }

    public interface SizeListener {
        void onReaderSizeChanged(int screenWidth, int screenHeight);
    }
}
