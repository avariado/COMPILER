package com.epubookobo.reader;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ActivityNotFoundException;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.Build;
import android.provider.Settings;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.PopupWindow;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;

public final class MainActivity extends Activity implements ReaderView.Listener, ReaderView.SizeListener {
    private static final int REQUEST_OPEN_EPUB = 1001;
    private static final int SCREEN_COLOR = Color.rgb(232, 230, 225);
    private static final int OVERLAY_COLOR = Color.rgb(216, 214, 209);
    private static final int TEXT_COLOR = Color.rgb(26, 26, 26);

    private ReaderView readerView;
    private ReaderStateStore stateStore;
    private final ExecutorService executor = Executors.newSingleThreadExecutor();
    private final AtomicInteger generation = new AtomicInteger(0);
    private final Handler handler = new Handler(Looper.getMainLooper());
    private Runnable resizeRunnable;
    private PopupWindow selectionPopup;

    private BookData book;
    private Uri currentUri;
    private int fontSize = ReaderStateStore.DEFAULT_FONT_SIZE;
    private float lineSpacing = ReaderStateStore.DEFAULT_LINE_SPACING;
    private int sideMarginDp = ReaderStateStore.DEFAULT_SIDE_MARGIN_DP;
    private int backgroundTemperature = ReaderStateStore.DEFAULT_BACKGROUND_TEMPERATURE;
    private float windowBrightness = -1f;
    private float brightnessGestureStart = -1f;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        requestWindowFeature(Window.FEATURE_NO_TITLE);
        getWindow().setStatusBarColor(Color.rgb(43, 43, 43));
        getWindow().setNavigationBarColor(Color.rgb(43, 43, 43));

        stateStore = new ReaderStateStore(this);
        readerView = new ReaderView(this);
        readerView.setListener(this);
        readerView.setSizeListener(this);
        setContentView(readerView);
        windowBrightness = resolveInitialBrightness();

        handleIncomingIntent(getIntent());
    }

    @Override
    protected void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        handleIncomingIntent(intent);
    }

    private void handleIncomingIntent(Intent intent) {
        if (intent == null) return;
        if (Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData() != null) {
            openUri(intent.getData());
        }
    }

    @Override
    public void onOpenRequested() {
        dismissSelectionPopup();
        openDocumentPicker();
    }

    @Override
    public void onPreviousPageRequested() {
        dismissSelectionPopup();
        if (readerView.getCurrentPage() > 0) {
            readerView.setCurrentPage(readerView.getCurrentPage() - 1);
        }
    }

    @Override
    public void onNextPageRequested() {
        dismissSelectionPopup();
        if (readerView.getCurrentPage() + 1 < readerView.getTotalPages()) {
            readerView.setCurrentPage(readerView.getCurrentPage() + 1);
        }
    }

    @Override
    public void onProgressRequested() {
        dismissSelectionPopup();
        showProgressDialog();
    }

    @Override
    public void onChaptersRequested() {
        dismissSelectionPopup();
        showChapterDialog();
    }

    @Override
    public void onSelectionRequested(String text, float rawX, float rawY) {
        showSelectionPopup(text, rawX, rawY);
    }

    @Override
    public void onBrightnessAdjustmentStarted() {
        dismissSelectionPopup();
        if (windowBrightness < 0f) {
            windowBrightness = resolveInitialBrightness();
        }
        brightnessGestureStart = windowBrightness;
        readerView.showBrightnessIndicator(Math.round(windowBrightness * 100f));
    }

    @Override
    public void onBrightnessAdjustmentChanged(float deltaFraction) {
        if (brightnessGestureStart < 0f) {
            if (windowBrightness < 0f) {
                windowBrightness = resolveInitialBrightness();
            }
            brightnessGestureStart = windowBrightness;
        }

        float rawTarget = brightnessGestureStart + deltaFraction;
        int percent = Math.max(2, Math.min(100, Math.round(rawTarget * 100f)));
        float target = percent / 100f;

        if (Math.abs(target - windowBrightness) >= 0.0001f) {
            windowBrightness = target;
            WindowManager.LayoutParams params = getWindow().getAttributes();
            params.screenBrightness = windowBrightness;
            getWindow().setAttributes(params);
        }

        readerView.showBrightnessIndicator(percent);
    }

    @Override
    public void onBrightnessAdjustmentEnded() {
        brightnessGestureStart = -1f;
        readerView.hideBrightnessIndicatorDelayed();
    }

    private float resolveInitialBrightness() {
        WindowManager.LayoutParams params = getWindow().getAttributes();
        if (params.screenBrightness >= 0f && params.screenBrightness <= 1f) {
            return params.screenBrightness;
        }
        try {
            int value = Settings.System.getInt(getContentResolver(), Settings.System.SCREEN_BRIGHTNESS);
            return Math.max(0.02f, Math.min(1f, value / 255f));
        } catch (Settings.SettingNotFoundException ignored) {
            return 0.5f;
        }
    }

    @Override
    public void onReaderSizeChanged(int screenWidth, int screenHeight) {
        if (book == null || readerView.getTotalPages() == 0 || readerView.isLoading()) return;
        if (resizeRunnable != null) handler.removeCallbacks(resizeRunnable);
        resizeRunnable = () -> repaginatePreservingProgress("A adaptar o documento…");
        handler.postDelayed(resizeRunnable, 280);
    }

    private Intent createContentPickerIntent() {
        // ACTION_GET_CONTENT é deliberadamente lançado diretamente, sem
        // Intent.createChooser(). Desta forma o Android pode construir o seu
        // próprio ecrã "Abrir de" e incluir gestores de ficheiros de terceiros
        // que anunciem capacidade para fornecer conteúdo.
        //
        // Não restringimos o MIME a application/epub+zip porque alguns gestores
        // de ficheiros anunciam apenas tipos genéricos. A validação efetiva do
        // EPUB é feita pelo parser depois de o utilizador escolher o ficheiro.
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("*/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        return intent;
    }

    private void openDocumentPicker() {
        try {
            // Importante: não envolver em createChooser(). Em vários Android/OEM,
            // o próprio resolvedor de ACTION_GET_CONTENT apresenta as fontes e
            // apps compatíveis dentro do menu "Abrir de".
            startActivityForResult(createContentPickerIntent(), REQUEST_OPEN_EPUB);
        } catch (ActivityNotFoundException e) {
            // Fallback apenas para dispositivos sem qualquer handler de
            // ACTION_GET_CONTENT.
            Intent fallback = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fallback.setType("*/*");
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
            try {
                startActivityForResult(fallback, REQUEST_OPEN_EPUB);
            } catch (ActivityNotFoundException ignored) {
                showError("Não existe um seletor de ficheiros disponível neste dispositivo.");
            }
        }
    }

    @Override
    @SuppressWarnings("deprecation")
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode != REQUEST_OPEN_EPUB || resultCode != RESULT_OK || data == null || data.getData() == null) {
            return;
        }

        Uri uri = data.getData();
        openUri(uri);
    }

    private void openUri(Uri uri) {
        if (uri == null) return;
        int token = generation.incrementAndGet();
        currentUri = uri;
        readerView.showLoading("A abrir EPUB…");

        executor.execute(() -> {
            try {
                BookData parsed = EpubParser.parse(getApplicationContext(), uri);
                runOnUiThread(() -> {
                    if (token != generation.get()) return;
                    book = parsed;
                    ReaderStateStore.SavedState saved = stateStore.read(parsed.key);
                    fontSize = saved.fontSize;
                    lineSpacing = saved.lineSpacing;
                    sideMarginDp = saved.sideMarginDp;
                    backgroundTemperature = saved.backgroundTemperature;
                    readerView.setBackgroundTemperature(backgroundTemperature);
                    paginate(token, saved.pageIndex, null, "A preparar o documento…");
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (token != generation.get()) return;
                    readerView.clearLoading();
                    book = null;
                    showError("Erro ao abrir EPUB\n\n" + safeMessage(e));
                });
            }
        });
    }

    private void paginate(int expectedGeneration,
                          Integer exactPage,
                          Float progressFraction,
                          String message) {
        if (book == null) return;

        int width = readerView.getReaderScreenWidth();
        int height = readerView.getReaderScreenHeight();
        if (width <= 0 || height <= 0) {
            readerView.postDelayed(() -> paginate(expectedGeneration, exactPage, progressFraction, message), 50);
            return;
        }

        final BookData targetBook = book;
        final int targetFont = fontSize;
        final float targetSpacing = lineSpacing;
        final int targetSideMargin = sideMarginDp;
        final float density = getResources().getDisplayMetrics().density;
        final float scaledDensity = getResources().getDisplayMetrics().scaledDensity;
        readerView.showLoading(message);

        executor.execute(() -> {
            try {
                Paginator paginator = new Paginator(
                        width, height, density, scaledDensity, targetFont, targetSpacing, targetSideMargin
                );
                PaginationResult result = paginator.paginate(targetBook);
                runOnUiThread(() -> {
                    if (expectedGeneration != generation.get() || targetBook != book) return;
                    if (result.pages.isEmpty()) {
                        readerView.clearLoading();
                        showError("O EPUB não contém páginas legíveis.");
                        return;
                    }

                    int page;
                    if (exactPage != null) {
                        page = exactPage;
                    } else if (progressFraction != null && result.pages.size() > 1) {
                        page = Math.round(progressFraction * (result.pages.size() - 1));
                    } else {
                        page = 0;
                    }
                    page = Math.max(0, Math.min(result.pages.size() - 1, page));
                    readerView.setReaderContent(targetBook, result, page, targetFont, targetSpacing, targetSideMargin);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (expectedGeneration != generation.get()) return;
                    readerView.clearLoading();
                    showError("Erro ao preparar o documento\n\n" + safeMessage(e));
                });
            }
        });
    }

    private void repaginatePreservingProgress(String message) {
        if (book == null || readerView.getTotalPages() == 0) return;
        float progress = readerView.getProgressFraction();
        int token = generation.incrementAndGet();
        paginate(token, null, progress, message);
    }

    private void changeFontSize(int delta) {
        if (book == null || readerView.isLoading()) return;
        int next = Math.max(ReaderStateStore.MIN_FONT_SIZE,
                Math.min(ReaderStateStore.MAX_FONT_SIZE, fontSize + delta));
        if (next == fontSize) return;
        fontSize = next;
        repaginatePreservingProgress("A ajustar fonte para " + fontSize + "…");
    }

    private void changeLineSpacing(float delta) {
        if (book == null || readerView.isLoading()) return;
        float next = Math.round((lineSpacing + delta) * 10f) / 10f;
        next = Math.max(ReaderStateStore.MIN_LINE_SPACING,
                Math.min(ReaderStateStore.MAX_LINE_SPACING, next));
        if (Math.abs(next - lineSpacing) < 0.001f) return;
        lineSpacing = next;
        repaginatePreservingProgress(String.format(Locale.ROOT, "A ajustar espaçamento para %.2f…", lineSpacing));
    }

    private void showSelectionPopup(String selectedText, float rawX, float rawY) {
        if (selectedText == null || selectedText.trim().isEmpty()) {
            readerView.clearSelection();
            return;
        }

        if (selectionPopup != null) {
            selectionPopup.setOnDismissListener(null);
            selectionPopup.dismiss();
            selectionPopup = null;
        }

        LinearLayout bar = new LinearLayout(this);
        bar.setOrientation(LinearLayout.HORIZONTAL);
        bar.setGravity(Gravity.CENTER);
        bar.setBackgroundColor(OVERLAY_COLOR);
        bar.setPadding(dp(6), dp(4), dp(6), dp(4));

        Button copy = dialogButton("Copiar");
        Button search = dialogButton("Pesquisar");
        Button share = dialogButton("Partilhar");
        bar.addView(copy, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        bar.addView(search, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));
        bar.addView(share, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT));

        PopupWindow popup = new PopupWindow(
                bar,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                LinearLayout.LayoutParams.WRAP_CONTENT,
                true
        );
        popup.setBackgroundDrawable(new ColorDrawable(OVERLAY_COLOR));
        popup.setOutsideTouchable(true);
        // Um toque fora do menu deve apenas cancelar a seleção. Consumimos
        // explicitamente ACTION_OUTSIDE para impedir que o mesmo toque atravesse
        // o PopupWindow e seja interpretado pelo ReaderView como navegação.
        popup.setTouchInterceptor((view, event) -> {
            if (event.getActionMasked() == MotionEvent.ACTION_OUTSIDE) {
                popup.dismiss();
                return true;
            }
            return false;
        });
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            popup.setElevation(dp(6));
        }
        popup.setOnDismissListener(() -> {
            readerView.clearSelection();
            if (selectionPopup == popup) selectionPopup = null;
        });
        selectionPopup = popup;

        copy.setOnClickListener(v -> {
            ClipboardManager clipboard = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            if (clipboard != null) {
                clipboard.setPrimaryClip(ClipData.newPlainText("Texto selecionado", selectedText));
                Toast.makeText(this, "Texto copiado", Toast.LENGTH_SHORT).show();
            }
            popup.dismiss();
        });

        search.setOnClickListener(v -> {
            Uri searchUri = Uri.parse("https://www.google.com/search?q=" + Uri.encode(selectedText));
            Intent intent = new Intent(Intent.ACTION_VIEW, searchUri);
            intent.addCategory(Intent.CATEGORY_BROWSABLE);
            try {
                startActivity(intent);
            } catch (ActivityNotFoundException e) {
                showError("Não existe um browser disponível para efetuar a pesquisa.");
            }
            popup.dismiss();
        });

        share.setOnClickListener(v -> {
            Intent sendIntent = new Intent(Intent.ACTION_SEND);
            sendIntent.setType("text/plain");
            sendIntent.putExtra(Intent.EXTRA_TEXT, selectedText);
            Intent chooser = Intent.createChooser(sendIntent, "Partilhar texto");
            try {
                startActivity(chooser);
            } catch (ActivityNotFoundException e) {
                showError("Não existe uma aplicação disponível para partilhar o texto.");
            }
            popup.dismiss();
        });

        int unspecified = View.MeasureSpec.makeMeasureSpec(0, View.MeasureSpec.UNSPECIFIED);
        bar.measure(unspecified, unspecified);
        int popupWidth = Math.max(dp(150), bar.getMeasuredWidth());
        int popupHeight = Math.max(dp(48), bar.getMeasuredHeight());
        int screenWidth = getResources().getDisplayMetrics().widthPixels;
        int screenHeight = getResources().getDisplayMetrics().heightPixels;
        int x = Math.round(rawX - popupWidth / 2f);
        int y = Math.round(rawY - popupHeight - dp(18));
        x = Math.max(dp(6), Math.min(screenWidth - popupWidth - dp(6), x));
        y = Math.max(dp(6), Math.min(screenHeight - popupHeight - dp(6), y));

        popup.showAtLocation(readerView, Gravity.TOP | Gravity.START, x, y);
    }

    private void dismissSelectionPopup() {
        if (selectionPopup != null) {
            selectionPopup.dismiss();
            selectionPopup = null;
        } else if (readerView != null) {
            readerView.clearSelection();
        }
    }

    private void showProgressDialog() {
        if (book == null || readerView.getTotalPages() == 0 || readerView.isLoading()) return;

        LinearLayout content = dialogLayout();
        TextView info = dialogText("", 16f, true);
        SeekBar seek = new SeekBar(this);
        seek.setMax(Math.max(1, readerView.getTotalPages() - 1));
        seek.setProgress(readerView.getCurrentPage());
        content.addView(info, matchWrap());
        content.addView(seek, matchWrap());

        Button save = dialogButton("Salvar progresso");
        Button reading = dialogButton("Leitura");
        Button open = dialogButton("Abrir outro EPUB");
        content.addView(save, matchWrap());
        content.addView(reading, matchWrap());
        content.addView(open, matchWrap());

        final int[] previewPage = {readerView.getCurrentPage()};
        updateProgressText(info, previewPage[0]);

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Progresso")
                .setView(content)
                .setNegativeButton("Fechar", null)
                .create();

        seek.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                previewPage[0] = Math.min(progress, readerView.getTotalPages() - 1);
                updateProgressText(info, previewPage[0]);
                if (fromUser) readerView.setCurrentPage(previewPage[0]);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {
                readerView.setCurrentPage(previewPage[0]);
            }
        });

        save.setOnClickListener(v -> saveProgress());
        reading.setOnClickListener(v -> {
            dialog.dismiss();
            showReadingDialog();
        });
        open.setOnClickListener(v -> {
            dialog.dismiss();
            openDocumentPicker();
        });

        showEInkDialog(dialog);
    }

    private void updateProgressText(TextView info, int page) {
        int total = Math.max(1, readerView.getTotalPages());
        float pct = ((page + 1f) / total) * 100f;
        info.setText(String.format(Locale.ROOT, "%.0f%%  —  Pág. %d/%d", pct, page + 1, total));
    }

    private void showChapterDialog() {
        if (book == null || book.chapters.isEmpty() || readerView.isLoading()) return;

        String[] labels = new String[book.chapters.size()];
        for (int i = 0; i < book.chapters.size(); i++) {
            String title = book.chapters.get(i).title;
            if (title == null || title.trim().isEmpty()) title = "CAPÍTULO " + (i + 1);
            labels[i] = String.format(Locale.ROOT, "%02d. %s", i + 1, title);
        }

        final int[] selected = {readerView.getCurrentChapterIndex()};
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Navegação por capítulos")
                .setSingleChoiceItems(labels, selected[0], (d, which) -> selected[0] = which)
                .setPositiveButton("Ir para capítulo", (d, which) ->
                        readerView.setCurrentPage(readerView.getChapterStartPage(selected[0])))
                .setNegativeButton("Fechar", null)
                .create();
        showEInkDialog(dialog);
    }

    private void showReadingDialog() {
        if (book == null || readerView.isLoading()) return;

        LinearLayout content = dialogLayout();
        TextView fontLabel = dialogText("", 15f, true);
        SeekBar fontSeek = new SeekBar(this);
        fontSeek.setMax(ReaderStateStore.MAX_FONT_SIZE - ReaderStateStore.MIN_FONT_SIZE);
        fontSeek.setProgress(fontSize - ReaderStateStore.MIN_FONT_SIZE);

        TextView spacingLabel = dialogText("", 15f, true);
        SeekBar spacingSeek = new SeekBar(this);
        int spacingSteps = Math.round((ReaderStateStore.MAX_LINE_SPACING - ReaderStateStore.MIN_LINE_SPACING) * 10f);
        spacingSeek.setMax(spacingSteps);
        spacingSeek.setProgress(Math.round((lineSpacing - ReaderStateStore.MIN_LINE_SPACING) * 10f));

        TextView marginLabel = dialogText("", 15f, true);
        SeekBar marginSeek = new SeekBar(this);
        marginSeek.setMax(ReaderStateStore.MAX_SIDE_MARGIN_DP - ReaderStateStore.MIN_SIDE_MARGIN_DP);
        marginSeek.setProgress(sideMarginDp - ReaderStateStore.MIN_SIDE_MARGIN_DP);

        TextView temperatureLabel = dialogText("", 15f, true);
        SeekBar temperatureSeek = new SeekBar(this);
        temperatureSeek.setMax(ReaderStateStore.MAX_BACKGROUND_TEMPERATURE);
        temperatureSeek.setProgress(backgroundTemperature);

        content.addView(fontLabel, matchWrap());
        content.addView(fontSeek, matchWrap());
        content.addView(spacingLabel, matchWrap());
        content.addView(spacingSeek, matchWrap());
        content.addView(marginLabel, matchWrap());
        content.addView(marginSeek, matchWrap());
        content.addView(temperatureLabel, matchWrap());
        content.addView(temperatureSeek, matchWrap());

        final int[] selectedFont = {fontSize};
        final float[] selectedSpacing = {lineSpacing};
        final int[] selectedMargin = {sideMarginDp};
        final int[] selectedTemperature = {backgroundTemperature};
        updateReadingLabels(fontLabel, spacingLabel, marginLabel, temperatureLabel,
                selectedFont[0], selectedSpacing[0], selectedMargin[0], selectedTemperature[0]);

        fontSeek.setOnSeekBarChangeListener(simpleSeek(progress -> {
            selectedFont[0] = ReaderStateStore.MIN_FONT_SIZE + progress;
            updateReadingLabels(fontLabel, spacingLabel, marginLabel, temperatureLabel,
                    selectedFont[0], selectedSpacing[0], selectedMargin[0], selectedTemperature[0]);
        }));
        spacingSeek.setOnSeekBarChangeListener(simpleSeek(progress -> {
            selectedSpacing[0] = Math.round((ReaderStateStore.MIN_LINE_SPACING + progress / 10f) * 100f) / 100f;
            updateReadingLabels(fontLabel, spacingLabel, marginLabel, temperatureLabel,
                    selectedFont[0], selectedSpacing[0], selectedMargin[0], selectedTemperature[0]);
        }));
        marginSeek.setOnSeekBarChangeListener(simpleSeek(progress -> {
            selectedMargin[0] = ReaderStateStore.MIN_SIDE_MARGIN_DP + progress;
            updateReadingLabels(fontLabel, spacingLabel, marginLabel, temperatureLabel,
                    selectedFont[0], selectedSpacing[0], selectedMargin[0], selectedTemperature[0]);
        }));
        temperatureSeek.setOnSeekBarChangeListener(simpleSeek(progress -> {
            selectedTemperature[0] = progress;
            updateReadingLabels(fontLabel, spacingLabel, marginLabel, temperatureLabel,
                    selectedFont[0], selectedSpacing[0], selectedMargin[0], selectedTemperature[0]);
        }));

        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Leitura")
                .setView(content)
                .setPositiveButton("Aplicar", (d, which) -> {
                    boolean layoutChanged = selectedFont[0] != fontSize
                            || Math.abs(selectedSpacing[0] - lineSpacing) > 0.001f
                            || selectedMargin[0] != sideMarginDp;
                    boolean temperatureChanged = selectedTemperature[0] != backgroundTemperature;
                    fontSize = selectedFont[0];
                    lineSpacing = selectedSpacing[0];
                    sideMarginDp = selectedMargin[0];
                    backgroundTemperature = selectedTemperature[0];
                    if (temperatureChanged) {
                        readerView.setBackgroundTemperature(backgroundTemperature);
                    }
                    if (layoutChanged) repaginatePreservingProgress("A adaptar o documento…");
                })
                .setNegativeButton("Cancelar", null)
                .create();
        showEInkDialog(dialog);
    }

    private void updateReadingLabels(TextView fontLabel,
                                     TextView spacingLabel,
                                     TextView marginLabel,
                                     TextView temperatureLabel,
                                     int font,
                                     float spacing,
                                     int marginDp,
                                     int temperature) {
        fontLabel.setText("Tamanho da letra: " + font);
        spacingLabel.setText(String.format(Locale.ROOT, "Espaçamento entre linhas: %.2f", spacing));
        marginLabel.setText(String.format(Locale.ROOT, "Margens laterais: %d dp", marginDp));

        String tone;
        if (temperature < 34) tone = "mais branco";
        else if (temperature < 67) tone = "neutro";
        else tone = "mais quente";
        temperatureLabel.setText(String.format(Locale.ROOT,
                "Temperatura do fundo: %d%% — %s", temperature, tone));
    }

    private SeekBar.OnSeekBarChangeListener simpleSeek(IntChange change) {
        return new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                change.onChange(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        };
    }

    private void saveProgress() {
        if (book == null || readerView.getTotalPages() == 0) return;
        try {
            stateStore.save(
                    book,
                    currentUri,
                    readerView.getCurrentPage(),
                    readerView.getTotalPages(),
                    fontSize,
                    lineSpacing,
                    sideMarginDp,
                    backgroundTemperature
            );
            Toast.makeText(this, "Progresso salvo em epubookobo.json", Toast.LENGTH_SHORT).show();
        } catch (Exception e) {
            showError("Não foi possível salvar o progresso.\n\n" + safeMessage(e));
        }
    }

    private LinearLayout dialogLayout() {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setBackgroundColor(OVERLAY_COLOR);
        int p = dp(18);
        layout.setPadding(p, dp(8), p, dp(8));
        return layout;
    }

    private TextView dialogText(String text, float sp, boolean centered) {
        TextView view = new TextView(this);
        view.setText(text);
        view.setTextColor(TEXT_COLOR);
        view.setTextSize(sp);
        view.setGravity(centered ? Gravity.CENTER : Gravity.START);
        view.setPadding(dp(4), dp(8), dp(4), dp(8));
        return view;
    }

    private Button dialogButton(String label) {
        Button button = new Button(this);
        button.setText(label);
        button.setTextColor(TEXT_COLOR);
        button.setAllCaps(false);
        return button;
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT,
                LinearLayout.LayoutParams.WRAP_CONTENT
        );
    }

    private void showEInkDialog(AlertDialog dialog) {
        dialog.setOnShowListener(d -> {
            if (dialog.getWindow() != null) {
                dialog.getWindow().setBackgroundDrawable(new ColorDrawable(OVERLAY_COLOR));
            }
        });
        dialog.show();
    }

    private void showExitDialog() {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("Sair do leitor?")
                .setMessage("Não se esqueça de salvar o progresso.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Sair", (d, which) -> finish())
                .create();
        showEInkDialog(dialog);
    }

    private void showError(String message) {
        AlertDialog dialog = new AlertDialog.Builder(this)
                .setTitle("EpubooKobo")
                .setMessage(message)
                .setPositiveButton("OK", null)
                .create();
        showEInkDialog(dialog);
    }

    private String safeMessage(Throwable throwable) {
        String message = throwable == null ? null : throwable.getMessage();
        if (message == null || message.trim().isEmpty()) {
            return throwable == null ? "Erro desconhecido." : throwable.getClass().getSimpleName();
        }
        return message;
    }

    private int dp(int value) {
        return Math.round(value * Resources.getSystem().getDisplayMetrics().density);
    }

    @Override
    @SuppressWarnings("deprecation")
    public void onBackPressed() {
        showExitDialog();
    }

    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        if (event.getAction() == KeyEvent.ACTION_DOWN && book != null && !readerView.isLoading()) {
            int code = event.getKeyCode();
            if (event.isCtrlPressed() && code == KeyEvent.KEYCODE_DPAD_UP) {
                changeLineSpacing(0.10f);
                return true;
            }
            if (event.isCtrlPressed() && code == KeyEvent.KEYCODE_DPAD_DOWN) {
                changeLineSpacing(-0.10f);
                return true;
            }
            if (event.isShiftPressed() && code == KeyEvent.KEYCODE_DPAD_UP) {
                changeFontSize(1);
                return true;
            }
            if (event.isShiftPressed() && code == KeyEvent.KEYCODE_DPAD_DOWN) {
                changeFontSize(-1);
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_LEFT) {
                onPreviousPageRequested();
                return true;
            }
            if (code == KeyEvent.KEYCODE_DPAD_RIGHT) {
                onNextPageRequested();
                return true;
            }
            if (code == KeyEvent.KEYCODE_ENTER || code == KeyEvent.KEYCODE_NUMPAD_ENTER) {
                showProgressDialog();
                return true;
            }
            if (code == KeyEvent.KEYCODE_SPACE) {
                showChapterDialog();
                return true;
            }
        }
        return super.dispatchKeyEvent(event);
    }

    @Override
    protected void onDestroy() {
        generation.incrementAndGet();
        if (resizeRunnable != null) handler.removeCallbacks(resizeRunnable);
        if (selectionPopup != null) {
            selectionPopup.setOnDismissListener(null);
            selectionPopup.dismiss();
            selectionPopup = null;
        }
        executor.shutdownNow();
        super.onDestroy();
    }

    private interface IntChange {
        void onChange(int value);
    }
}
