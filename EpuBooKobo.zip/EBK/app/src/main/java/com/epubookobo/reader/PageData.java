package com.epubookobo.reader;

import java.util.ArrayList;
import java.util.List;

public final class PageData {
    public final List<Line> lines;

    public PageData(List<Line> lines) {
        this.lines = lines == null ? new ArrayList<>() : lines;
    }

    public static final class Line {
        public final String text;
        public final boolean paragraphEnd;
        public final float firstLineIndentPx;
        public final boolean italic;
        public final boolean bold;

        public Line(String text,
                    boolean paragraphEnd,
                    float firstLineIndentPx,
                    boolean italic,
                    boolean bold) {
            this.text = text == null ? "" : text;
            this.paragraphEnd = paragraphEnd;
            this.firstLineIndentPx = Math.max(0f, firstLineIndentPx);
            this.italic = italic;
            this.bold = bold;
        }
    }
}
