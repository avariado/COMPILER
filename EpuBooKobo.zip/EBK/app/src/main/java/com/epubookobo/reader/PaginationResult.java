package com.epubookobo.reader;

import java.util.ArrayList;
import java.util.List;

public final class PaginationResult {
    public final List<PageData> pages;
    public final List<Integer> pageOfChapter;

    public PaginationResult(List<PageData> pages, List<Integer> pageOfChapter) {
        this.pages = pages == null ? new ArrayList<>() : pages;
        this.pageOfChapter = pageOfChapter == null ? new ArrayList<>() : pageOfChapter;
    }
}
