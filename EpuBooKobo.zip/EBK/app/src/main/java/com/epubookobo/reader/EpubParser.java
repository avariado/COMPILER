package com.epubookobo.reader;

import android.content.Context;
import android.net.Uri;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.Node;
import org.w3c.dom.NodeList;
import org.xml.sax.InputSource;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.ArrayList;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;
import java.util.zip.ZipEntry;
import java.util.zip.ZipFile;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

public final class EpubParser {
    private EpubParser() {}

    private static final Pattern CSS_RULE = Pattern.compile("([^{}]+)\\{([^{}]*)\\}", Pattern.DOTALL);
    private static final Pattern CSS_DECL = Pattern.compile("([-\\w]+)\\s*:\\s*([^;}{]+)", Pattern.CASE_INSENSITIVE);
    private static final Pattern CSS_COMMENT = Pattern.compile("/\\*.*?\\*/", Pattern.DOTALL);
    private static final Pattern CSS_LENGTH = Pattern.compile("(-?\\d+(?:\\.\\d+)?)(px|pt|em|rem|%)?", Pattern.CASE_INSENSITIVE);

    public static BookData parse(Context context, Uri uri) throws Exception {
        File temp = File.createTempFile("epubookobo_", ".epub", context.getCacheDir());
        try {
            try (InputStream in = context.getContentResolver().openInputStream(uri);
                 FileOutputStream out = new FileOutputStream(temp)) {
                if (in == null) {
                    throw new IllegalArgumentException("Não foi possível abrir o ficheiro selecionado.");
                }
                byte[] buffer = new byte[64 * 1024];
                int read;
                while ((read = in.read(buffer)) != -1) {
                    out.write(buffer, 0, read);
                }
            }
            return parseFile(temp);
        } finally {
            // Todo o conteúdo necessário fica em memória no BookData.
            //noinspection ResultOfMethodCallIgnored
            temp.delete();
        }
    }

    private static BookData parseFile(File epubFile) throws Exception {
        try (ZipFile zip = new ZipFile(epubFile)) {
            String opfPath = findOpfPath(zip);
            byte[] opfBytes = readEntry(zip, opfPath);
            Document opf = parseXml(opfBytes);
            String opfDir = parentPath(opfPath);

            String title = firstText(opf, "title");
            if (title.isEmpty()) {
                title = epubFile.getName();
            }
            List<String> creators = texts(opf, "creator");
            List<String> languages = texts(opf, "language");
            List<String> identifiers = texts(opf, "identifier");

            Map<String, ManifestItem> manifest = parseManifest(opf, opfDir);
            List<String> spineIds = parseSpine(opf);
            if (spineIds.isEmpty()) {
                for (Map.Entry<String, ManifestItem> entry : manifest.entrySet()) {
                    if (isDocumentMediaType(entry.getValue().mediaType)) {
                        spineIds.add(entry.getKey());
                    }
                }
            }

            Map<String, String> tocTitles = buildTocMap(zip, opf, manifest, opfDir);
            CssMaps cssMaps = buildCssMaps(zip, manifest);

            List<BookData.Chapter> chapters = new ArrayList<>();
            for (String id : spineIds) {
                ManifestItem item = manifest.get(id);
                if (item == null || !isDocumentMediaType(item.mediaType)) {
                    continue;
                }
                ZipEntry entry = zip.getEntry(item.path);
                if (entry == null) {
                    continue;
                }

                byte[] htmlBytes = readEntry(zip, item.path);
                ChapterContent content = parseChapter(htmlBytes, cssMaps);
                String chapterTitle = tocTitles.get(item.path);
                if (chapterTitle == null || chapterTitle.trim().isEmpty()) {
                    chapterTitle = tocTitles.get(baseName(item.path));
                }
                if ((chapterTitle == null || chapterTitle.trim().isEmpty()) && content.heading != null) {
                    chapterTitle = content.heading;
                }

                List<BookData.Paragraph> chapterParagraphs = removeLeadingDuplicateTitle(
                        content.paragraphs,
                        chapterTitle,
                        content.heading
                );
                if (!chapterParagraphs.isEmpty()) {
                    chapters.add(new BookData.Chapter(
                            blankToNull(chapterTitle),
                            chapterParagraphs
                    ));
                }
            }

            if (chapters.isEmpty()) {
                throw new IllegalArgumentException("Não foi possível extrair conteúdo de texto do EPUB.");
            }

            String bookKey = buildBookIdentity(epubFile, title, creators, languages, identifiers);
            return new BookData(title, bookKey, chapters);
        }
    }

    private static List<BookData.Paragraph> removeLeadingDuplicateTitle(
            List<BookData.Paragraph> paragraphs,
            String chapterTitle,
            String htmlHeading) {
        if (paragraphs == null || paragraphs.isEmpty()) {
            return Collections.emptyList();
        }

        List<BookData.Paragraph> out = new ArrayList<>(paragraphs);
        BookData.Paragraph first = out.get(0);
        String candidate = comparableText(first.text);
        String tocTitle = comparableText(chapterTitle);
        String heading = comparableText(htmlHeading);

        if (!candidate.isEmpty()
                && ((!tocTitle.isEmpty() && candidate.equals(tocTitle))
                || (!heading.isEmpty() && candidate.equals(heading)))) {
            out.remove(0);
            // O título é desenhado separadamente pela app. A margem inferior
            // do bloco original não deve transformar-se numa linha vazia extra.
            if (!out.isEmpty() && out.get(0).gapBefore) {
                out.set(0, out.get(0).withGapBefore(false));
            }
        }
        return out;
    }

    private static String comparableText(String value) {
        return normalizeWhitespace(value == null ? "" : value)
                .toLowerCase(Locale.ROOT);
    }

    private static String findOpfPath(ZipFile zip) throws Exception {
        byte[] container = readEntry(zip, "META-INF/container.xml");
        Document doc = parseXml(container);
        NodeList roots = elements(doc, "rootfile");
        for (int i = 0; i < roots.getLength(); i++) {
            Node node = roots.item(i);
            if (node instanceof Element) {
                String path = ((Element) node).getAttribute("full-path");
                if (!path.trim().isEmpty()) {
                    return normalizePath(path);
                }
            }
        }
        throw new IllegalArgumentException("EPUB inválido: META-INF/container.xml não indica o ficheiro OPF.");
    }

    private static Map<String, ManifestItem> parseManifest(Document opf, String opfDir) {
        Map<String, ManifestItem> result = new LinkedHashMap<>();
        NodeList items = elements(opf, "item");
        for (int i = 0; i < items.getLength(); i++) {
            Node node = items.item(i);
            if (!(node instanceof Element)) continue;
            Element el = (Element) node;
            String id = el.getAttribute("id").trim();
            String href = el.getAttribute("href").trim();
            if (id.isEmpty() || href.isEmpty()) continue;
            String path = resolvePath(opfDir, href);
            result.put(id, new ManifestItem(
                    id,
                    path,
                    el.getAttribute("media-type").trim(),
                    el.getAttribute("properties").trim()
            ));
        }
        return result;
    }

    private static List<String> parseSpine(Document opf) {
        List<String> result = new ArrayList<>();
        NodeList refs = elements(opf, "itemref");
        for (int i = 0; i < refs.getLength(); i++) {
            Node node = refs.item(i);
            if (node instanceof Element) {
                String idref = ((Element) node).getAttribute("idref").trim();
                if (!idref.isEmpty() && !result.contains(idref)) {
                    result.add(idref);
                }
            }
        }
        return result;
    }

    private static Map<String, String> buildTocMap(ZipFile zip,
                                                    Document opf,
                                                    Map<String, ManifestItem> manifest,
                                                    String opfDir) {
        Map<String, String> result = new HashMap<>();

        for (ManifestItem item : manifest.values()) {
            if (containsWord(item.properties, "nav")) {
                try {
                    parseNavDocument(zip, item, result);
                } catch (Exception ignored) {
                    // Tentar NCX/fallback mais abaixo.
                }
            }
        }

        String ncxId = "";
        NodeList spines = elements(opf, "spine");
        if (spines.getLength() > 0 && spines.item(0) instanceof Element) {
            ncxId = ((Element) spines.item(0)).getAttribute("toc").trim();
        }

        ManifestItem ncx = ncxId.isEmpty() ? null : manifest.get(ncxId);
        if (ncx == null) {
            for (ManifestItem item : manifest.values()) {
                if ("application/x-dtbncx+xml".equalsIgnoreCase(item.mediaType)) {
                    ncx = item;
                    break;
                }
            }
        }
        if (ncx != null) {
            try {
                parseNcx(zip, ncx, result);
            } catch (Exception ignored) {
                // O índice é auxiliar; a leitura continua pelos headings do XHTML.
            }
        }

        return result;
    }

    private static void parseNavDocument(ZipFile zip, ManifestItem navItem, Map<String, String> out) throws Exception {
        Document doc = parseXml(readEntry(zip, navItem.path));
        NodeList navs = elements(doc, "nav");
        Element chosen = null;
        for (int i = 0; i < navs.getLength(); i++) {
            if (!(navs.item(i) instanceof Element)) continue;
            Element nav = (Element) navs.item(i);
            String type = attrByLocalName(nav, "type");
            String epubType = nav.getAttribute("epub:type");
            String combined = (type + " " + epubType).toLowerCase(Locale.ROOT);
            if (combined.contains("toc")) {
                chosen = nav;
                break;
            }
            if (chosen == null) chosen = nav;
        }
        if (chosen == null) return;

        NodeList anchors = elements(chosen, "a");
        String navDir = parentPath(navItem.path);
        for (int i = 0; i < anchors.getLength(); i++) {
            if (!(anchors.item(i) instanceof Element)) continue;
            Element a = (Element) anchors.item(i);
            String href = a.getAttribute("href").trim();
            String label = normalizeWhitespace(a.getTextContent());
            if (href.isEmpty() || label.isEmpty()) continue;
            String path = resolvePath(navDir, stripFragment(href));
            out.put(path, label);
            out.put(baseName(path), label);
        }
    }

    private static void parseNcx(ZipFile zip, ManifestItem ncx, Map<String, String> out) throws Exception {
        Document doc = parseXml(readEntry(zip, ncx.path));
        NodeList navPoints = elements(doc, "navPoint");
        String ncxDir = parentPath(ncx.path);
        for (int i = 0; i < navPoints.getLength(); i++) {
            Node node = navPoints.item(i);
            if (!(node instanceof Element)) continue;
            Element point = (Element) node;
            NodeList contents = elements(point, "content");
            NodeList labels = elements(point, "text");
            if (contents.getLength() == 0 || labels.getLength() == 0) continue;
            Element content = (Element) contents.item(0);
            String src = content.getAttribute("src").trim();
            String label = normalizeWhitespace(labels.item(0).getTextContent());
            if (src.isEmpty() || label.isEmpty()) continue;
            String path = resolvePath(ncxDir, stripFragment(src));
            out.put(path, label);
            out.put(baseName(path), label);
        }
    }

    private static CssMaps buildCssMaps(ZipFile zip, Map<String, ManifestItem> manifest) {
        Map<String, String> base = new HashMap<>();
        Map<String, Map<String, String>> classes = new HashMap<>();

        for (ManifestItem item : manifest.values()) {
            if (!"text/css".equalsIgnoreCase(item.mediaType)) continue;
            try {
                String css = new String(readEntry(zip, item.path), StandardCharsets.UTF_8);
                css = CSS_COMMENT.matcher(css).replaceAll("");
                Matcher rules = CSS_RULE.matcher(css);
                while (rules.find()) {
                    String selectors = rules.group(1);
                    Map<String, String> declarations = parseDeclarations(rules.group(2));
                    if (declarations.isEmpty()) continue;

                    for (String selectorRaw : selectors.split(",")) {
                        String selector = selectorRaw.trim();
                        if (selector.equalsIgnoreCase("p")) {
                            base.putAll(declarations);
                            continue;
                        }
                        if (selector.contains(" ") || selector.contains(">") || selector.contains(":")) {
                            continue;
                        }
                        Matcher classMatcher = Pattern.compile("\\.([A-Za-z0-9_-]+)").matcher(selector);
                        while (classMatcher.find()) {
                            String cls = classMatcher.group(1);
                            Map<String, String> target = classes.get(cls);
                            if (target == null) {
                                target = new HashMap<>();
                                classes.put(cls, target);
                            }
                            target.putAll(declarations);
                        }
                    }
                }
            } catch (Exception ignored) {
                // Uma folha CSS danificada não impede a leitura do conteúdo.
            }
        }
        return new CssMaps(base, classes);
    }

    private static ChapterContent parseChapter(byte[] bytes, CssMaps cssMaps) {
        try {
            Document doc = parseXml(bytes);
            removeElements(doc, "script");
            removeElements(doc, "style");
            removeElements(doc, "nav");

            String heading = "";
            Node firstHeadingNode = null;
            for (String tag : new String[]{"h1", "h2", "h3", "h4"}) {
                NodeList nodes = elements(doc, tag);
                if (nodes.getLength() > 0) {
                    for (int i = 0; i < nodes.getLength(); i++) {
                        String candidate = normalizeWhitespace(nodes.item(i).getTextContent());
                        if (!candidate.isEmpty()) {
                            heading = candidate;
                            firstHeadingNode = nodes.item(i);
                            break;
                        }
                    }
                    if (!heading.isEmpty()) break;
                }
            }

            // Se existir um heading HTML real, ele funciona como título do capítulo
            // e não deve voltar a entrar no corpo. Títulos implementados como <div>
            // (muito comuns em EPUB 2) são removidos mais tarde por comparação com o TOC.
            if (firstHeadingNode != null && firstHeadingNode.getParentNode() != null) {
                firstHeadingNode.getParentNode().removeChild(firstHeadingNode);
            }

            List<Element> blocks = new ArrayList<>();
            NodeList bodies = elements(doc, "body");
            if (bodies.getLength() > 0) {
                collectTextBlocks(bodies.item(0), blocks);
            }

            List<BookData.Paragraph> paragraphs = appendBlocksWithFormatting(blocks, cssMaps);
            if (paragraphs.isEmpty() && bodies.getLength() > 0) {
                String text = normalizeWhitespace(bodies.item(0).getTextContent());
                if (!text.isEmpty()) {
                    paragraphs.add(new BookData.Paragraph(text, false, 0f, false, false));
                }
            }
            return new ChapterContent(blankToNull(heading), paragraphs);
        } catch (Exception xmlError) {
            /*
             * Alguns EPUBs contêm XHTML que um parser XML estrito rejeita. O
             * tokenizador tolerante conserva p/div como blocos separados e passa
             * igualmente o CSS de cada bloco para a paginação.
             */
            String html = new String(bytes, StandardCharsets.UTF_8);
            html = html.replaceAll("(?is)<!--.*?-->", " ")
                       .replaceAll("(?is)<script\\b[^>]*>.*?</script>", " ")
                       .replaceAll("(?is)<style\\b[^>]*>.*?</style>", " ")
                       .replaceAll("(?is)<nav\\b[^>]*>.*?</nav>", " ");

            TolerantHtmlContent parsed = tokenizeHtmlContent(html);
            List<HtmlTextBlock> selected = !parsed.paragraphs.isEmpty()
                    ? parsed.paragraphs
                    : parsed.leafDivs;

            List<BookData.Paragraph> paragraphs = appendHtmlTextBlocksWithFormatting(selected, cssMaps);
            if (paragraphs.isEmpty()) {
                String body = firstRegexGroup(html, "(?is)<body\\b[^>]*>(.*?)</body>");
                String bodyHtml = body == null ? html : body;
                bodyHtml = bodyHtml.replaceFirst(
                        "(?is)<h[1-4]\\b[^>]*>.*?</h[1-4]\\s*>", " "
                );
                String text = htmlToText(bodyHtml);
                if (!text.isEmpty()) {
                    paragraphs.add(new BookData.Paragraph(text, false, 0f, false, false));
                }
            }
            return new ChapterContent(blankToNull(parsed.heading), paragraphs);
        }
    }

    /**
     * Recolhe blocos de leitura na ordem real do XHTML sem deixar que um <p>
     * vazio (por exemplo, apenas com uma âncora) faça ignorar todos os <div>
     * seguintes. Foi precisamente esse caso que achatava o capítulo de teste.
     */
    private static void collectTextBlocks(Node parent, List<Element> out) {
        if (parent == null) return;
        Node child = parent.getFirstChild();
        while (child != null) {
            if (child instanceof Element) {
                Element el = (Element) child;
                String name = localName(el).toLowerCase(Locale.ROOT);

                if ("script".equals(name) || "style".equals(name) || "nav".equals(name)) {
                    child = child.getNextSibling();
                    continue;
                }

                if ("p".equals(name) || "li".equals(name) || "blockquote".equals(name)
                        || "pre".equals(name) || "h1".equals(name) || "h2".equals(name)
                        || "h3".equals(name) || "h4".equals(name) || "h5".equals(name)
                        || "h6".equals(name)) {
                    if (!normalizeWhitespace(el.getTextContent()).isEmpty()) out.add(el);
                    child = child.getNextSibling();
                    continue;
                }

                if ("div".equals(name) || "section".equals(name) || "article".equals(name)
                        || "aside".equals(name)) {
                    if (hasDirectBlockChild(el)) {
                        collectTextBlocks(el, out);
                    } else if (!normalizeWhitespace(el.getTextContent()).isEmpty()) {
                        out.add(el);
                    }
                    child = child.getNextSibling();
                    continue;
                }

                // Containers neutros (body, main, etc.): procurar blocos dentro.
                collectTextBlocks(el, out);
            }
            child = child.getNextSibling();
        }
    }

    private static boolean hasDirectBlockChild(Element parent) {
        Node child = parent.getFirstChild();
        while (child != null) {
            if (child instanceof Element) {
                String name = localName((Element) child).toLowerCase(Locale.ROOT);
                if ("p".equals(name) || "div".equals(name) || "section".equals(name)
                        || "article".equals(name) || "aside".equals(name)
                        || "li".equals(name) || "blockquote".equals(name)
                        || "pre".equals(name) || "h1".equals(name) || "h2".equals(name)
                        || "h3".equals(name) || "h4".equals(name) || "h5".equals(name)
                        || "h6".equals(name)) {
                    return true;
                }
            }
            child = child.getNextSibling();
        }
        return false;
    }

    private static TolerantHtmlContent tokenizeHtmlContent(String html) {
        List<HtmlTextBlock> paragraphs = new ArrayList<>();
        List<HtmlTextBlock> leafDivs = new ArrayList<>();
        List<HtmlOpenBlock> divStack = new ArrayList<>();

        HtmlOpenBlock currentParagraph = null;
        String headingTag = null;
        StringBuilder headingText = null;
        String firstHeading = null;

        Pattern tokenPattern = Pattern.compile("(?is)<[^>]+>|[^<]+");
        Pattern tagPattern = Pattern.compile(
                "(?is)^<\\s*(/?)\\s*([A-Za-z0-9:_-]+)([^>]*)>$"
        );
        Matcher tokenMatcher = tokenPattern.matcher(html == null ? "" : html);

        while (tokenMatcher.find()) {
            String token = tokenMatcher.group();

            if (!token.startsWith("<")) {
                String decoded = decodeHtmlTextToken(token);
                boolean insideFirstHeading = headingTag != null && headingText != null;

                if (insideFirstHeading) {
                    headingText.append(decoded);
                } else {
                    if (currentParagraph != null) currentParagraph.text.append(decoded);
                    for (HtmlOpenBlock div : divStack) div.text.append(decoded);
                }
                continue;
            }

            String compact = token.trim();
            if (compact.startsWith("<!") || compact.startsWith("<?")) continue;

            Matcher tagMatcher = tagPattern.matcher(compact);
            if (!tagMatcher.matches()) continue;

            boolean closing = !tagMatcher.group(1).isEmpty();
            String rawName = tagMatcher.group(2).toLowerCase(Locale.ROOT);
            int colon = rawName.lastIndexOf(':');
            String name = colon >= 0 ? rawName.substring(colon + 1) : rawName;
            String attrs = tagMatcher.group(3) == null ? "" : tagMatcher.group(3);
            boolean selfClosing = compact.matches("(?is).*?/\\s*>$");

            if (!closing && ("br".equals(name) || "hr".equals(name))) {
                if (headingTag != null && headingText != null) {
                    headingText.append(' ');
                } else {
                    if (currentParagraph != null) currentParagraph.text.append(' ');
                    for (HtmlOpenBlock div : divStack) div.text.append(' ');
                }
                continue;
            }

            if (!closing && firstHeading == null
                    && ("h1".equals(name) || "h2".equals(name)
                    || "h3".equals(name) || "h4".equals(name))) {
                headingTag = name;
                headingText = new StringBuilder();
                if (selfClosing) {
                    firstHeading = "";
                    headingTag = null;
                    headingText = null;
                }
                continue;
            }

            if (closing && headingTag != null && name.equals(headingTag)) {
                firstHeading = normalizeWhitespace(headingText.toString());
                headingTag = null;
                headingText = null;
                continue;
            }

            if ("p".equals(name)) {
                if (!closing) {
                    // Em HTML, um novo <p> fecha implicitamente o anterior.
                    if (currentParagraph != null) {
                        addHtmlBlock(paragraphs, currentParagraph);
                    }
                    currentParagraph = new HtmlOpenBlock("p", attrs);
                    if (selfClosing) {
                        addHtmlBlock(paragraphs, currentParagraph);
                        currentParagraph = null;
                    }
                } else if (currentParagraph != null) {
                    addHtmlBlock(paragraphs, currentParagraph);
                    currentParagraph = null;
                }
                continue;
            }

            if ("div".equals(name)) {
                if (!closing) {
                    if (!divStack.isEmpty()) {
                        divStack.get(divStack.size() - 1).hasChildDiv = true;
                    }
                    HtmlOpenBlock div = new HtmlOpenBlock("div", attrs);
                    divStack.add(div);
                    if (selfClosing) {
                        closeLastDiv(divStack, leafDivs);
                    }
                } else {
                    closeLastDiv(divStack, leafDivs);
                }
                continue;
            }

            // Se não há <p>, estes elementos ajudam a manter fronteiras lógicas
            // dentro de um div sem transformar todo o capítulo num único fluxo.
            if (!closing && ("li".equals(name) || "blockquote".equals(name)
                    || "section".equals(name) || "article".equals(name)
                    || "aside".equals(name) || "pre".equals(name))) {
                if (currentParagraph != null) currentParagraph.text.append(' ');
                for (HtmlOpenBlock div : divStack) div.text.append(' ');
            }
        }

        if (currentParagraph != null) {
            addHtmlBlock(paragraphs, currentParagraph);
        }
        while (!divStack.isEmpty()) {
            closeLastDiv(divStack, leafDivs);
        }

        return new TolerantHtmlContent(
                blankToNull(firstHeading),
                paragraphs,
                leafDivs
        );
    }

    private static void addHtmlBlock(List<HtmlTextBlock> out, HtmlOpenBlock open) {
        if (open == null) return;
        String text = normalizeWhitespace(open.text.toString());
        if (!text.isEmpty()) {
            out.add(new HtmlTextBlock(open.tag, open.attrs, text));
        }
    }

    private static void closeLastDiv(List<HtmlOpenBlock> stack,
                                     List<HtmlTextBlock> leafDivs) {
        if (stack.isEmpty()) return;
        HtmlOpenBlock div = stack.remove(stack.size() - 1);
        if (!div.hasChildDiv) {
            addHtmlBlock(leafDivs, div);
        }
    }

    private static List<BookData.Paragraph> appendHtmlTextBlocksWithFormatting(
            List<HtmlTextBlock> blocks,
            CssMaps cssMaps) {
        List<BookData.Paragraph> result = new ArrayList<>();
        Double previousBottom = null;

        for (HtmlTextBlock block : blocks) {
            String blockText = normalizeWhitespace(block.text);
            if (blockText.isEmpty()) continue;

            Map<String, String> declarations = declarationsForHtmlBlock(
                    block.tag, block.attrs, cssMaps);
            double defaultMargin = "p".equalsIgnoreCase(block.tag) ? 1.0 : 0.0;
            double[] margins = verticalMarginsFromDeclarations(declarations, defaultMargin);
            double top = margins[0];
            double bottom = margins[1];
            boolean gapBefore = !result.isEmpty()
                    && previousBottom != null
                    && Math.max(previousBottom, top) >= 0.45;

            float indentEm = textIndentFromDeclarations(declarations);
            boolean italic = isItalic(declarations);
            boolean bold = isBold(declarations);
            result.add(new BookData.Paragraph(
                    blockText, gapBefore, indentEm, italic, bold));
            previousBottom = bottom;
        }
        return result;
    }

    private static String decodeHtmlTextToken(String text) {
        if (text == null || text.isEmpty()) return "";
        String decoded = text
                .replace("&nbsp;", "\u00A0")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&apos;", "'")
                .replace("&#39;", "'");

        Matcher numeric = Pattern.compile("&#(x?[0-9A-Fa-f]+);").matcher(decoded);
        StringBuffer out = new StringBuffer();
        while (numeric.find()) {
            String raw = numeric.group(1);
            try {
                int value = raw.startsWith("x") || raw.startsWith("X")
                        ? Integer.parseInt(raw.substring(1), 16)
                        : Integer.parseInt(raw, 10);
                numeric.appendReplacement(
                        out,
                        Matcher.quoteReplacement(
                                new String(Character.toChars(value))
                        )
                );
            } catch (Exception ignored) {
                numeric.appendReplacement(
                        out,
                        Matcher.quoteReplacement(numeric.group())
                );
            }
        }
        numeric.appendTail(out);
        return out.toString();
    }

    private static Map<String, String> declarationsForHtmlBlock(
            String tag,
            String attrs,
            CssMaps cssMaps) {
        Map<String, String> declarations = new HashMap<>();
        if ("p".equalsIgnoreCase(tag)) declarations.putAll(cssMaps.base);

        String classAttr = htmlAttribute(attrs, "class");
        if (!classAttr.trim().isEmpty()) {
            for (String cls : classAttr.trim().split("\\s+")) {
                Map<String, String> values = cssMaps.classes.get(cls);
                if (values != null) declarations.putAll(values);
            }
        }

        String inline = htmlAttribute(attrs, "style");
        if (!inline.trim().isEmpty()) declarations.putAll(parseDeclarations(inline));
        return declarations;
    }

    private static String htmlAttribute(String attrs, String name) {
        if (attrs == null || attrs.isEmpty()) return "";
        Pattern p = Pattern.compile(
                "(?is)(?:^|\\s)" + Pattern.quote(name)
                        + "\\s*=\\s*(?:\"([^\"]*)\"|'([^']*)'|([^\\s>]+))");
        Matcher m = p.matcher(attrs);
        if (!m.find()) return "";
        if (m.group(1) != null) return m.group(1);
        if (m.group(2) != null) return m.group(2);
        return m.group(3) == null ? "" : m.group(3);
    }

    private static List<BookData.Paragraph> appendBlocksWithFormatting(
            List<Element> blocks,
            CssMaps cssMaps) {
        List<BookData.Paragraph> result = new ArrayList<>();
        Double previousBottom = null;

        for (Element tag : blocks) {
            String text = normalizeWhitespace(tag.getTextContent());
            if (text.isEmpty()) continue;

            String tagName = localName(tag).toLowerCase(Locale.ROOT);
            Map<String, String> declarations = declarationsForElement(tag, cssMaps);
            double defaultMargin = "p".equals(tagName) ? 1.0 : 0.0;
            double[] margins = verticalMarginsFromDeclarations(declarations, defaultMargin);
            double top = margins[0];
            double bottom = margins[1];
            boolean gapBefore = !result.isEmpty()
                    && previousBottom != null
                    && Math.max(previousBottom, top) >= 0.45;

            float indentEm = textIndentFromDeclarations(declarations);
            boolean italic = isItalic(declarations) || entirelyWrappedBy(tag, "i", "em");
            boolean bold = isBold(declarations) || entirelyWrappedBy(tag, "b", "strong");

            result.add(new BookData.Paragraph(
                    text, gapBefore, indentEm, italic, bold));
            previousBottom = bottom;
        }
        return result;
    }

    private static Map<String, String> declarationsForElement(Element tag, CssMaps cssMaps) {
        String tagName = localName(tag).toLowerCase(Locale.ROOT);
        Map<String, String> declarations = new HashMap<>();
        if ("p".equals(tagName)) declarations.putAll(cssMaps.base);

        String classAttr = tag.getAttribute("class");
        if (!classAttr.trim().isEmpty()) {
            for (String cls : classAttr.trim().split("\\s+")) {
                Map<String, String> values = cssMaps.classes.get(cls);
                if (values != null) declarations.putAll(values);
            }
        }
        String inline = tag.getAttribute("style");
        if (!inline.trim().isEmpty()) declarations.putAll(parseDeclarations(inline));
        return declarations;
    }

    private static double[] verticalMarginsFromDeclarations(
            Map<String, String> declarations,
            double defaultMargin) {
        Double top = null;
        Double bottom = null;
        String shorthand = declarations.get("margin");
        if (shorthand != null) {
            String[] parts = shorthand.trim().split("\\s+");
            List<Double> values = new ArrayList<>();
            boolean valid = true;
            for (String part : parts) {
                Double v = cssLengthToEm(part);
                if (v == null) { valid = false; break; }
                values.add(v);
            }
            if (valid && !values.isEmpty()) {
                if (values.size() == 1) {
                    top = bottom = values.get(0);
                } else if (values.size() == 2) {
                    top = bottom = values.get(0);
                } else {
                    top = values.get(0);
                    bottom = values.get(2);
                }
            }
        }
        if (declarations.containsKey("margin-top")) {
            Double v = cssLengthToEm(declarations.get("margin-top"));
            if (v != null) top = v;
        }
        if (declarations.containsKey("margin-bottom")) {
            Double v = cssLengthToEm(declarations.get("margin-bottom"));
            if (v != null) bottom = v;
        }
        if (top == null) top = defaultMargin;
        if (bottom == null) bottom = defaultMargin;
        return new double[]{Math.max(0.0, top), Math.max(0.0, bottom)};
    }

    private static float textIndentFromDeclarations(Map<String, String> declarations) {
        Double value = cssLengthToEm(declarations.get("text-indent"));
        if (value == null) return 0f;
        return (float) Math.max(0.0, value);
    }

    private static boolean isItalic(Map<String, String> declarations) {
        String style = declarations.get("font-style");
        return style != null && (style.toLowerCase(Locale.ROOT).contains("italic")
                || style.toLowerCase(Locale.ROOT).contains("oblique"));
    }

    private static boolean isBold(Map<String, String> declarations) {
        String weight = declarations.get("font-weight");
        if (weight == null) return false;
        String value = weight.trim().toLowerCase(Locale.ROOT);
        if (value.contains("bold")) return true;
        try {
            return Integer.parseInt(value) >= 600;
        } catch (NumberFormatException ignored) {
            return false;
        }
    }

    private static boolean entirelyWrappedBy(Element element, String... tagNames) {
        Node only = null;
        Node child = element.getFirstChild();
        while (child != null) {
            if (child.getNodeType() == Node.TEXT_NODE) {
                if (!normalizeWhitespace(child.getTextContent()).isEmpty()) return false;
            } else if (child instanceof Element) {
                if (only != null) return false;
                only = child;
            }
            child = child.getNextSibling();
        }
        if (!(only instanceof Element)) return false;
        String name = localName((Element) only).toLowerCase(Locale.ROOT);
        for (String candidate : tagNames) {
            if (candidate.equalsIgnoreCase(name)) return true;
        }
        return false;
    }

    private static Map<String, String> parseDeclarations(String body) {
        Map<String, String> result = new HashMap<>();
        Matcher matcher = CSS_DECL.matcher(body == null ? "" : body);
        while (matcher.find()) {
            result.put(matcher.group(1).trim().toLowerCase(Locale.ROOT), matcher.group(2).trim());
        }
        return result;
    }

    private static Double cssLengthToEm(String value) {
        if (value == null) return null;
        String v = value.trim().toLowerCase(Locale.ROOT);
        if (v.isEmpty()) return null;
        if (v.equals("0") || v.equals("0.0")) return 0.0;
        Matcher m = CSS_LENGTH.matcher(v);
        if (!m.matches()) return null;
        double number = Double.parseDouble(m.group(1));
        String unit = m.group(2) == null ? "" : m.group(2).toLowerCase(Locale.ROOT);
        switch (unit) {
            case "":
            case "em":
            case "rem": return number;
            case "px": return number / 16.0;
            case "pt": return number / 12.0;
            case "%": return number / 100.0;
            default: return null;
        }
    }

    private static String buildBookIdentity(File file,
                                            String title,
                                            List<String> creators,
                                            List<String> languages,
                                            List<String> identifiers) throws Exception {
        for (String identifier : identifiers) {
            String compact = identifier.replaceAll("[^0-9Xx]", "");
            if (compact.matches("\\d{13}")) {
                return "isbn:" + compact;
            }
            if (compact.length() == 10 && compact.substring(0, 9).matches("\\d{9}") &&
                    (Character.isDigit(compact.charAt(9)) || compact.substring(9).equalsIgnoreCase("X"))) {
                return "isbn:" + compact.toUpperCase(Locale.ROOT);
            }
        }

        String normalizedTitle = identityText(title);
        List<String> normalizedCreators = new ArrayList<>();
        for (String s : creators) normalizedCreators.add(identityText(s));
        List<String> normalizedLanguages = new ArrayList<>();
        for (String s : languages) normalizedLanguages.add(identityText(s));

        String metadataIdentity = normalizedTitle + "||" + join("|", normalizedCreators) + "||" + join("|", normalizedLanguages);
        if (!normalizedTitle.isEmpty() && !normalizedCreators.isEmpty() && !join("", normalizedCreators).isEmpty()) {
            return "metadata:" + sha256(metadataIdentity.getBytes(StandardCharsets.UTF_8));
        }
        return "sha256:" + sha256File(file);
    }

    private static String identityText(String value) {
        return normalizeWhitespace(value == null ? "" : value).toLowerCase(Locale.ROOT);
    }

    private static String sha256File(File file) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        try (InputStream in = new FileInputStream(file)) {
            byte[] buffer = new byte[1024 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) digest.update(buffer, 0, read);
        }
        return hex(digest.digest());
    }

    private static String sha256(byte[] bytes) throws Exception {
        MessageDigest digest = MessageDigest.getInstance("SHA-256");
        return hex(digest.digest(bytes));
    }

    private static String hex(byte[] bytes) {
        StringBuilder sb = new StringBuilder(bytes.length * 2);
        for (byte b : bytes) sb.append(String.format(Locale.ROOT, "%02x", b & 0xff));
        return sb.toString();
    }

    private static Document parseXml(byte[] bytes) throws Exception {
        DocumentBuilderFactory factory = DocumentBuilderFactory.newInstance();
        factory.setNamespaceAware(true);
        try { factory.setFeature("http://xml.org/sax/features/external-general-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature("http://xml.org/sax/features/external-parameter-entities", false); } catch (Exception ignored) {}
        try { factory.setFeature("http://apache.org/xml/features/nonvalidating/load-external-dtd", false); } catch (Exception ignored) {}
        DocumentBuilder builder = factory.newDocumentBuilder();
        try {
            builder.setEntityResolver((publicId, systemId) -> new InputSource(new ByteArrayInputStream(new byte[0])));
        } catch (Exception ignored) {}
        return builder.parse(new ByteArrayInputStream(bytes));
    }


    private static String localName(Element element) {
        if (element == null) return "";
        String local = element.getLocalName();
        if (local != null && !local.isEmpty()) return local;
        String name = element.getTagName();
        int colon = name == null ? -1 : name.lastIndexOf(':');
        return colon >= 0 ? name.substring(colon + 1) : (name == null ? "" : name);
    }

    private static NodeList elements(Node node, String localName) {
        if (node instanceof Document) {
            Document doc = (Document) node;
            NodeList ns = doc.getElementsByTagNameNS("*", localName);
            return ns.getLength() > 0 ? ns : doc.getElementsByTagName(localName);
        }
        if (node instanceof Element) {
            Element el = (Element) node;
            NodeList ns = el.getElementsByTagNameNS("*", localName);
            return ns.getLength() > 0 ? ns : el.getElementsByTagName(localName);
        }
        return new EmptyNodeList();
    }

    private static void removeElements(Document doc, String tag) {
        NodeList nodes = elements(doc, tag);
        List<Node> copy = new ArrayList<>();
        for (int i = 0; i < nodes.getLength(); i++) copy.add(nodes.item(i));
        for (Node node : copy) {
            if (node.getParentNode() != null) node.getParentNode().removeChild(node);
        }
    }

    private static String firstText(Document doc, String tag) {
        List<String> all = texts(doc, tag);
        return all.isEmpty() ? "" : all.get(0);
    }

    private static List<String> texts(Document doc, String tag) {
        NodeList nodes = elements(doc, tag);
        List<String> result = new ArrayList<>();
        for (int i = 0; i < nodes.getLength(); i++) {
            String text = normalizeWhitespace(nodes.item(i).getTextContent());
            if (!text.isEmpty()) result.add(text);
        }
        return result;
    }

    private static byte[] readEntry(ZipFile zip, String path) throws Exception {
        ZipEntry entry = zip.getEntry(normalizePath(path));
        if (entry == null) throw new IllegalArgumentException("Ficheiro em falta no EPUB: " + path);
        try (InputStream in = zip.getInputStream(entry); ByteArrayOutputStream out = new ByteArrayOutputStream()) {
            byte[] buffer = new byte[32 * 1024];
            int read;
            while ((read = in.read(buffer)) != -1) out.write(buffer, 0, read);
            return out.toByteArray();
        }
    }

    private static boolean isDocumentMediaType(String mediaType) {
        String mt = mediaType == null ? "" : mediaType.toLowerCase(Locale.ROOT);
        return mt.contains("xhtml") || mt.equals("text/html") || mt.contains("html");
    }

    private static boolean containsWord(String text, String word) {
        if (text == null) return false;
        for (String part : text.trim().split("\\s+")) if (part.equalsIgnoreCase(word)) return true;
        return false;
    }

    private static String resolvePath(String baseDir, String href) {
        String decoded = Uri.decode(stripFragment(href == null ? "" : href));
        String combined = (baseDir == null || baseDir.isEmpty()) ? decoded : baseDir + "/" + decoded;
        return normalizePath(combined);
    }

    private static String normalizePath(String raw) {
        if (raw == null) return "";
        String p = raw.replace('\\', '/');
        while (p.startsWith("./")) p = p.substring(2);
        String[] parts = p.split("/");
        List<String> out = new ArrayList<>();
        for (String part : parts) {
            if (part.isEmpty() || part.equals(".")) continue;
            if (part.equals("..")) {
                if (!out.isEmpty()) out.remove(out.size() - 1);
            } else {
                out.add(part);
            }
        }
        return join("/", out);
    }

    private static String parentPath(String path) {
        int idx = path.lastIndexOf('/');
        return idx < 0 ? "" : path.substring(0, idx);
    }

    private static String baseName(String path) {
        int idx = path.lastIndexOf('/');
        return idx < 0 ? path : path.substring(idx + 1);
    }

    private static String stripFragment(String href) {
        if (href == null) return "";
        int idx = href.indexOf('#');
        return idx < 0 ? href : href.substring(0, idx);
    }

    private static String normalizeWhitespace(String text) {
        return text == null ? "" : text.replace('\u00A0', ' ').replaceAll("\\s+", " ").trim();
    }

    private static String blankToNull(String text) {
        if (text == null) return null;
        String t = text.trim();
        return t.isEmpty() ? null : t;
    }

    private static String attrByLocalName(Element element, String name) {
        if (element.hasAttribute(name)) return element.getAttribute(name);
        if (element.hasAttributeNS("http://www.idpf.org/2007/ops", name)) {
            return element.getAttributeNS("http://www.idpf.org/2007/ops", name);
        }
        return "";
    }

    private static String firstRegexText(String html, String tagPattern) {
        Matcher m = Pattern.compile("(?is)<(?:" + tagPattern + ")\\b[^>]*>(.*?)</(?:" + tagPattern + ")>").matcher(html);
        return m.find() ? htmlToText(m.group(1)) : "";
    }

    private static String firstRegexGroup(String text, String regex) {
        Matcher m = Pattern.compile(regex).matcher(text);
        return m.find() ? m.group(1) : null;
    }

    private static String htmlToText(String html) {
        if (html == null) return "";
        String text = html
                .replaceAll("(?is)<br\\s*/?>", " ")
                .replaceAll("(?is)<[^>]+>", " ")
                .replace("&nbsp;", " ")
                .replace("&amp;", "&")
                .replace("&lt;", "<")
                .replace("&gt;", ">")
                .replace("&quot;", "\"")
                .replace("&#39;", "'");
        return normalizeWhitespace(text);
    }

    private static String join(String separator, List<String> values) {
        if (values == null || values.isEmpty()) return "";
        StringBuilder sb = new StringBuilder();
        for (String value : values) {
            if (sb.length() > 0) sb.append(separator);
            sb.append(value);
        }
        return sb.toString();
    }

    private static final class HtmlOpenBlock {
        final String tag;
        final String attrs;
        final StringBuilder text = new StringBuilder();
        boolean hasChildDiv;

        HtmlOpenBlock(String tag, String attrs) {
            this.tag = tag == null ? "" : tag;
            this.attrs = attrs == null ? "" : attrs;
        }
    }

    private static final class HtmlTextBlock {
        final String tag;
        final String attrs;
        final String text;

        HtmlTextBlock(String tag, String attrs, String text) {
            this.tag = tag == null ? "" : tag;
            this.attrs = attrs == null ? "" : attrs;
            this.text = text == null ? "" : text;
        }
    }

    private static final class TolerantHtmlContent {
        final String heading;
        final List<HtmlTextBlock> paragraphs;
        final List<HtmlTextBlock> leafDivs;

        TolerantHtmlContent(String heading,
                            List<HtmlTextBlock> paragraphs,
                            List<HtmlTextBlock> leafDivs) {
            this.heading = heading;
            this.paragraphs = paragraphs == null
                    ? Collections.emptyList() : paragraphs;
            this.leafDivs = leafDivs == null
                    ? Collections.emptyList() : leafDivs;
        }
    }

    private static final class ManifestItem {
        final String id;
        final String path;
        final String mediaType;
        final String properties;

        ManifestItem(String id, String path, String mediaType, String properties) {
            this.id = id;
            this.path = path;
            this.mediaType = mediaType == null ? "" : mediaType;
            this.properties = properties == null ? "" : properties;
        }
    }

    private static final class CssMaps {
        final Map<String, String> base;
        final Map<String, Map<String, String>> classes;

        CssMaps(Map<String, String> base, Map<String, Map<String, String>> classes) {
            this.base = base;
            this.classes = classes;
        }
    }

    private static final class ChapterContent {
        final String heading;
        final List<BookData.Paragraph> paragraphs;

        ChapterContent(String heading, List<BookData.Paragraph> paragraphs) {
            this.heading = heading;
            this.paragraphs = paragraphs == null ? Collections.emptyList() : paragraphs;
        }
    }

    private static final class EmptyNodeList implements NodeList {
        @Override public Node item(int index) { return null; }
        @Override public int getLength() { return 0; }
    }
}
