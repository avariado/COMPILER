package com.epubookobo.reader;

import java.util.ArrayList;
import java.util.List;

public final class BookData {
    public final String title;
    public final String key;
    public final List<Chapter> chapters;

    public BookData(String title, String key, List<Chapter> chapters) {
        this.title = title == null ? "" : title;
        this.key = key == null ? "" : key;
        this.chapters = chapters == null ? new ArrayList<>() : chapters;
    }

    public static final class Chapter {
        public final String title;
        public final List<Paragraph> paragraphs;

        public Chapter(String title, List<Paragraph> paragraphs) {
            this.title = title;
            this.paragraphs = paragraphs == null ? new ArrayList<>() : paragraphs;
        }
    }

    /**
     * Um bloco de texto do EPUB preservado até à paginação.
     * gapBefore representa uma separação vertical real entre blocos; textIndentEm
     * corresponde ao CSS text-indent e é aplicado apenas à primeira linha.
     */
    public static final class Paragraph {
        public final String text;
        public final boolean gapBefore;
        public final float textIndentEm;
        public final boolean italic;
        public final boolean bold;

        public Paragraph(String text,
                         boolean gapBefore,
                         float textIndentEm,
                         boolean italic,
                         boolean bold) {
            this.text = text == null ? "" : text;
            this.gapBefore = gapBefore;
            this.textIndentEm = Math.max(0f, textIndentEm);
            this.italic = italic;
            this.bold = bold;
        }

        public Paragraph withGapBefore(boolean value) {
            return new Paragraph(text, value, textIndentEm, italic, bold);
        }
    }
}
