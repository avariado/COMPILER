package com.epubookobo.reader;

import android.graphics.Paint;
import android.graphics.Typeface;

import java.util.ArrayList;
import java.util.List;

public final class Paginator {
    private final Paint bodyPaint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.SUBPIXEL_TEXT_FLAG);
    private final float textWidth;
    private final int lineHeight;
    private final int bodyTop;
    private final int bodyBottom;
    private final int titleReserved;

    public Paginator(int screenWidthPx,
                     int screenHeightPx,
                     float density,
                     float scaledDensity,
                     int fontSizeSp,
                     float lineSpacing,
                     int sideMarginDp) {
        int clampedMarginDp = Math.max(ReaderStateStore.MIN_SIDE_MARGIN_DP,
                Math.min(ReaderStateStore.MAX_SIDE_MARGIN_DP, sideMarginDp));
        int marginX = Math.round(clampedMarginDp * density);
        int marginBottom = Math.round(28f * density);
        int footerGap = Math.round(24f * density);
        bodyTop = Math.round(50f * density);
        titleReserved = Math.round(40f * density);
        int footerY = screenHeightPx - marginBottom;
        bodyBottom = footerY - footerGap;
        textWidth = Math.max(40f, screenWidthPx - 2f * marginX);

        bodyPaint.setTypeface(Typeface.create(Typeface.SERIF, Typeface.NORMAL));
        bodyPaint.setTextSize(fontSizeSp * scaledDensity);
        Paint.FontMetrics fm = bodyPaint.getFontMetrics();
        float base = Math.max(1f, fm.descent - fm.ascent);
        lineHeight = Math.max(1, Math.round(base * lineSpacing));
    }

    public Paint getBodyPaint() {
        return bodyPaint;
    }

    public int getLineHeight() {
        return lineHeight;
    }

    public PaginationResult paginate(BookData book) {
        List<PageData> pages = new ArrayList<>();
        List<Integer> starts = new ArrayList<>();

        for (BookData.Chapter chapter : book.chapters) {
            starts.add(pages.size());
            pages.addAll(paginateChapter(chapter.paragraphs));
        }

        return new PaginationResult(pages, starts);
    }

    private List<PageData> paginateChapter(List<BookData.Paragraph> paragraphs) {
        List<PageData.Line> allLines = new ArrayList<>();

        for (BookData.Paragraph paragraph : paragraphs) {
            if (paragraph == null || paragraph.text.trim().isEmpty()) continue;

            if (paragraph.gapBefore
                    && !allLines.isEmpty()
                    && !allLines.get(allLines.size() - 1).text.isEmpty()) {
                allLines.add(new PageData.Line("", true, 0f, false, false));
            }

            Paint paragraphPaint = paintFor(paragraph);
            float indentPx = Math.min(textWidth * 0.45f,
                    Math.max(0f, paragraph.textIndentEm * bodyPaint.getTextSize()));
            List<String> wrapped = wrap(paragraph.text, paragraphPaint, indentPx);
            for (int i = 0; i < wrapped.size(); i++) {
                allLines.add(new PageData.Line(
                        wrapped.get(i),
                        i == wrapped.size() - 1,
                        i == 0 ? indentPx : 0f,
                        paragraph.italic,
                        paragraph.bold
                ));
            }
        }

        int usableHeight = Math.max(lineHeight, bodyBottom - bodyTop);
        int normalLines = Math.max(1, usableHeight / lineHeight);
        int firstPageLines = Math.max(1, (usableHeight - titleReserved) / lineHeight);

        List<PageData> pages = new ArrayList<>();
        int pos = 0;
        int capacity = firstPageLines;

        while (pos < allLines.size()) {
            List<PageData.Line> page = new ArrayList<>(capacity);
            int end = Math.min(allLines.size(), pos + capacity);
            for (int i = pos; i < end; i++) {
                page.add(allLines.get(i));
            }
            while (page.size() < capacity) {
                page.add(new PageData.Line("", true, 0f, false, false));
            }
            pages.add(new PageData(page));
            pos += capacity;
            capacity = normalLines;
        }

        if (pages.isEmpty()) {
            List<PageData.Line> empty = new ArrayList<>();
            for (int i = 0; i < firstPageLines; i++) {
                empty.add(new PageData.Line("", true, 0f, false, false));
            }
            pages.add(new PageData(empty));
        }
        return pages;
    }

    private Paint paintFor(BookData.Paragraph paragraph) {
        if (!paragraph.italic && !paragraph.bold) return bodyPaint;
        Paint paint = new Paint(bodyPaint);
        int style;
        if (paragraph.bold && paragraph.italic) style = Typeface.BOLD_ITALIC;
        else if (paragraph.bold) style = Typeface.BOLD;
        else style = Typeface.ITALIC;
        paint.setTypeface(Typeface.create(Typeface.SERIF, style));
        return paint;
    }

    private List<String> wrap(String text, Paint paint, float firstLineIndentPx) {
        List<String> lines = new ArrayList<>();
        String trimmed = text == null ? "" : text.trim();
        if (trimmed.isEmpty()) return lines;

        String[] words = trimmed.split("\\s+");
        String current = "";
        boolean firstLine = true;

        for (String word : words) {
            float allowedWidth = Math.max(20f,
                    textWidth - (firstLine ? firstLineIndentPx : 0f));
            String test = current.isEmpty() ? word : current + " " + word;
            if (paint.measureText(test) <= allowedWidth) {
                current = test;
                continue;
            }

            if (!current.isEmpty()) {
                lines.add(current);
                current = "";
                firstLine = false;
                allowedWidth = textWidth;
            }

            if (paint.measureText(word) > allowedWidth) {
                StringBuilder fragment = new StringBuilder();
                for (int offset = 0; offset < word.length();) {
                    int cp = word.codePointAt(offset);
                    String piece = new String(Character.toChars(cp));
                    String candidate = fragment + piece;
                    if (fragment.length() > 0 && paint.measureText(candidate) > allowedWidth) {
                        lines.add(fragment.toString());
                        fragment.setLength(0);
                        firstLine = false;
                        allowedWidth = textWidth;
                    }
                    fragment.append(piece);
                    offset += Character.charCount(cp);
                }
                current = fragment.toString();
            } else {
                current = word;
            }
        }

        if (!current.isEmpty()) lines.add(current);
        return lines;
    }
}
