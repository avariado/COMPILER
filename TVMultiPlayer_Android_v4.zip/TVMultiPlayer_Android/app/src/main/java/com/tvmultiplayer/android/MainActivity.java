package com.tvmultiplayer.android;

import android.app.*;
import android.os.*;
import android.content.*;
import android.content.res.Configuration;
import android.database.Cursor;
import android.graphics.Color;
import android.net.Uri;
import android.provider.*;
import android.text.*;
import android.view.*;
import android.webkit.*;
import android.widget.*;
import androidx.annotation.OptIn;
import androidx.media3.common.*;
import androidx.media3.common.util.UnstableApi;
import androidx.media3.exoplayer.ExoPlayer;
import androidx.media3.ui.PlayerView;
import org.json.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.util.*;
import java.util.concurrent.*;

public class MainActivity extends Activity {
    private final int BG=Color.rgb(17,21,27), PANEL=Color.rgb(28,35,45), TEXT=Color.WHITE, ACCENT=Color.rgb(38,136,210);
    private final ArrayList<MediaItemEntry> entries=new ArrayList<>(), all=new ArrayList<>();
    private final HashSet<String> favorites=new HashSet<>();
    private final ExecutorService workers=Executors.newFixedThreadPool(3);
    private String mode="IPTV", filterGroup="Todos", query="";
    private LinearLayout root, controls, listBox, toolbar;
    private FrameLayout videoContainer;
    private PlayerView playerView;
    private ExoPlayer player;
    private TextView heading, status, nowPlaying;
    private EditText search;
    private Spinner groups;
    private SeekBar volume;
    private MediaItemEntry selected;
    private boolean onlyFavorites=false, fullScreen=false;
    private WebView webView;
    private final HashSet<String> detected=new HashSet<>();
    private static final int PICK_LIST=111, PICK_MEDIA=112, PICK_EXPORT=113;
    private static final String DEFAULT_IPTV_URL="https://pastebin.com/raw/57GAkcRF";
    private String pendingExport="";
    private int savedListPosition=0;
    private ScrollView channelScroll;

    @Override public void onCreate(Bundle state){ super.onCreate(state); getWindow().setStatusBarColor(BG); getWindow().setNavigationBarColor(BG);
        player=new ExoPlayer.Builder(this).build(); player.setRepeatMode(Player.REPEAT_MODE_OFF);
        player.addListener(new Player.Listener(){
            @Override public void onPlayerError(PlaybackException error){runOnUiThread(()->message("Erro de reprodução: "+error.getErrorCodeName()+". Algumas fontes necessitam de autenticação ou codecs adicionais."));}
            @Override public void onPlaybackStateChanged(int st){ updateKeepScreenOn(); if(st==Player.STATE_ENDED && "Rádio".equals(mode)) playNextPodcast(); }
            @Override public void onIsPlayingChanged(boolean isPlaying){updateKeepScreenOn();}
        });
        loadStore(); if(state!=null){mode=state.getString("mode",mode); filterGroup=state.getString("group",filterGroup); query=state.getString("query",query);onlyFavorites=state.getBoolean("favoritesOnly",false);savedListPosition=state.getInt("scrollPosition",0);} build();
        if(!hasDefaultIptvEntries() && !getPreferences(0).getBoolean("default_iptv_loaded",false)) loadDefaultIptv();
        Intent intent=getIntent(); if(intent!=null && Intent.ACTION_VIEW.equals(intent.getAction()) && intent.getData()!=null) play(new MediaItemEntry("Abrir ligação",intent.getDataString(),"Externos","IPTV"));
    }
    private boolean hasDefaultIptvEntries(){for(MediaItemEntry e:all)if("IPTV".equals(e.type))return true;return false;}
    private void loadDefaultIptv(){
        // Load once on first launch; only mark completed after a successful parse.
        fetch(DEFAULT_IPTV_URL,"IPTV",true);
    }
    private void updateKeepScreenOn(){
        if(player!=null)getWindow().getDecorView().setKeepScreenOn(player.isPlaying());
    }
    private TextView text(String value,int size){TextView t=new TextView(this); t.setText(value);t.setTextColor(TEXT);t.setTextSize(size);t.setGravity(Gravity.CENTER_VERTICAL);return t;}
    private LinearLayout vertical(){LinearLayout l=new LinearLayout(this);l.setOrientation(1);return l;}
    private Button button(String s,Runnable click){Button b=new Button(this);b.setText(s);b.setTextColor(TEXT);b.setAllCaps(false);b.setTextSize(14);b.setMinHeight(dp(52));b.setPadding(dp(5),dp(4),dp(5),dp(4));b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(PANEL));b.setOnClickListener(v->click.run());return b;}
    private void addButton(LinearLayout parent,String s,Runnable click){parent.addView(button(s,click),new LinearLayout.LayoutParams(0,dp(54),1));}
    private void build(){
        root=vertical();root.setBackgroundColor(BG);root.setFitsSystemWindows(false);setContentView(root);
        configureSafeInsets();
        LinearLayout appBar=new LinearLayout(this);appBar.setGravity(Gravity.CENTER);appBar.setBackgroundColor(ACCENT);
        TextView appTitle=text("TV MultiPlayer",18);appTitle.setTypeface(null,android.graphics.Typeface.BOLD);appTitle.setGravity(Gravity.CENTER);
        appBar.addView(appTitle,new LinearLayout.LayoutParams(-1,-1));root.addView(appBar,new LinearLayout.LayoutParams(-1,dp(40)));
        toolbar=new LinearLayout(this);toolbar.setBackgroundColor(PANEL);root.addView(toolbar,new LinearLayout.LayoutParams(-1,dp(56)));
        for(String tab:new String[]{"IPTV","WebTV","Rádio"})addButton(toolbar,tab,()->switchMode(tab));
        heading=text(mode,13);heading.setGravity(Gravity.CENTER);heading.setPadding(12,2,12,2);root.addView(heading,new LinearLayout.LayoutParams(-1,dp(28)));
        videoContainer=new FrameLayout(this);videoContainer.setBackgroundColor(Color.BLACK);
        root.addView(videoContainer,new LinearLayout.LayoutParams(-1,videoHeight()));
        playerView=new PlayerView(this);playerView.setPlayer(player);playerView.setUseController(true);videoContainer.addView(playerView,new FrameLayout.LayoutParams(-1,-1));
        nowPlaying=text("Sem reprodução",12);nowPlaying.setPadding(10,3,10,3);root.addView(nowPlaying,new LinearLayout.LayoutParams(-1,dp(36)));
        controls=new LinearLayout(this);root.addView(controls,new LinearLayout.LayoutParams(-1,dp(56)));
        addButton(controls,"Abrir",this::openMenu);
        addButton(controls,"URL",this::urlDialog);
        addButton(controls,"Guardar lista",this::exportPlaylist);
        addButton(controls,"⛶",this::toggleFullscreen);
        LinearLayout bar=new LinearLayout(this);root.addView(bar,new LinearLayout.LayoutParams(-1,dp(56)));
        search=new EditText(this);search.setSingleLine(true);search.setText(query);search.setTextColor(TEXT);search.setHintTextColor(0xffaaaaaa);search.setTextSize(14);search.setHint("Pesquisar");bar.addView(search,new LinearLayout.LayoutParams(0,-1,2));
        search.addTextChangedListener(new TextWatcher(){public void beforeTextChanged(CharSequence s,int st,int c,int a){}public void onTextChanged(CharSequence s,int st,int before,int count){query=s.toString();refresh();}public void afterTextChanged(Editable e){}});
        groups=new Spinner(this);bar.addView(groups,new LinearLayout.LayoutParams(0,-1,2));
        addButton(bar,"★",()->{onlyFavorites=!onlyFavorites;refresh();});
        status=text("Pronto",12);status.setPadding(12,0,12,0);root.addView(status,new LinearLayout.LayoutParams(-1,dp(32)));
        channelScroll=new ScrollView(this);root.addView(channelScroll,new LinearLayout.LayoutParams(-1,0,1));
        listBox=vertical();channelScroll.addView(listBox);
        if(mode.equals("WebTV")){addButtonToList("Abrir página Web para detetar streams",this::pageDialog);}
        refresh(); if(savedListPosition>0){channelScroll.post(()->channelScroll.scrollTo(0,savedListPosition));savedListPosition=0;}
    }
    private int videoHeight(){return dp(getResources().getConfiguration().orientation==Configuration.ORIENTATION_LANDSCAPE?100:190);}
    private void configureSafeInsets(){
        if(Build.VERSION.SDK_INT>=30){
            getWindow().setDecorFitsSystemWindows(false);
            root.setOnApplyWindowInsetsListener((view,insets)->{
                android.graphics.Insets safe=insets.getInsets(android.view.WindowInsets.Type.systemBars()|android.view.WindowInsets.Type.displayCutout());
                view.setPadding(safe.left,fullScreen?0:safe.top,safe.right,fullScreen?0:safe.bottom);
                return insets;
            });
        } else {
            getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_VISIBLE);
            root.setFitsSystemWindows(true);
        }
        root.requestApplyInsets();
    }
    private int dp(int x){return (int)(getResources().getDisplayMetrics().density*x+.5f);}
    private void switchMode(String next){mode=next;query="";filterGroup="Todos";onlyFavorites=false;dismissBrowser();build();}
    private void addButtonToList(String caption,Runnable click){Button b=button(caption,click);listBox.addView(b,new LinearLayout.LayoutParams(-1,dp(54)));}
    private void refresh(){if(listBox==null)return;
        listBox.removeAllViews(); if(mode.equals("WebTV"))addButtonToList("Descobrir vídeo numa página Web",this::pageDialog);
        TreeSet<String> names=new TreeSet<>(String.CASE_INSENSITIVE_ORDER); names.add("Todos");
        for(MediaItemEntry e:all)if(e.type.equals(mode))names.add(e.group);
        String[] groupNames=names.toArray(new String[0]);
        ArrayAdapter<String> sp=new ArrayAdapter<>(this,android.R.layout.simple_spinner_dropdown_item,groupNames);
        groups.setAdapter(sp);int ix=Arrays.asList(groupNames).indexOf(filterGroup);groups.setSelection(Math.max(0,ix));
        groups.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener(){public void onNothingSelected(android.widget.AdapterView<?> p){}public void onItemSelected(android.widget.AdapterView<?> p,View v,int index,long id){String value=groupNames[index];if(!value.equals(filterGroup)){filterGroup=value; refresh();}}});
        entries.clear(); for(MediaItemEntry e:all){if(!e.type.equals(mode))continue;
            if(onlyFavorites&&!favorites.contains(e.key()))continue;
            if(!filterGroup.equals("Todos")&&!e.group.equals(filterGroup))continue;
            if(!query.isEmpty()&&!(e.name+" "+e.group).toLowerCase(Locale.ROOT).contains(query.toLowerCase(Locale.ROOT)))continue;
            entries.add(e);
        }
        for(MediaItemEntry e:entries){
            LinearLayout line=new LinearLayout(this);line.setGravity(Gravity.CENTER_VERTICAL);line.setPadding(8,2,8,2);
            TextView title=text(e.name+"\n"+e.group,14);title.setMaxLines(2);line.addView(title,new LinearLayout.LayoutParams(0,dp(57),1));title.setOnClickListener(v->play(e));
            TextView star=text(favorites.contains(e.key())?"★":"☆",23);star.setGravity(Gravity.CENTER);line.addView(star,new LinearLayout.LayoutParams(dp(42),dp(57)));star.setOnClickListener(v->{if(!favorites.add(e.key()))favorites.remove(e.key());saveStore();refresh();});
            TextView menu=text("⋮",24);menu.setGravity(Gravity.CENTER);line.addView(menu,new LinearLayout.LayoutParams(dp(38),dp(57)));menu.setOnClickListener(v->itemMenu(e,menu));
            listBox.addView(line); View divider=new View(this);divider.setBackgroundColor(0xff333944);listBox.addView(divider,new LinearLayout.LayoutParams(-1,1));
        }
        status.setText(entries.size()+" itens  •  "+mode+(onlyFavorites?"  •  Favoritos":""));
    }
    private void itemMenu(MediaItemEntry e,View anchor){PopupMenu pm=new PopupMenu(this,anchor);for(String opt:new String[]{"Reproduzir","Copiar URL","Guardar conteúdo","Remover da lista","Abrir noutra aplicação"})pm.getMenu().add(opt);
        pm.setOnMenuItemClickListener(item->{switch(item.getTitle().toString()){
            case "Reproduzir":play(e);break;
            case "Copiar URL":((android.content.ClipboardManager)getSystemService(CLIPBOARD_SERVICE)).setPrimaryClip(ClipData.newPlainText("URL",e.url));toast("URL copiado");break;
            case "Guardar conteúdo":download(e);break;
            case "Remover da lista":all.remove(e);saveStore();refresh();break;
            case "Abrir noutra aplicação":try{Intent i=new Intent(Intent.ACTION_VIEW,Uri.parse(e.url));startActivity(Intent.createChooser(i,"Abrir com"));}catch(Exception ex){message(ex.getMessage());}break;
        }return true;});pm.show();}
    private void openMenu(){String[] options={"Importar lista M3U / RSS", "Abrir ficheiro multimédia", "Importar lista por URL", "Adicionar canal / estação", "Limpar lista deste separador", "Repetir reprodução: ligar/desligar", "Volume: 100%"};
        new AlertDialog.Builder(this).setTitle("Abrir / Opções").setItems(options,(d,which)->{
            switch(which){case 0:pick(PICK_LIST,"*/*");break;case 1:pick(PICK_MEDIA,"*/*");break;case 2:urlDialog();break;case 3:addDirectDialog();break;
                case 4:new AlertDialog.Builder(this).setMessage("Remover todas as entradas de "+mode+"?").setPositiveButton("Remover",(a,b)->{all.removeIf(e->e.type.equals(mode));saveStore();refresh();}).setNegativeButton("Cancelar",null).show();break;
                case 5:player.setRepeatMode(player.getRepeatMode()==Player.REPEAT_MODE_ONE?Player.REPEAT_MODE_OFF:Player.REPEAT_MODE_ONE);toast(player.getRepeatMode()==Player.REPEAT_MODE_ONE?"Repetição ativa":"Repetição desativada");break;
                case 6:volumeDialog();break;
            }
        }).show();}
    private void volumeDialog(){SeekBar s=new SeekBar(this);s.setMax(100);s.setProgress((int)(player.getVolume()*100));s.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener(){public void onStartTrackingTouch(SeekBar v){}public void onStopTrackingTouch(SeekBar v){}public void onProgressChanged(SeekBar v,int p,boolean user){player.setVolume(p/100f);}});new AlertDialog.Builder(this).setTitle("Volume").setView(s).setPositiveButton("Fechar",null).show();}
    private void pick(int code,String mime){
        // ACTION_GET_CONTENT direto: permite que os gestores de ficheiros de terceiros
        // compatíveis surjam na secção «Abrir de» do seletor Android.
        // Não adicionar CATEGORY_OPENABLE nem envolver em Intent.createChooser().
        Intent i=new Intent(Intent.ACTION_GET_CONTENT);
        i.setType("*/*");
        i.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        if(code==PICK_MEDIA)i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
        try{startActivityForResult(i,code);}
        catch(android.content.ActivityNotFoundException e){
            // Fallback SAF quando não existe atividade compatível com GET_CONTENT.
            Intent fallback=new Intent(Intent.ACTION_OPEN_DOCUMENT);
            fallback.setType("*/*");
            fallback.addCategory(Intent.CATEGORY_OPENABLE);
            fallback.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION|Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            if(code==PICK_MEDIA)fallback.putExtra(Intent.EXTRA_ALLOW_MULTIPLE,true);
            try{startActivityForResult(fallback,code);}
            catch(android.content.ActivityNotFoundException ex){message("Não existe um seletor de ficheiros disponível.");}
        }
    }
    @Override protected void onActivityResult(int req,int result,Intent data){super.onActivityResult(req,result,data);if(result!=RESULT_OK||data==null)return;
        if(req==PICK_EXPORT){try(OutputStream out=getContentResolver().openOutputStream(data.getData())){if(out!=null)out.write(pendingExport.getBytes(StandardCharsets.UTF_8));toast("Lista guardada");}catch(Exception e){message(e.toString());}return;}
        if(req==PICK_MEDIA){if(data.getClipData()!=null){for(int i=0;i<data.getClipData().getItemCount();i++)addLocal(data.getClipData().getItemAt(i).getUri());}else if(data.getData()!=null)addLocal(data.getData());saveStore();refresh();return;}
        Uri uri=data.getData(); if(uri==null)return;
        try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}
        try(InputStream in=getContentResolver().openInputStream(uri)){if(in==null)return;String s=read(in);addParsed(s,uri.toString(),mode);}catch(Exception e){message("Erro ao importar: "+e.getMessage());}
    }
    private void addLocal(Uri uri){String name=uri.getLastPathSegment();try(Cursor c=getContentResolver().query(uri,new String[]{OpenableColumns.DISPLAY_NAME},null,null,null)){if(c!=null&&c.moveToFirst())name=c.getString(0);}catch(Exception ignored){}MediaItemEntry e=new MediaItemEntry(name==null?"Multimédia local":name,uri.toString(),"Ficheiros",mode);all.add(e);try{getContentResolver().takePersistableUriPermission(uri,Intent.FLAG_GRANT_READ_URI_PERMISSION);}catch(Exception ignored){}}
    private void urlDialog(){inputDialog("Importar lista M3U, RSS ou URL direto","https://",value->{if(value.isEmpty())return;String u=value.trim();if(isMediaUrl(u)){addEntry(new MediaItemEntry(u,u,"Endereços",mode));return;}fetch(u,mode);});}
    private void addDirectDialog(){inputDialog("Nome do canal / estação","",name->inputDialog("URL de reprodução","https://",url->{if(!url.trim().isEmpty())addEntry(new MediaItemEntry(name.trim().isEmpty()?url:name.trim(),url.trim(),"Adicionados",mode));}));}
    private interface StringHandler{void accept(String s);}
    private void inputDialog(String title,String hint,StringHandler handler){EditText input=new EditText(this);input.setSingleLine(true);input.setText(hint);input.setSelectAllOnFocus(true);new AlertDialog.Builder(this).setTitle(title).setView(input).setPositiveButton("OK",(d,w)->handler.accept(input.getText().toString())).setNegativeButton("Cancelar",null).show();}
    private boolean isMediaUrl(String u){return u.matches("(?i).*\\.(mp4|mp3|aac|ts|m4a|flac|mkv|wav|ogg|webm)(\\?.*)?")||u.contains(".m3u8")||u.contains(".mpd");}
    private void fetch(String url,String forMode){fetch(url,forMode,false);}
    private void fetch(String url,String forMode,boolean isDefault){status.setText("A carregar lista…");workers.execute(()->{try{
        HttpURLConnection c=(HttpURLConnection)new URL(url).openConnection();c.setConnectTimeout(13000);c.setReadTimeout(22000);c.setRequestProperty("User-Agent","Mozilla/5.0 TVMultiPlayer Android");c.setInstanceFollowRedirects(true);
        String text;try(InputStream in=c.getInputStream()){text=read(in);}String effective=c.getURL().toString();
        runOnUiThread(()->{
            if(isDefault){
                List<MediaItemEntry> found=PlaylistParser.parse(text,effective,forMode);
                if(!found.isEmpty())getPreferences(0).edit().putBoolean("default_iptv_loaded",true).apply();
            }
            addParsed(text,effective,forMode);
        });
    }catch(Exception e){runOnUiThread(()->message("Não foi possível carregar: "+e.getMessage()));}});}
    private static String read(InputStream in)throws IOException {ByteArrayOutputStream out=new ByteArrayOutputStream();byte[] data=new byte[16384];int n;while((n=in.read(data))>=0){out.write(data,0,n);if(out.size()>12*1024*1024)throw new IOException("Ficheiro demasiado grande (limite 12 MB)");}return out.toString("UTF-8");}
    private void addParsed(String data,String base,String forMode){List<MediaItemEntry> parsed=PlaylistParser.parse(data,base,forMode);if(parsed.isEmpty()){message("Não foram encontrados canais/episódios. Para streams HLS usa 'Adicionar canal' ou introduz o URL direto.");return;}
        int count=0;HashSet<String> keys=new HashSet<>();for(MediaItemEntry e:all)keys.add(e.key());for(MediaItemEntry e:parsed)if(keys.add(e.key())){all.add(e);count++;}saveStore();refresh();toast(count+" entradas importadas");}
    private void addEntry(MediaItemEntry e){all.add(e);saveStore();refresh();}
    @OptIn(markerClass=UnstableApi.class)
    private void play(MediaItemEntry e){selected=e;nowPlaying.setText(e.name);dismissBrowser();
        try{
            androidx.media3.common.MediaItem.Builder mb=new androidx.media3.common.MediaItem.Builder().setUri(e.url);
            String lower=e.url.toLowerCase(Locale.ROOT);
            if(lower.contains(".m3u8"))mb.setMimeType(MimeTypes.APPLICATION_M3U8);
            if(lower.contains(".mpd"))mb.setMimeType(MimeTypes.APPLICATION_MPD);
            androidx.media3.common.MediaItem item=mb.build();
            player.setMediaItem(item);player.prepare();player.play();
        }catch(Exception ex){message("Não foi possível reproduzir: "+ex.getMessage());}
    }
    private void playNextPodcast(){if(selected==null||!"Rádio".equals(selected.type))return;int i=all.indexOf(selected);if(i>=0&&i+1<all.size()&&all.get(i+1).type.equals("Rádio")&&"Podcasts".equals(selected.group))play(all.get(i+1));}
    private void toggleFullscreen(){fullScreen=!fullScreen;getWindow().getDecorView().setSystemUiVisibility(fullScreen?(View.SYSTEM_UI_FLAG_FULLSCREEN|View.SYSTEM_UI_FLAG_HIDE_NAVIGATION|View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY):View.SYSTEM_UI_FLAG_VISIBLE);
        toolbar.setVisibility(fullScreen?View.GONE:View.VISIBLE);heading.setVisibility(fullScreen?View.GONE:View.VISIBLE);controls.setVisibility(fullScreen?View.GONE:View.VISIBLE);
        int idx=root.indexOfChild(videoContainer);for(int j=0;j<root.getChildCount();j++){View v=root.getChildAt(j);if(v!=videoContainer)v.setVisibility(fullScreen?View.GONE:View.VISIBLE);}
        LinearLayout.LayoutParams lp=(LinearLayout.LayoutParams)videoContainer.getLayoutParams();lp.height=fullScreen?0:videoHeight();lp.weight=fullScreen?1:0;videoContainer.setLayoutParams(lp);root.requestApplyInsets();
    }
    private void exportPlaylist(){StringBuilder sb=new StringBuilder("#EXTM3U\n");for(MediaItemEntry e:entries){sb.append("#EXTINF:-1,").append(e.name.replace("\n"," ")).append('\n');sb.append("#EXTGRP:").append(e.group.replace("\n"," ")).append('\n').append(e.url).append('\n');}
        pendingExport=sb.toString();Intent i=new Intent(Intent.ACTION_CREATE_DOCUMENT);i.addCategory(Intent.CATEGORY_OPENABLE);i.setType("audio/x-mpegurl");i.putExtra(Intent.EXTRA_TITLE,"TVMultiPlayer_"+mode+".m3u8");startActivityForResult(i,PICK_EXPORT);}
    private void download(MediaItemEntry e){if(!e.url.startsWith("http")){message("A gravação está disponível para URLs HTTP/HTTPS diretos.");return;}
        if(e.url.contains(".m3u8")||e.url.contains(".mpd")){message("Esta versão guarda apenas ficheiros diretos, não efetua gravação ou conversão de transmissões segmentadas HLS/DASH.");return;}
        String ext=".mp4";try{String p=new URI(e.url).getPath().toLowerCase(Locale.ROOT);int dot=p.lastIndexOf('.');if(dot>=0&&p.length()-dot<8)ext=p.substring(dot);}catch(Exception ignored){}
        String name=e.name.replaceAll("[\\\\/:*?\"<>|]","_");if(name.length()>70)name=name.substring(0,70);String filename=name+ext;
        try{DownloadManager.Request req=new DownloadManager.Request(Uri.parse(e.url));req.setTitle(e.name);req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS,"TVMultiPlayer/"+filename);
            ((DownloadManager)getSystemService(DOWNLOAD_SERVICE)).enqueue(req);toast("Transferência iniciada: Download/TVMultiPlayer");}
        catch(Exception err){message("Falha na transferência: "+err.getMessage());}
    }
    private void pageDialog(){inputDialog("Página WebTV (deteção de vídeo)","https://",url->openWeb(url.trim()));}
    private void openWeb(String url){if(!url.startsWith("http")){message("Indica um endereço HTTP/HTTPS válido.");return;}
        detected.clear();dismissBrowser();webView=new WebView(this);webView.getSettings().setJavaScriptEnabled(true);webView.getSettings().setDomStorageEnabled(true);
        webView.setWebViewClient(new WebViewClient(){
            @Override public WebResourceResponse shouldInterceptRequest(WebView view,WebResourceRequest req){String candidate=req.getUrl().toString();if(isMediaUrl(candidate) && !candidate.matches("(?i).*\\.ts(\\?.*)?"))runOnUiThread(()->foundStream(candidate));return null;}
            @Override public void onPageFinished(WebView view,String u){status.setText("Página Web aberta: inicia o vídeo na página para procurar streams.");}
        });
        final Dialog dlg=new Dialog(this,android.R.style.Theme_Material_Light_NoActionBar_Fullscreen);
        LinearLayout panel=vertical();Button close=button("Fechar navegador / regressar",()->dlg.dismiss());panel.addView(close,new LinearLayout.LayoutParams(-1,48));panel.addView(webView,new LinearLayout.LayoutParams(-1,0,1));dlg.setContentView(panel);dlg.setOnDismissListener(x->dismissBrowser());dlg.show();webView.loadUrl(url);
    }
    private void foundStream(String url){if(detected.add(url)){MediaItemEntry e=new MediaItemEntry("WebTV • "+new Date().toString(),url,"Detetados","WebTV");addEntry(e);toast("Stream detetado e acrescentado a WebTV");}}
    private void dismissBrowser(){if(webView!=null){try{webView.stopLoading();webView.loadUrl("about:blank");webView.destroy();}catch(Exception ignored){}webView=null;}}
    private void loadStore(){try{String src=getPreferences(0).getString("store","");JSONObject o=new JSONObject(src);JSONArray a=o.optJSONArray("entries");if(a!=null)for(int i=0;i<a.length();i++)all.add(MediaItemEntry.fromJson(a.getJSONObject(i)));JSONArray f=o.optJSONArray("favorites");if(f!=null)for(int i=0;i<f.length();i++)favorites.add(f.getString(i));}catch(Exception ignored){}}
    private void saveStore(){try{JSONObject o=new JSONObject();JSONArray arr=new JSONArray(),fav=new JSONArray();for(MediaItemEntry e:all)arr.put(e.json());for(String s:favorites)fav.put(s);o.put("entries",arr);o.put("favorites",fav);getPreferences(0).edit().putString("store",o.toString()).apply();}catch(Exception ignored){}}
    private void toast(String s){Toast.makeText(this,s,Toast.LENGTH_LONG).show();}
    private void message(String s){new AlertDialog.Builder(this).setMessage(s).setPositiveButton("OK",null).show();}
    @Override protected void onDestroy(){
        getWindow().getDecorView().setKeepScreenOn(false);
        dismissBrowser();
        if(player!=null)player.release();
        workers.shutdownNow();
        super.onDestroy();
    }
    @Override public void onConfigurationChanged(Configuration c){
        super.onConfigurationChanged(c);
        // Preserve search, current tab, filters, playback and list scroll during rotation.
        savedListPosition=channelScroll!=null?channelScroll.getScrollY():0;
        boolean wasFullScreen=fullScreen;
        build();
        if(wasFullScreen){fullScreen=false;toggleFullscreen();}
        root.requestApplyInsets();
    }
    @Override protected void onSaveInstanceState(Bundle out){
        out.putString("mode",mode);out.putString("group",filterGroup);out.putString("query",query);
        out.putBoolean("favoritesOnly",onlyFavorites);
        out.putInt("scrollPosition",channelScroll==null?0:channelScroll.getScrollY());
        super.onSaveInstanceState(out);
    }
    @Override public void onBackPressed(){if(fullScreen){toggleFullscreen();return;}super.onBackPressed();}
    @Override protected void onDestroy(){dismissBrowser();player.release();workers.shutdownNow();super.onDestroy();}
}
