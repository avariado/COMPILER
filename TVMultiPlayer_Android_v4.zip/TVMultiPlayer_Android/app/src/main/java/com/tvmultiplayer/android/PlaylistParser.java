package com.tvmultiplayer.android;

import java.util.*;
import java.util.regex.*;
import javax.xml.parsers.DocumentBuilderFactory;
import org.w3c.dom.*;
import org.xml.sax.InputSource;
import java.io.StringReader;

public final class PlaylistParser {
    private PlaylistParser(){}
    private static String attr(String s,String key){ Matcher m=Pattern.compile("(?:^|\\s)"+Pattern.quote(key)+"\\s*=\\s*[\\\"']([^\\\"']*)[\\\"']",Pattern.CASE_INSENSITIVE).matcher(s); return m.find()?m.group(1):""; }
    public static List<MediaItemEntry> parse(String text,String base,String mode) {
        ArrayList<MediaItemEntry> out=new ArrayList<>();
        if(text.trim().startsWith("<?xml") || text.contains("<rss") || text.contains("<feed")) return rss(text,mode);
        String name="",group="",referer="",userAgent="";
        for(String raw:text.replace("\r", "").split("\n")) {
            String s=raw.trim(); if(s.isEmpty()) continue;
            if(s.startsWith("#EXTINF")){
                int comma=s.indexOf(','); name=comma>=0?s.substring(comma+1).trim():"";
                String a=comma>=0?s.substring(0,comma):s;
                group=attr(a,"group-title"); referer=attr(a,"http-referrer"); userAgent=attr(a,"http-user-agent");
                String tvg=attr(a,"tvg-name"); if(name.isEmpty())name=tvg;
            } else if(s.startsWith("#EXTGRP:")) group=s.substring(8).trim();
            else if(s.startsWith("#EXTVLCOPT:")) {
                String v=s.substring(11); if(v.startsWith("http-referrer="))referer=v.substring(14); if(v.startsWith("http-user-agent="))userAgent=v.substring(16);
            } else if(!s.startsWith("#")) {
                String url=s;
                try { if(base!=null&&!base.isEmpty()) url=new java.net.URI(base).resolve(s).toString(); } catch(Exception ignored){}
                if(!url.startsWith("http://")&&!url.startsWith("https://")&&!url.startsWith("content://")&&!url.startsWith("file://"))continue;
                // HLS variant playlists are media manifests, not channel lists.
                if(text.contains("#EXT-X-STREAM-INF") || text.contains("#EXT-X-TARGETDURATION")) return out;
                MediaItemEntry e=new MediaItemEntry(name.isEmpty()?deriveName(url):name,url,group.isEmpty()?"Sem grupo":group,mode);
                e.referer=referer; e.userAgent=userAgent; out.add(e);
                name="";group="";referer="";userAgent="";
            }
        }
        return out;
    }
    private static String deriveName(String url){try {String p=new java.net.URI(url).getPath();String s=p.substring(p.lastIndexOf('/')+1);return s.isEmpty()?url:s;}catch(Exception e){return url;}}
    private static List<MediaItemEntry> rss(String xml,String mode){
        ArrayList<MediaItemEntry> out=new ArrayList<>();
        try {
            DocumentBuilderFactory f=DocumentBuilderFactory.newInstance();f.setFeature("http://apache.org/xml/features/disallow-doctype-decl",true); f.setFeature("http://xml.org/sax/features/external-general-entities",false); f.setFeature("http://xml.org/sax/features/external-parameter-entities",false); f.setXIncludeAware(false);f.setExpandEntityReferences(false);
            Document d=f.newDocumentBuilder().parse(new InputSource(new StringReader(xml)));
            NodeList items=d.getElementsByTagName("item");
            for(int i=0;i<items.getLength();i++){
                Element el=(Element)items.item(i); String title=el.getElementsByTagName("title").getLength()>0?el.getElementsByTagName("title").item(0).getTextContent():"Episódio";
                NodeList enclosures=el.getElementsByTagName("enclosure");
                if(enclosures.getLength()>0){ String url=((Element)enclosures.item(0)).getAttribute("url"); if(url.startsWith("http"))out.add(new MediaItemEntry(title,url,"Podcasts",mode)); }
            }
        }catch(Exception ignored){}
        return out;
    }
}
