package com.tvmultiplayer.android;

import org.json.JSONObject;

public class MediaItemEntry {
    public String name, url, group, type, referer, userAgent;
    public MediaItemEntry(String name, String url, String group, String type) {
        this.name=name; this.url=url; this.group=group; this.type=type;
        this.referer=""; this.userAgent="";
    }
    public String key() { return type+"|"+url; }
    public JSONObject json() {
        JSONObject o=new JSONObject();
        try { o.put("name",name); o.put("url",url); o.put("group",group); o.put("type",type); o.put("referer",referer); o.put("userAgent",userAgent); } catch(Exception ignored){}
        return o;
    }
    public static MediaItemEntry fromJson(JSONObject o) {
        MediaItemEntry e = new MediaItemEntry(o.optString("name"),o.optString("url"),o.optString("group"),o.optString("type","IPTV"));
        e.referer=o.optString("referer"); e.userAgent=o.optString("userAgent"); return e;
    }
    @Override public String toString(){return name;}
}
