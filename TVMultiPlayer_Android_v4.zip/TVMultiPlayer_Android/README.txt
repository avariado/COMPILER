TV MultiPlayer Android 1.0 — projeto Java / Gradle

COMPILAÇÃO
Abrir esta pasta de projeto no APK Compiler, como os projetos Android anteriores.
Módulo: app
Package/applicationId: com.tvmultiplayer.android
Android Gradle Plugin: 8.2.2; Java: 17; compileSdk 35; minSdk 24.
Motor: Media3/ExoPlayer 1.8.0. Compilação requer acesso às dependências Google/Maven Central na primeira execução.
Não inclui nem altera o compilador, o SDK, keystore ou configurações externas.

UTILIZAÇÃO
IPTV / Rádio: Abrir -> importar M3U/M3U8, RSS de podcasts ou ficheiros individuais.
URL: importar uma lista via HTTP(S); usar "Adicionar canal" para HLS diretos.
WebTV: introduzir o URL de uma página Web; o WebView recolhe pedidos com endereços de vídeo visíveis. Não substitui o motor Playwright/Chromium do programa Windows.
Lista: tocar para reproduzir, estrela para favoritos, menu de três pontos para copiar URL, abrir externamente, eliminar ou descarregar.
Procurar e filtrar por grupos; exportar listas no formato EXTINF/EXTGRP/URL.

ARMAZENAMENTO
Favoritos, listas e definições: espaço privado da app (permanecem após reinício e rotação).
Listas, fotos/vídeos e RSS locais: seletor de documentos do Android (SAF); podem estar na pasta Download ou noutra pasta.
Exportação de listas: o utilizador escolhe a pasta, incluindo Download.
Ficheiros transferidos diretamente: Download/TVMultiPlayer (DownloadManager).
Não é solicitada permissão de acesso irrestrito ao armazenamento.

LIMITAÇÕES IMPORTANTES
- WebTV: a descoberta automática das fontes específicas do Python (que dependem de Playwright, scraping e resolução de tokens) não está portada; WebView interceta apenas URLs de media expostos pelos pedidos de rede.
- HLS/DASH: reprodução suportada; download/gravação segmentada NÃO implementada.
- Podcasts: RSS básico com enclosure; importação OPML não implementada apesar do rótulo genérico do seletor.
- Não há importação automática de playlists de websites particulares do script Windows, monitor Cinemix, atualização automática dos URLs temporários ou leitura de um diretório inteiro.
- Alguns streams necessitam de headers especiais, cookies, DRM ou codecs fora do Media3; não há garantia de reprodução.
- Reprodução em segundo plano não tem serviço dedicado; poderá parar se o Android terminar a atividade.
- Sem testes de compilação/dispositivo realizados neste ambiente. Trata-se de uma primeira versão funcional em código-fonte, não de um APK validado.

CORREÇÕES DE INTERFACE (25/10/2026)
- Barra de título azul com «TV MultiPlayer» centrado, substituindo o antigo título em label.
- Ícone próprio fornecido em res/drawable/ic_launcher.png e declarado no AndroidManifest.
- Tratamento explícito das system bars/display cutout no Android 11+; fallback fitsSystemWindows em versões anteriores; adaptação ao modo de ecrã inteiro.
- Rotação mantém tab, pesquisa, filtro, favoritos, posição da lista e o mesmo ExoPlayer; redimensiona o vídeo na horizontal.
- Seleção com ACTION_OPEN_DOCUMENT, categoria OPENABLE e permissões SAF persistentes. Aplicações de terceiros aparecem em «Abrir de» se publicarem um DocumentsProvider compatível (não se pode forçar a presença).
- Sem alterações de versão ou dependências Gradle.
- Ainda não compilado/testado num dispositivo Android.

ATUALIZAÇÃO DA INTERFACE (25/10/2026)
- Barra azul do título reduzida para 40dp; botões e separadores aumentados
  para aproximadamente 54-56dp; alturas definidas em dp e não pixels.
- O ecrã mantém-se ligado enquanto ExoPlayer indica reprodução efetiva.
- Na primeira execução, a app tenta importar a lista IPTV de
  https://pastebin.com/raw/57GAkcRF ; não substitui entradas já existentes.
  Necessita de ligação à Internet e de o endereço disponibilizar M3U legível.
- Os comandos normais Abrir utilizam ACTION_GET_CONTENT diretamente, sem chooser nem CATEGORY_OPENABLE.
  Nota: Android decide que aplicações figuram no seletor; apps de terceiros
  sem DocumentsProvider podem apenas aparecer no chooser externo.
  Documentos vindos de ACTION_GET_CONTENT poderão perder acesso após reinício
  caso a aplicação fornecedora não disponibilize permissões persistentes.
- Gradle, plugin Android, Java, dependências e package NÃO foram alterados.

VERSÃO 4 — SELETOR DE FICHEIROS
- Os dois comandos de abertura usam ACTION_GET_CONTENT diretamente, MIME */*, sem CATEGORY_OPENABLE e sem Intent.createChooser(), para disponibilizar gestores de terceiros em «Abrir de», quando suportados pelo dispositivo.
- ACTION_OPEN_DOCUMENT é usado apenas se não existir atividade para ACTION_GET_CONTENT.
- Removidas as opções redundantes de explorador externo.
- Em ficheiros devolvidos por ACTION_GET_CONTENT, o acesso URI pode ser temporário: é necessário voltar a selecionar o ficheiro se a permissão caducar.
